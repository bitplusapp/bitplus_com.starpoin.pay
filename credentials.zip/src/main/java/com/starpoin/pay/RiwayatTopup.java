package com.starpoin.pay;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.LapTiketAdapter;
import com.starpoin.pay.model.LapTiket;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.PBar;
import com.starpoin.pay.util.DateParse;
import com.starpoin.pay.util.DatePick;
import com.starpoin.pay.util.JsonIn;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class RiwayatTopup extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;
    private RecyclerView rvDenom;
    private LinearLayout lyAmount;
    private Button btndrtgl,btnsdtgl, btnSubmit, btnClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat_topup);

        this.setTitle("Riwayat Topup");

        btnSubmit = findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);

        btnClear = findViewById(R.id.btnClear);
        btnClear.setOnClickListener(this);

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
        rvDenom=findViewById(R.id.rvDenom);
        lyAmount=(LinearLayout) findViewById(R.id.lyAmount);

        btndrtgl=(Button) findViewById(R.id.btndrtgl);
        btndrtgl.setOnClickListener(this);

        btnsdtgl=(Button) findViewById(R.id.btnsdtgl);
        btnsdtgl.setOnClickListener(this);

        String tgl=new SimpleDateFormat("dd/MM/yyyy").format(new Date());
        btndrtgl.setText(tgl);
        btnsdtgl.setText(tgl);

        initial();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btndrtgl:
                new DatePick(RiwayatTopup.this,btndrtgl).onClick(v);
                break;
            case R.id.btnsdtgl:
                new DatePick(RiwayatTopup.this,btnsdtgl).onClick(v);
                break;
            case R.id.btnSubmit:
                inquery();
                break;
            case R.id.btnClear:
                initial();
                break;
        }
    }

    private void initial() {
        rvDenom.removeAllViews();
        LinearLayout layoutResult = findViewById(R.id.layoutResult);
        layoutResult.setVisibility(View.GONE);
        lyAmount.setVisibility(View.GONE);
    }

    private void inquery(){
        String str1=btndrtgl.getText().toString();
        String str2=btnsdtgl.getText().toString();
        if(!str1.contains("/")||!str2.contains("/")){
            showMsg("Tanggal belum dipilih");
            return;
        }
        String drtgl=new DateParse().tglDefault(str1);
        String sdtgl=new DateParse().tglDefault(str2);
        String params="ticket/history/"+drtgl+"/"+sdtgl;

        final ProgressBar pbar=new PBar(this,rootLayout);
        OtherTask task = new OtherTask(RiwayatTopup.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc").trim();
                if(rc.equals("000")||rc.equals("0000")){
                    viewContent(content);
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }

            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewContent(String content) {
        DecimalFormat df=new DecimalFormat("#,##0");
        LinearLayout layoutResult = findViewById(R.id.layoutResult);
        layoutResult.setVisibility(View.VISIBLE);
        rvDenom.removeAllViews();
        ArrayList<LapTiket> list=new LapTiket().listContent(content);
        LapTiketAdapter adapter=new LapTiketAdapter(RiwayatTopup.this,list);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);

        int total = 0;
        for(int i =0; i < list.size(); i++) {
            total += Integer.parseInt(list.get(i).getTiket().replace(",","").replace(".", ""));
        }

        lyAmount.setVisibility(View.VISIBLE);
        TextView tvTotalAmount = findViewById(R.id.tvTotalAmount);
        tvTotalAmount.setText(df.format(total));
    }
}