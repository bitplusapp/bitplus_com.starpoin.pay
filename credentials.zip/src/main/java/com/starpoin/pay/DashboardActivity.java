package com.starpoin.pay;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.messaging.FirebaseMessaging;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.starpoin.pay.util.MyFirebaseMessagingService;
import com.starpoin.pay.util.NotificationUtils;
import com.starpoin.pay.util.Wong;

public class DashboardActivity extends AppCompatActivity {

    private static NotificationUtils notificationUtils;
    private static final String TAG = "DashboardActivity";
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    String[] permissionsRequired = new String[]{
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
    };
    private SharedPreferences permissionStatus;
    private boolean sentToSettings = false;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //Fragment fragment = null;
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    Fragment trans=new TransFragment();
                    loadFragment(trans);
                    return true;
                case R.id.navigation_dashboard:
                    Fragment laporan=new OtherFragment();
                    loadFragment(laporan);
                    return true;
                case R.id.navigation_user:
                    Fragment profile = new ProfileFragment();
                    Bundle args = new Bundle();
                    args.putString("param1", "test param1");
                    args.putString("param2", "test param2");
                    profile.setArguments(args);
                    loadFragment(profile);
                    return true;
                case R.id.navigation_notifications:
                        Fragment bantuan=new BantuanFragment();
                        loadFragment(bantuan);
                    return true;
            }

            return false;
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_dashboard);

            getSupportActionBar().hide();
            notificationUtils = new NotificationUtils(this);


            BottomNavigationView navView = findViewById(R.id.nav_view);
            navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
            navView.setSelectedItemId(R.id.navigation_home);

            regToTopic();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                permissionStatus = getSharedPreferences("permissionStatus",MODE_PRIVATE);
                if(ActivityCompat.checkSelfPermission(DashboardActivity.this, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                        || ActivityCompat.checkSelfPermission(DashboardActivity.this, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                ){

                    if(ActivityCompat.shouldShowRequestPermissionRationale(DashboardActivity.this,permissionsRequired[0])
                            || ActivityCompat.shouldShowRequestPermissionRationale(DashboardActivity.this,permissionsRequired[1])

                    ){

                        //Show Information about why you need the permission

                        FancyAlertDialog.Builder
                                .with(this)
                                .setTitle("Berikan izin akses")
                                .setBackgroundColorRes(R.color.warning)  // for @ColorRes use setBackgroundColorRes(R.color.colorvalue)
                                .setMessage("Perlu beberapa izin")
                                .setNegativeBtnText("Izinkan")
                                .setPositiveBtnBackground(Color.parseColor("#0F78C9"))  // for @ColorRes use setPositiveBtnBackgroundRes(R.color.colorvalue)
                                .setPositiveBtnText("Tunda")
                                .setNegativeBtnBackgroundRes(R.color.common_google_signin_btn_text_light)  // for @ColorRes use setNegativeBtnBackgroundRes(R.color.colorvalue)
                                .setAnimation(Animation.POP)
                                .isCancellable(true)
                                .setIcon(R.drawable.ic_check_24, View.INVISIBLE)
                                .onPositiveClicked(dialog -> ActivityCompat.requestPermissions(DashboardActivity.this,permissionsRequired,PERMISSION_CALLBACK_CONSTANT))
                                .onNegativeClicked(dialog -> {
                                    Toast.makeText(DashboardActivity.this, "Izin ditunda", Toast.LENGTH_SHORT).show();
                                })
                                .build()
                                .show();
                    } else {
                        //just request the permission
                        ActivityCompat.requestPermissions(DashboardActivity.this,permissionsRequired,PERMISSION_CALLBACK_CONSTANT);
                    }

                    //txtPermissions.setText("Permissions Required");

                    SharedPreferences.Editor editor = permissionStatus.edit();
                    editor.putBoolean(permissionsRequired[0],true);
                    editor.commit();

                }
            }

    }

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        //transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        exitDialog();
    }



    private void exitDialog() {

        FancyAlertDialog.Builder
                .with(this)
                .setTitle("Konfirmasi")
                .setBackgroundColorRes(R.color.secondary)  // for @ColorRes use setBackgroundColorRes(R.color.colorvalue)
                .setMessage("Apakah anda yakin ingin keluar dari aplikasi?")
                .setNegativeBtnText("Tidak")
                .setPositiveBtnBackground(Color.parseColor("#0F78C9"))  // for @ColorRes use setPositiveBtnBackgroundRes(R.color.colorvalue)
                .setPositiveBtnText("Ya")
                .setNegativeBtnBackgroundRes(R.color.common_google_signin_btn_text_light)  // for @ColorRes use setNegativeBtnBackgroundRes(R.color.colorvalue)
                .setAnimation(Animation.POP)
                .isCancellable(true)
                .setIcon(R.drawable.ic_arrow_back_24, View.VISIBLE)
                .onPositiveClicked(dialog -> {
                    Wong.setUserLogin(false);
                    finish();
                })
                .onNegativeClicked(dialog -> {
                    //Toast.makeText(DashboardActivity.this, "Batal", Toast.LENGTH_SHORT).show();
                })
                .build()
                .show();
    }

    private void regToTopic(){
                String topik=getString(R.string.default_notification_channel_name);

                FirebaseMessaging.getInstance().subscribeToTopic(topik)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        String msg = "Subscribed";
                        if (!task.isSuccessful()) {
                            msg = "Subscribe failed";
                        }
                        Log.d(TAG, msg);
                        //Toast.makeText(DashboardActivity.this, msg, Toast.LENGTH_SHORT).show();
                    }
                });

                FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Log.w(TAG, "Fetching FCM registration token failed", task.getException());
                            return;
                        }

                        // Get new FCM registration token
                        String id_merchant = Wong.getIdmerch();
                        String token = task.getResult();
                        MyFirebaseMessagingService firebaseUpdate = new MyFirebaseMessagingService();
                        firebaseUpdate.sendRegistrationToServer(DashboardActivity.this, id_merchant,token);
                    }
                });
        // [END log_reg_token]
    }

}
