package com.starpoin.pay;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.SecureOtherTask;
import com.starpoin.pay.util.JsonIn;

import org.json.JSONObject;

public class FragmentReedem extends Fragment {
    private Context context;
    private FragmentActivity activity;
    private EditText editText1, editText2, editText3;
    private Button btnReedem;
    public FragmentReedem() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_reedem_code, container, false);

        editText1 = rootView.findViewById(R.id.editText1);
        editText2 = rootView.findViewById(R.id.editText2);
        editText3 = rootView.findViewById(R.id.editText3);

        editText1.requestFocus();

        btnReedem = rootView.findViewById(R.id.btnReedem);
        btnReedem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processReedemCode();
            }
        });

        btnReedem.setEnabled(false);

        setupEditTextListener();

        return rootView;
    }

    private void processReedemCode() {
        btnReedem.setEnabled(false);
        String kode_voucher = editText1.getText()+""+editText2.getText()+""+editText3.getText();
        if(kode_voucher.length() < 12) {
            Toast.makeText(requireContext(), "Kode voucher harus 12 digit", Toast.LENGTH_SHORT).show();
        }else{
            OtherTask task = new OtherTask(requireContext(), requireActivity(), new OnEventListener<String>() {

                @Override
                public void onSuccess(String object) {
                    JsonIn json = new JsonIn();
                    showMsg(json.getString(object, "message"));
                    btnReedem.setEnabled(true);
                }

                @Override
                public void onFailure(Exception e) {
                    e.printStackTrace();
                    btnReedem.setEnabled(true);
                }
            });

            task.execute("ticket/reedem/"+kode_voucher);
        }
    }

    private void setupEditTextListener() {
        editText1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 4) {
                    editText2.requestFocus();
                } else if (s.length() == 0) {
                    // Jika pengguna menghapus isi dari editText1, fokus akan dikembalikan ke editText1
                    editText1.requestFocus();
                }
            }
        });

        editText2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 4) {
                    editText3.requestFocus();
                } else if (s.length() == 0) {
                    // Jika pengguna menghapus isi dari editText2, fokus akan dikembalikan ke editText1
                    editText1.requestFocus();
                }
            }
        });

        editText3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 4) {
                    // Lakukan tindakan yang diinginkan setelah mengisi editText3
                    btnReedem.setEnabled(true);
                } else if (s.length() == 0) {
                    // Jika pengguna menghapus isi dari editText3, fokus akan dikembalikan ke editText2
                    editText2.requestFocus();
                    btnReedem.setEnabled(false);
                }
            }
        });
    }

    public void showMsg(String msg){
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(requireContext(), R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.msg_dialog);
        Button btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //bottomSheetDialog.cancel();
                bottomSheetDialog.dismiss();
            }
        });

        TextView tvError=bottomSheetDialog.findViewById(R.id.tvError);
        tvError.setText(msg);

        bottomSheetDialog.show();

    }

}
