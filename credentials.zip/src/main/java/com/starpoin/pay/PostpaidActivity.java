package com.starpoin.pay;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.starpoin.pay.model.Postpaid;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;

import org.json.JSONObject;

import java.util.Map;

public class PostpaidActivity extends AbaseActivity implements View.OnClickListener {

    private static final int SCAN_REQ=1;

    private ConstraintLayout rootLayout;

    private EditText etNomor;
    private Button btnScan;
    private Button btnLihat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postpaid);

        setBarTitle("PLN Postpaid");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        etNomor=(EditText) findViewById(R.id.etNomor);
        etNomor.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int txtSize=etNomor.getText().toString().length();
                if(txtSize>=10){
                    if(!btnLihat.isEnabled()){
                        btnLihat.setEnabled(true);
                    }
                }else{
                    if(btnLihat.isEnabled()){
                        btnLihat.setEnabled(false);
                    }
                }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }
            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }
        });

        btnScan=(Button) findViewById(R.id.btnScan);
        btnScan.setOnClickListener(this);

        btnLihat=(Button) findViewById(R.id.btnLihat);
        btnLihat.setOnClickListener(this);
    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnLihat:
                inquery();
                break;
            case R.id.btnScan:
                Intent intent = new Intent(this, ScanBarcodeActivity.class);
                startActivityForResult(intent, SCAN_REQ);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK){
            switch (requestCode){
                case SCAN_REQ:
                    String kode_barcode = data.getStringExtra("barcode");
                    //Log.i("kode_barcode",kode_barcode);
                    etNomor.setText(kode_barcode);
                    btnLihat.setEnabled(true);
                    break;
            }
        }
    }

    private void inquery(){

        String noid=etNomor.getText().toString().trim();
        if(noid.length()<10){
            showMsg("Nomor tidak sesuai");
            return;
        }
        Map<String,Object> map=new Postpaid().paramsInq(noid);
        String params= new JSONObject(map).toString();
        TransTask task = new TransTask(PostpaidActivity.this,PostpaidActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")){
                    String trxid=json.getObjectWithString(content,"data", "ref_id");
                    double amount =Double.parseDouble(json.getObjectWithString(content,"data", "amount"));
                    String admin = json.getObjectWithString(content,"data", "admin");
                    String bill = json.getObjectWithString(content, "data","bill");
                    double nominal = amount - (Long.parseLong(admin)*Long.parseLong(bill));
                    String time = json.getObjectWithString(content,"data", "time");
                    Intent intent=new Intent(PostpaidActivity.this,ResponseActivity.class);
                    intent.putExtra("produk", Produk.POSTPAID);
                    intent.putExtra("result", content);
                    intent.putExtra("nominal", nominal);
                    intent.putExtra("amount", amount);
                    intent.putExtra("trxid", trxid);
                    intent.putExtra("admin", admin);
                    intent.putExtra("time", time);
                    intent.putExtra("noid", noid);
                    intent.putExtra("additional", "-"); //tambahan parameter
                    startActivity(intent);

                    etNomor.setText("");
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }



}