package com.starpoin.pay;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.Profil;
import com.starpoin.pay.model.LoginMethod;
import com.starpoin.pay.task.LoginTask;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.PBarLinear;
import com.starpoin.pay.task.RegistrationTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Wong;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import in.aabhasjindal.otptextview.OTPListener;
import in.aabhasjindal.otptextview.OtpTextView;

public class VerifikasiRegActivity extends AbaseActivity implements View.OnClickListener {

    private RelativeLayout rootLayout;

    private TextView btnChat,btnVer,tvTimer;
    private String pin;
    private int totalResend;
    private OtpTextView otpTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_verifikasi_reg);

        if(getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        rootLayout=(RelativeLayout) findViewById(R.id.rootLayout);

        btnChat=(TextView) findViewById(R.id.btnResend) ;
        btnChat.setOnClickListener(this);

        tvTimer=(TextView) findViewById(R.id.tvTimer);
        //checkAndRequestPermissions();

        otpTextView = findViewById(R.id.otp_view);

        otpTextView.setOtpListener(new OTPListener() {
            @Override
            public void onInteractionListener() {
                // fired when user types something in the Otpbox
            }
            @Override
            public void onOTPComplete(String otp) {
                // fired when user has entered the OTP fully.
                verifikasi(otp);
            }
        });

        //focus
        otpTextView.requestFocusOTP();

        new CountDownTimer(60000, 1000) {

            public void onTick(long millisUntilFinished) {
                tvTimer.setText("Kirim ulang kode : " + millisUntilFinished / 1000);
                btnChat.setVisibility(View.GONE);
                // logic to set the EditText could go here
            }

            public void onFinish() {
                totalResend = 1;
                tvTimer.setText("Tidak dapat kode? Klik ");
                btnChat.setVisibility(View.VISIBLE);
            }

        }.start();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnResend:
                totalResend += 1;
                resendCode();
                break;
        }
    }

    @Override
    public void onResume() {
        //LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter("otp"));
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        //LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }

//    private BroadcastReceiver receiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            if (intent.getAction().equalsIgnoreCase("otp")) {
//                String message = intent.getStringExtra("message");
//                String sender = intent.getStringExtra("Sender");
//
//                if(sender.equals("+6285794513477")) {
//                    String code = parseCode(message);
//                    System.out.println("OTP CODE "+code);
//                    String[] arr = new String[code.length()];
//
//                    // Copy character by character into array
//                    for (int i = 0; i < code.length(); i++) {
//                        arr[i] = String.valueOf(code.charAt(i));
//                        System.out.println(arr[i]);
//                    }
//
//                    e1.setText((arr[0]));
//                    e2.setText((arr[1]));
//                    e3.setText((arr[2]));
//                    e4.setText((arr[3]));
//                    e5.setText((arr[4]));
//                    e6.setText((arr[5]));
//                    verifikasi();
//                }
//                //Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG).show();
//                //Log.e("OTP MESSSGE", message+" - "+sender);
//            }
//        }
//    };

//    private boolean checkAndRequestPermissions() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
//            int receiveSMS = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECEIVE_SMS);
//            int readSMS = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_SMS);
//            List<String> listPermissionsNeeded = new ArrayList<>();
//            if (receiveSMS != PackageManager.PERMISSION_GRANTED) {
//                listPermissionsNeeded.add(Manifest.permission.RECEIVE_SMS);
//            }
//            if (readSMS != PackageManager.PERMISSION_GRANTED) {
//                listPermissionsNeeded.add(android.Manifest.permission.READ_SMS);
//            }
//            if (!listPermissionsNeeded.isEmpty()) {
//                ActivityCompat.requestPermissions(this,
//                        listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
//                return false;
//            }
//            return true;
//        }
//        return true;
//
//    }

//    public String parseCode(String message) {
//        message = message.replaceAll("[^0-9]", "");
//        return message;
//    }

    private void resendCode() {
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("email",Wong.getEmail());
        map.put("phoneNumber",Wong.getHp());
        map.put("otpVia",Wong.getOtp_via());
        String params= new JSONObject(map).toString();

        RegistrationTask task = new RegistrationTask(getApplicationContext(), this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String desc=json.getString(content,"message");
                Toast.makeText(getApplicationContext(),desc,Toast.LENGTH_LONG).show();
                new CountDownTimer(60000, 1000) {

                    public void onTick(long millisUntilFinished) {
                        tvTimer.setText("Kirim ulang kode : " + millisUntilFinished / 1000);
                        btnChat.setVisibility(View.GONE);
                        // logic to set the EditText could go here
                    }

                    public void onFinish() {
                        if(totalResend < 3) {
                            tvTimer.setText("Tidak dapat kode? Klik ");
                            btnChat.setVisibility(View.VISIBLE);
                        }else{
                            tvTimer.setText("Tidak dapat kode? Ubah Verifikasi ");
                            Wong.setOtp_via("WhatsApp");
                            btnChat.setVisibility(View.VISIBLE);
                        }
                    }

                }.start();
            }

            @Override
            public void onFailure(Exception e) {
                showDialog(e.getMessage());
            }

        });

        task.execute("registration/user/verification/resend",params);

    }

    private void verifikasi(String pin) {
        int pinsize=pin.length();
        if(pinsize<6){
            showMsg("Masukan kode verifikasi 6 angka");
            return;
        }

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("email",Wong.getEmail());
        map.put("phoneNumber",Wong.getHp());
        map.put("otpVia",Wong.getOtp_via());
        map.put("pin_verification",pin);
        String params = new JSONObject(map).toString();
        RegistrationTask task = new RegistrationTask(VerifikasiRegActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                String desc=json.getString(content,"message");
                if(rc.equals("0000")) {
                    otpTextView.showSuccess();	// shows the success state to the user (can be set a bar color or drawable)
                    String idmerc=desc;
                    String uniq=pin;
                    Wong.setIdmerch(idmerc);
                    Wong.setUniq(uniq);

                    updateUserProfil();
                    updateBiodata();
                }else{
                    otpTextView.showError();	// shows the success state to the user (can be set a bar color or drawable)
                    otpTextView.resetState();	// brings the views back to default state (the state it was at input)
                    Toast.makeText(VerifikasiRegActivity.this,desc,Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Exception e) {
                otpTextView.showError();	// shows the success state to the user (can be set a bar color or drawable)
                otpTextView.resetState();	// brings the views back to default state (the state it was at input)
            }

        });
        task.execute("registration/user/verification",params);
    }

    private void updateUserProfil(){

        String userid=Wong.getEmail();
        DatabaseHelper dbHelper=new DatabaseHelper(VerifikasiRegActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            String strSQL = "UPDATE "+ Profil.PROFIL_TABLE+" SET "+Profil.PROFIL_USERID+" ='"+userid+"' ";

            db.execSQL(strSQL);
        }catch (Exception e){
            Log.d("error",e.toString());
        }
    }

    private void updateBiodata(){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("email",Wong.getEmail());
        map.put("id_merchant",Wong.getIdmerch());
        map.put("nameMerchant", Wong.getMerchant());
        map.put("phoneNumber",Wong.getHp());
        map.put("address", Wong.getAlamat());
        map.put("group", "ams");
        map.put("pin_verification", Wong.getUniq());
        String params= new JSONObject(map).toString();
        RegistrationTask task = new RegistrationTask(VerifikasiRegActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                String desc=json.getString(content,"message");
                if(rc.equals("0000")) {
                    login();
                }else{
                    Toast.makeText(VerifikasiRegActivity.this,desc,Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Exception e) {
                showDialog(e.getMessage());
            }

        });
        task.execute("registration/user/biodata", params);
    }

    private void showDialog(String pesan){
        Toast toast = Toast.makeText(VerifikasiRegActivity.this,pesan, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP, 25, 400);
        toast.show();
        finish();
    }

    private void login() {
        String user= Wong.getEmail();
        String pass= Wong.getPassword();
        final ProgressBar pbar=new PBarLinear(this,rootLayout);
        LoginTask task = new LoginTask(VerifikasiRegActivity.this,VerifikasiRegActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc= json.getString(content, "rc");
                if(rc.equals("0000")) {
                    String idmerc=json.getString(content,"id_merchant");
                    String name=json.getString(content,"name_merchant");
                    String user_key=json.getString(content,"token");
                    String type_merchant=json.getString(content,"type_merchant");
                    //String topiStatus=xml.getItem(content,"topi_status");
                    String topiStatus="0";

                    Wong.setIdmerch(idmerc);
                    Wong.setMerchant(name);
                    Wong.setUser_key(user_key);
                    Wong.setTypeMerchant(type_merchant);
                    Wong.setTopiStatus(topiStatus);

                    String email=user;
                    String passs=pass;
                    Wong.setEmail(email);
                    Wong.setPassword(passs);

                    Wong.setUserLogin(true);

                    Intent intent=new Intent(VerifikasiRegActivity.this,DashboardActivity.class);
                    startActivity(intent);
                    finish();
                }else{
                    String desc=json.getString(content,"message");
                    Toast.makeText(VerifikasiRegActivity.this,desc,Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Exception e) {
                Toast.makeText(getApplicationContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }

        });
        task.execute(user,pass, Integer.toString(LoginMethod.EMAIL_PASSWORD));
    }
}