package com.starpoin.pay;


import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link ChatFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BantuanFragment extends Fragment implements View.OnClickListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private View view;
    private LinearLayout lyWhatsapp, lyChat, lyEmail;
    private TextView tvWhatsapp, tvChat, tvEmail;
    private ImageView ivWhatsapp, ivChat, ivEmail;

    public BantuanFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ChatFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ChatFragment newInstance(String param1, String param2) {
        ChatFragment fragment = new ChatFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.bantuan_fragment, container, false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getActivity().getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor("#0F78C9"));
        }

        lyWhatsapp = view.findViewById(R.id.lyWhatsapp);
        lyWhatsapp.setOnClickListener(this);
        lyChat = view.findViewById(R.id.lyChat);
        lyChat.setOnClickListener(this);
        lyEmail = view.findViewById(R.id.lyEmail);
        lyEmail.setOnClickListener(this);

        tvWhatsapp = view.findViewById(R.id.tvWhatsapp);
        tvWhatsapp.setOnClickListener(this);
        tvChat = view.findViewById(R.id.tvChat);
        tvChat.setOnClickListener(this);
        tvEmail = view.findViewById(R.id.tvEmail);
        tvEmail.setOnClickListener(this);

        ivWhatsapp = view.findViewById(R.id.ivWhatsapp);
        ivWhatsapp.setOnClickListener(this);
        ivChat = view.findViewById(R.id.ivChat);
        ivChat.setOnClickListener(this);
        ivEmail = view.findViewById(R.id.ivEmail);
        ivEmail.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvEmail:
            case R.id.ivEmail:
            case R.id.lyEmail:
                Intent emailIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:cs.bitplus@gmail.com"));
                try {
                    startActivity(emailIntent);
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(requireContext(), "Aplikasi email tidak tersedia", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.tvWhatsapp:
            case R.id.ivWhatsapp:
            case R.id.lyWhatsapp:
                String phoneNumber = "6281222763146"; // Ganti dengan nomor telepon Anda
                String body = "Hai, helpdesk mohon bantuanya..";
                Uri uri = Uri.parse("https://api.whatsapp.com/send?phone="+phoneNumber+"&text="+body);
                Intent whatsappIntent = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    startActivity(whatsappIntent);
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(getContext(), "WhatsApp belum di install.", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.tvChat:
            case R.id.ivChat:
            case R.id.lyChat:
                startActivity(new Intent(getActivity(), ChatActivity.class));
                break;
        }
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
