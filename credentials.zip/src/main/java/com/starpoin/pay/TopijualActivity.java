package com.starpoin.pay;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.PBar;
import com.starpoin.pay.task.TopiPrinterTask;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.topi.DataProduk;
import com.starpoin.pay.topi.Jual;
import com.starpoin.pay.topi.Produk;
import com.starpoin.pay.topi.adapter.JualAdapter;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import malik.org.json.JSONObject;

public class TopijualActivity extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;
    private AutoCompleteTextView etProduk;
    private EditText etQty;
    private Button btnScan,btnTambah,btnBayar;
    private TextView tvTotal;
    private int REQUEST_CODE=1;
    private Produk SELECTED_PRODUK;
    private String noNota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topijual);

        setTitle("Penjualan");

        rootLayout=findViewById(R.id.rootLayout);

        etProduk=findViewById(R.id.etProduk);
        etQty=findViewById(R.id.etQty);

        btnScan=findViewById(R.id.btnScan);
        btnScan.setOnClickListener(this);

        btnTambah=findViewById(R.id.btnTambah);
        btnTambah.setOnClickListener(this);

        btnBayar=findViewById(R.id.btnBayar);
        btnBayar.setOnClickListener(this);

        tvTotal=findViewById(R.id.tvTotal);

        List<Produk> list=new DataProduk().getListProduk(TopijualActivity.this);
        ArrayAdapter<Produk> adapterProduk=new ArrayAdapter<>(TopijualActivity.this,R.layout.support_simple_spinner_dropdown_item,list);
        etProduk.setAdapter(adapterProduk);
        etProduk.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                SELECTED_PRODUK =(Produk) parent.getItemAtPosition(position);
                String kode=SELECTED_PRODUK.getKode_produk();
                etProduk.setText(kode);

            }
        });

        setListJual();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.topi_jual_menu, menu);

        //MenuInflater inflater = getMenuInflater();
        //inflater.inflate(R.menu.topi_produk_menu, menu);
        //MenuItem itemRefresh=menu.findItem(R.id.refresh);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.print:
                printUlang();
                return true;
            case R.id.reset:
                new Jual().clearItem(TopijualActivity.this);
                setListJual();

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnScan:
                Intent intent = new Intent(this, ScanBarcodeActivity.class);
                startActivityForResult(intent, REQUEST_CODE);

                break;
            case R.id.btnTambah:
                tambahItem();
                break;
            case R.id.btnBayar:
                showTunai();
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Check that it is the SecondActivity with an OK result
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {

                // Get String data from Intent
                String kode_barcode = data.getStringExtra("barcode");
                etProduk.setText(kode_barcode);
            }
        }
    }

    private void setListJual(){
        ArrayList<Jual> listJual=new Jual().listJual(TopijualActivity.this);
        JualAdapter adapter=new JualAdapter(TopijualActivity.this,R.layout.topi_jual_adapter,listJual);
        ListView listview=findViewById(R.id.listview);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Jual jual=(Jual)parent.getItemAtPosition(position);

                updateItem(jual);
            }
        });
        int total=0;
        for(Jual j:listJual){
            int hj=Integer.parseInt(j.getHarga_jual());
            int qty=Integer.parseInt(j.getQty());
            int sub=hj*qty;
            total+=sub;
        }
        DecimalFormat df=new DecimalFormat("#,##0");
        //TextView tvTotal=findViewById(R.id.tvTotal);
        tvTotal.setText(df.format(total));

        int rows=listJual.size();
        if(rows>=1){
            if(!btnBayar.isEnabled()){
                btnBayar.setEnabled(true);
            }
        }else{
            btnBayar.setEnabled(false);
        }
    }

    private void tambahItem(){
        String kode=etProduk.getText().toString().trim();
        String qty=etQty.getText().toString().trim().replaceAll("\\.","").replaceAll(",","");

        if(kode.length()<1){
            showMsg("Produk belum sesuai");
            return;
        }
        if(qty.length()<1){
            showMsg("Qty belum diisi");
            return;
        }

        Produk prod=new DataProduk().getDataByKode(TopijualActivity.this,kode);

        if(prod==null){
            showMsg("Produk belum terdaftar");
            return;
        }
        String nama_produk=prod.getNama_produk();
        String satuan=prod.getSatuan();
        String hb=prod.getHarga_beli();
        String hj=prod.getHarga_jual();
        String idmerc= Wong.getIdmerch();

        Jual jual=new Jual();
        jual.setId_merchant(idmerc);
        jual.setKode_produk(kode);
        jual.setNama_produk(nama_produk);
        jual.setSatuan(satuan);
        jual.setQty(qty);
        jual.setHarga_beli(hb);
        jual.setHarga_jual(hj);

        String str=new Jual().addItemJual(TopijualActivity.this,jual);
        if(str.equals("00")){
            setListJual();
            etProduk.setText("");
            etQty.setText("");
        }else{
            showMsg(str);
        }
    }

    private void updateItem(Jual jual){
        final BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.topi_update_item);
        EditText etQty=dialog.findViewById(R.id.etQty);
        etQty.setText(jual.getQty());
        Button btnHapus=dialog.findViewById(R.id.btnHapus);
        btnHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                String msg=new Jual().deleteItem(TopijualActivity.this,jual.getId());
                if(msg.equals("00")){
                    setListJual();
                }
            }
        });

        Button btnUpdate=dialog.findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                String newqty=etQty.getText().toString().trim().replaceAll("\\.","").replaceAll(",","");
                String msg=new Jual().updateItem(TopijualActivity.this,jual,newqty);
                if(msg.equals("00")){
                    setListJual();
                }
            }
        });

        Button btnBatal=dialog.findViewById(R.id.btnBatal);
        btnBatal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        dialog.show();
    }

    private void showTunai(){
        final BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.topi_bayar_layout);
        EditText etTunai=dialog.findViewById(R.id.etTunai);
        etTunai.setText(tvTotal.getText().toString());
        etTunai.addTextChangedListener(new TextWatcher(){

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                etTunai.removeTextChangedListener(this);

                try {
                    String originalString = s.toString();

                    Long longval;
                    if (originalString.contains(",")) {
                        originalString = originalString.replaceAll(",", "");
                    }
                    longval = Long.parseLong(originalString);

                    DecimalFormat formatter = (DecimalFormat) NumberFormat.getInstance(Locale.US);
                    //DecimalFormat formatter=new DecimalFormat("#,##0");
                    formatter.applyPattern("#,###,###,###");
                    String formattedString = formatter.format(longval);

                    //setting text after format to EditText
                    etTunai.setText(formattedString);
                    etTunai.setSelection(etTunai.getText().length());
                } catch (NumberFormatException nfe) {
                    nfe.printStackTrace();
                }

                etTunai.addTextChangedListener(this);

            }
        });



        Button btnOk=dialog.findViewById(R.id.btnOk);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                String tunai=etTunai.getText().toString().trim().replaceAll("\\.","").replaceAll(",","");
                simpanTrans(tunai);
            }
        });

        Button btnBatal=dialog.findViewById(R.id.btnBatal);
        btnBatal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        dialog.show();
    }

    private void simpanTrans(String tunai){
        ArrayList<Jual> listJual=new Jual().listJual(TopijualActivity.this);

        Map<String,Object> maplist=new HashMap<>();
        maplist.put("item",listJual);
        JSONObject job=new JSONObject(maplist);

        Map<String,Object> map=new HashMap<>();
        map.put("q","add_jual");
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("json",job.toString());
        String params="Topi"+new Params().buildParams(map);
        TransTask task = new TransTask(TopijualActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JSONObject job=new JSONObject(content);

                String rc=job.getString("rc");
                if(rc.equals("0000")){
                    noNota=job.getString("id_transaksi");
                    confirmCetak(listJual,Integer.parseInt(tunai));
                    updateStokLocal(listJual);
                    new Jual().clearItem(TopijualActivity.this);
                    setListJual();
                }else{
                    String desc=job.getString("desc");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void updateStokLocal(ArrayList<Jual> listJual){
        ArrayList<Produk> list=new ArrayList<>();
        for(Jual jual:listJual){
            Produk prod=new Produk();
            prod.setKode_produk(jual.getKode_produk());
            prod.setQty(jual.getQty());
            list.add(prod);
        }
        new DataProduk().updateLocalStok(TopijualActivity.this,list);
    }

    private void confirmCetak(ArrayList<Jual> list,int tunai){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Konfirmasi");
        builder.setMessage("Cetak Struk ?");

        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();

                String struk=new Jual().buildStruke(TopijualActivity.this,noNota,list,tunai);
                final ProgressBar pbar=new PBar(TopijualActivity.this,rootLayout);
                TopiPrinterTask task = new TopiPrinterTask(TopijualActivity.this,pbar, new OnEventListener<String>() {
                    @Override
                    public void onSuccess(String content) {
                        /*if(!content.equals("1")){
                            showMsg(content);
                        }*/
                    }

                    @Override
                    public void onFailure(Exception e) {
                        showMsg(e.getMessage());
                    }

                });
                task.execute(struk);
            }
        });

        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {


                //resetData();
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();

    }

    private void printUlang(){
        String lastStruke=new Jual().getLastStruk(TopijualActivity.this);
        final ProgressBar pbar=new PBar(TopijualActivity.this,rootLayout);
        TopiPrinterTask task = new TopiPrinterTask(TopijualActivity.this,pbar, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                /*if(!content.equals("1")){
                    showMsg(content);
                }*/
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(lastStruke);
    }
}