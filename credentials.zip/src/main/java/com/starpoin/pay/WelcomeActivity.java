package com.starpoin.pay;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.LoadingHelper;
import com.starpoin.pay.helper.Notifikasi;
import com.starpoin.pay.model.ConnectionQuality;
import com.starpoin.pay.task.NetworkTask;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OnNetworkListener;
import com.starpoin.pay.task.SilentTask;
import com.starpoin.pay.util.PicassoTrustAll;
import com.starpoin.pay.util.Wong;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class WelcomeActivity extends AppCompatActivity implements View.OnClickListener{

    //private static  NotificationUtils notificationUtils;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    String[] permissionsRequired = new String[]{
            Manifest.permission.VIBRATE,
            Manifest.permission.RECEIVE_BOOT_COMPLETED,
            Manifest.permission.ACCESS_NOTIFICATION_POLICY,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.INTERNET,
            Manifest.permission.USE_BIOMETRIC,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.GET_ACCOUNTS,
            Manifest.permission.READ_PHONE_STATE,
    };

    private SharedPreferences permissionStatus;
    private Button btnDaftar,btnLogin;
    private LinearLayout layoutChat;
    private TextView layoutFaq, tvTitle;
    private ImageView imgLanding;
    private ImageButton iBConnectionStatus;
    private Handler handler;
    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //set notification
        //notificationUtils = new NotificationUtils(this);

        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT){
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_landing);

        if(getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        if(Build.VERSION.SDK_INT >= 23) {
            SharedPreferences pref = getSharedPreferences("pref",MODE_PRIVATE);
            if (!pref.getBoolean("welcomed",false)){
                startActivity(new Intent(this, OnBoardingActivity.class));
                pref.edit().putBoolean("welcomed",true).apply();
            }
        }

        btnDaftar=(Button) findViewById(R.id.btnDaftar);
        btnDaftar.setOnClickListener(this);
        btnLogin=(Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        layoutChat=(LinearLayout) findViewById(R.id.layoutChat);
        layoutChat.setOnClickListener(this);
        layoutFaq=(TextView) findViewById(R.id.layoutFaq);
        layoutFaq.setOnClickListener(this);
        imgLanding = (ImageView) findViewById(R.id.imgLanding);
        tvTitle = findViewById(R.id.tvTitle);

        iBConnectionStatus = findViewById(R.id.iBConnectionStatus);

        permissionStatus = getSharedPreferences("permissionStatus",MODE_PRIVATE);
        if(ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[2]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[3]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[4]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[5]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[6]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[7]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[8]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[9]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[10]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[11]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[12]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[13]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[14]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[15]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[16]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(WelcomeActivity.this, permissionsRequired[17]) != PackageManager.PERMISSION_GRANTED
        ){

            if(ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[0])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[1])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[2])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[3])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[4])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[5])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[6])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[7])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[8])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[9])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[10])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[11])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[12])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[13])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[14])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[16])
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,permissionsRequired[17])

            ){

                FancyAlertDialog.Builder
                        .with(this)
                        .setTitle("Berikan izin akses")
                        .setBackgroundColorRes(R.color.warning)  // for @ColorRes use setBackgroundColorRes(R.color.colorvalue)
                        .setMessage("Perlu beberapa izin")
                        .setNegativeBtnText("Izinkan")
                        .setPositiveBtnBackground(Color.parseColor("#0F78C9"))  // for @ColorRes use setPositiveBtnBackgroundRes(R.color.colorvalue)
                        .setPositiveBtnText("Tunda")
                        .setNegativeBtnBackgroundRes(R.color.common_google_signin_btn_text_light)  // for @ColorRes use setNegativeBtnBackgroundRes(R.color.colorvalue)
                        .setAnimation(Animation.POP)
                        .isCancellable(true)
                        .setIcon(R.drawable.ic_check_24, View.INVISIBLE)
                        .onPositiveClicked(dialog -> ActivityCompat.requestPermissions(WelcomeActivity.this,permissionsRequired,PERMISSION_CALLBACK_CONSTANT))
                        .onNegativeClicked(dialog -> {
                            Toast.makeText(WelcomeActivity.this, "Izin ditunda", Toast.LENGTH_SHORT).show();
                        })
                        .build()
                        .show();
            } else {
                //just request the permission
                ActivityCompat.requestPermissions(WelcomeActivity.this,permissionsRequired,PERMISSION_CALLBACK_CONSTANT);
            }

            SharedPreferences.Editor editor = permissionStatus.edit();
            editor.putBoolean(permissionsRequired[0],true);
            editor.commit();

            proceedAfterPermission();

        }else {
            //You already have the permission, just go ahead.
            proceedAfterPermission();
        }

        AssetManager am=this.getAssets();
        Wong.setAssetManager(am);

        String urlProd=this.getString(R.string.url_prod);
        Wong.setUrlProd(urlProd);

        String auth=this.getString(R.string.authority);
        Wong.setAuthority(auth);

        String dir=this.getFilesDir().getPath();
        String dirdb="/payplus/epay/db";
        Wong.setDBdir(dir+dirdb);
        //Log.i("infopath",dirdb);

        if(Build.VERSION.SDK_INT >= 23) {
            SharedPreferences login = getSharedPreferences("Login", 0);
            if(login.getString("pin", null) != null) {
                Intent intent = new Intent(this, PinScreenActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            } //276704

            System.out.println(login.getString("pin", null));
        }

        TelephonyManager tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
        String deviceid = null;
        try {
            Bundle bundle = getIntent().getExtras();
            if(bundle != null)  {
                System.out.println("Bundle != null");
                insertNotificationFromBackground(bundle);
            }else{
                System.out.println("Bundle == null");
            }
            deviceid = tm.getDeviceId();
            Wong.setDevice(deviceid);
        }catch (Exception e){
            e.printStackTrace();
        }finally {

        }

    }

    private void proceedAfterPermission() {
        getImageLanding();
    }

    private void getImageLanding() {
        LoadingHelper loading = new LoadingHelper(this);
        loading.showLoadingOverlay();
        SilentTask task = new SilentTask(WelcomeActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String object) {
                try {
                    JSONObject response = new JSONObject(object);
                    JSONArray item = response.getJSONArray("data");
                    String imageUrls = null, titleImage = "Mudah dan Menguntungkan";

                    for(int i = 0; i < item.length(); i++) {
                        String Title = (item.getJSONObject(i).getString("title"));
                        String ImageUrl = (item.getJSONObject(i).getString("image_url"));
                        titleImage = Title;
                        imageUrls = ImageUrl;
                    }

                    tvTitle.setText(titleImage);

                    PicassoTrustAll.getInstance(getApplicationContext())
                            .load(imageUrls)
                            .error(R.drawable.landing)
                            .into(imgLanding);

                }catch (Exception e) {
                    e.printStackTrace();
                    imgLanding.setImageResource(R.drawable.landing);
                    tvTitle.setText("Mudah dan Menguntungkan");
                }finally {
                    loading.hideLoadingOverlay();
                }

            }

            @Override
            public void onFailure(Exception e) {
                e.printStackTrace();
                imgLanding.setImageResource(R.drawable.landing);
                tvTitle.setText("Mudah dan Menguntungkan");
                loading.hideLoadingOverlay();
            }
        });

        task.execute("banner/landing/bitplus");
    }

    @Override
    public void onClick(View view) {
        Intent intent=null;
        switch (view.getId()) {

            case R.id.btnDaftar:
                intent=new Intent(WelcomeActivity.this,RegistrasiActivity.class);
                intent.removeExtra("email");
                intent.removeExtra("name_merchant");
                break;
            case R.id.btnLogin:
                intent=new Intent(WelcomeActivity.this,MlebuActivity.class);
                break;
            case R.id.layoutChat:
                intent=new Intent(WelcomeActivity.this,ChatActivity.class);
                break;
            case R.id.layoutFaq:
                intent=new Intent(WelcomeActivity.this,FaqActivity.class);
                break;
        }
        startActivity(intent);
    }

    private void reCheckConnection() {
        NetworkTask task = new NetworkTask(this, new OnNetworkListener<ConnectionQuality>() {
            @Override
            public void onSuccess(ConnectionQuality quality) {
                updateConnectionIndicator(quality);
            }

            @Override
            public void onFailure(Exception e) {
                updateConnectionIndicator(ConnectionQuality.POOR);
            }
        });

        task.execute();

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(handler != null) {
            handler.removeCallbacks(runnable);
        }
    }
    @Override
    protected void onStop() {
        super.onStop();
        if(handler != null) {
            handler.removeCallbacks(runnable);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                reCheckConnection();
                // Jadwalkan pengecekan berikutnya setelah 10 detik
                handler.postDelayed(this, 3000);
            }
        };

        handler.postDelayed(runnable, 3000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(handler != null) {
            handler.removeCallbacks(runnable);
        }
    }

    private void updateConnectionIndicator(ConnectionQuality quality) {
        switch (quality) {
            case GOOD:
                iBConnectionStatus.setBackgroundResource(R.drawable.circle_green);
                break;
            case MODERATE:
                iBConnectionStatus.setBackgroundResource(R.drawable.circle_yellow);
                break;
            case POOR:
                iBConnectionStatus.setBackgroundResource(R.drawable.circle_red);
                break;
            default:
                // Default case, jika quality tidak sesuai dengan nilai yang diharapkan.
                // Anda dapat mengatur tindakan default yang sesuai.
                break;
        }
    }

    private void insertNotificationFromBackground(Bundle bundle) {
        if(bundle.getString("action").equals("SHOW_DETAILS")) /*This indicates activity is launched from notification, not directly*/
        {
            //Data retrieved from notification payload send
            String title = bundle.getString("title");
            String body = bundle.getString("body");

            SharedPreferences sp1=getSharedPreferences("Login",0);
            String unm  = sp1.getString("unm", null);
            String pass = sp1.getString("pas", null);
            String idm  = sp1.getString("idm", null);

            if(unm != null && pass != null && idm != null) {
                //insert to sqlite
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = new Date();
                String dateNow = dateFormat.format(date);
                DatabaseHelper dbHelper=new DatabaseHelper(WelcomeActivity.this);
                SQLiteDatabase db=dbHelper.getWritableDatabase();
                try{
                    ContentValues cv = new ContentValues();
                    cv.put("id_message", this.getString(R.string.default_notification_channel_id));
                    cv.put("title", title);
                    cv.put("message", body);
                    cv.put("id_merchant", idm);
                    cv.put("waktu", dateNow);
                    cv.put("status", 0);

                    new Notifikasi().insertNotification(db, cv);
                }catch (Exception e){
                    Log.d("error",e.toString());
                }finally {
                    try{
                        db.close();
                    }catch (Exception se){

                    }
                }
            }
        }
    }

    public void initialApp() {
        AssetManager am=this.getAssets();
        Wong.setAssetManager(am);

        String urlProd=this.getString(R.string.url_prod);
        Wong.setUrlProd(urlProd);

        String auth=this.getString(R.string.authority);
        Wong.setAuthority(auth);

        String dir=this.getFilesDir().getPath();
        String dirdb="/payplus/epay/db";
        Wong.setDBdir(dir+dirdb);
        //Log.i("infopath",dirdb);

        TelephonyManager tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
        String deviceid = null;
        try {
            deviceid = tm.getDeviceId();
            Wong.setDevice(deviceid);
            //Log.d("devid",deviceid);
        }catch (SecurityException e){
            //e.printStackTrace();
        }
    }
}