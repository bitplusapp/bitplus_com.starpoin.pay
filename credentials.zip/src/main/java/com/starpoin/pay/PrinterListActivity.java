package com.starpoin.pay;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.util.PrinterItem;

import java.util.ArrayList;
import java.util.Set;

public class PrinterListActivity extends AbaseActivity implements View.OnClickListener {

    private BluetoothAdapter bluetoothAdapter;
    private Button btnRefresh;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_list);

        proceedAfterPermission();

        setTitle("Set Printer");

    }

    private void proceedAfterPermission(){
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        btnRefresh=(Button) findViewById(R.id.btnRefresh);
        btnRefresh.setOnClickListener(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ECLAIR) {
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent,2);
            }else{
                cariPerangkatTerpasang();
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnRefresh:
                cariPerangkatTerpasang();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        try{
            if(bluetoothAdapter.isDiscovering()){

                bluetoothAdapter.cancelDiscovery();
            }
        }catch (Exception e){

        }

        finish();
    }

    private void cariPerangkatTerpasang(){
        ArrayList<PrinterItem> al=new ArrayList<>();


        try{
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();


            if(pairedDevices.size() > 0){

                for(BluetoothDevice device : pairedDevices){

                    String deviceName = device.getName(); // MAC address
                    String deviceHardwareAddress = device.getAddress(); // MAC address
                    PrinterItem e=new PrinterItem();
                    e.setNama(deviceName);
                    e.setAdres(deviceHardwareAddress);
                    al.add(e);
                }


            }else{
                String msg="Printer tidak ditemukan , pasangkan printer melalui pengaturan bluetooth di android";
                PrinterItem e=new PrinterItem();
                e.setNama(msg);
                al.add(e);
                //return;
            }
        }catch(Exception ex){

            PrinterItem e=new PrinterItem();
            e.setNama(e.toString());
            al.add(e);
        }

        ListDataAdapter listAdapter=new ListDataAdapter(this,al);

        ListView listView=(ListView) findViewById(R.id.list_printer);
        listView.setAdapter(listAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PrinterItem l = (PrinterItem) parent.getItemAtPosition(position);
                String nama=l.getNama();
                String adress=l.getAdres();
                updatePrinter(nama,adress);

                Toast toast = Toast.makeText(PrinterListActivity.this,
                        "Setting printer sukses", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP, 25, 400);
                toast.show();


                finish();

            }
        });


    }

    public void updatePrinter(String pname,String puuid){

        DatabaseHelper dbHelper=new DatabaseHelper(PrinterListActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            //String strSQL = "UPDATE "+ Profil.PROFIL_TABLE+" SET "+Profil.PROFIL_PRINTER+" ='"+pname+"' , "+Profil.PROFIL_PRINTER_UUID+"='"+puuid+"' ";
            String strSQL = "UPDATE tprinter set printer_uuid='"+puuid+"', printer='"+pname+"'";

            db.execSQL(strSQL);
        }catch (Exception e){
            //Log.d("error",e.toString());
        }finally {
            try{
                db.close();
            }catch (Exception se){

            }

        }
    }



    private class ListDataAdapter extends ArrayAdapter<PrinterItem> {

        private class ViewHolder {
            TextView nama;
        }

        public ListDataAdapter(Context context, ArrayList<PrinterItem> singleList) {
            super(context, R.layout.printerlist_adapter, singleList);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            PrinterItem user = getItem(position);
            ViewHolder viewHolder;
            if (convertView == null) {
                viewHolder = new ViewHolder();
                LayoutInflater inflater = LayoutInflater.from(getContext());
                convertView = inflater.inflate(R.layout.printerlist_adapter, parent, false);
                viewHolder.nama = (TextView) convertView.findViewById(R.id.tvName);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.nama.setText(user.getNama());
            return convertView;
        }
    }
}