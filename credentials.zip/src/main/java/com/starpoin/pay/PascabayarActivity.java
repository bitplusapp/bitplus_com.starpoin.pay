package com.starpoin.pay;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.PascabayarAdapter;
import com.starpoin.pay.model.PascaBayar;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;

import java.util.ArrayList;

public class PascabayarActivity extends AbaseActivity implements View.OnClickListener {

    private final static int PICK_CONTACT = 0;
    private ConstraintLayout rootLayout;
    private PascaBayar selectedProvider;
    private EditText etNomor;
    private Button btnContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pascabayar);

        setBarTitle("Paska Bayar");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        etNomor=(EditText) findViewById(R.id.etNomor);


        btnContact=(Button) findViewById(R.id.btnContact);
        btnContact.setOnClickListener(this);

        viewProvider();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnContact:
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
                startActivityForResult(intent, PICK_CONTACT);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            switch (requestCode) {
                case (PICK_CONTACT):
                    if (resultCode == RESULT_OK) {
                        Cursor cursor = getContentResolver().query(data.getData(), new String[] {ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);

                        // True if the cursor is not empty
                        cursor.moveToFirst();
                        String number = cursor.getString((int) 0);

                        if (number.length() > 0 && number.substring(0, 1).equals("+")) {
                            number = "0" + number.substring(3);
                        }

                        etNomor.setText(number.replace("-", "").replace(" ", ""));

                    }

                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void viewProvider(){
        ArrayList<PascaBayar> listProvider=new PascaBayar().listProvider();
        PascabayarAdapter adapter=new PascabayarAdapter(this,listProvider);
        GridLayoutManager layoutManager=new GridLayoutManager(this,3);
        RecyclerView rvDenom=findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);

        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();

                selectedProvider=listProvider.get(position);
                String no=etNomor.getText().toString().trim();
                String idproduk=selectedProvider.getKode();
                inquery(no,idproduk);
            }
        });
    }

    private void inquery(String no,String idProduk){
        if(no.length()<8){
            showMsg("Nomor Tidak Sesuai");
            return;
        }

        String params=new PascaBayar().paramsInq(no,idProduk);
        TransTask task = new TransTask(PascabayarActivity.this, PascabayarActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")){
                    String trxid=json.getObjectWithString(content,"data", "ref_id");
                    double amount =Double.parseDouble(json.getObjectWithString(content,"data", "amount"));
                    String admin = json.getObjectWithString(content,"data", "admin");
                    double nominal = Double.parseDouble(json.getObjectWithString(content,"data", "tagihan"));
                    String time = json.getObjectWithString(content,"data", "time");
                    Intent intent=new Intent(PascabayarActivity.this, ResponseActivity.class);
                    intent.putExtra("produk", Produk.PASCABAYAR);
                    intent.putExtra("result", content);
                    intent.putExtra("nominal", nominal);
                    intent.putExtra("amount", amount);
                    intent.putExtra("trxid", trxid);
                    intent.putExtra("admin", admin);
                    intent.putExtra("time", time);
                    intent.putExtra("noid", no);
                    intent.putExtra("additional", idProduk); //tambahan parameter
                    startActivity(intent);

                    etNomor.setText("");
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);

    }
}