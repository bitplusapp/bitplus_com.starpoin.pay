package com.starpoin.pay;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.adapter.ListTopupAdapter;
import com.starpoin.pay.adapter.TopupDenom;
import com.starpoin.pay.adapter.TopupProvider;
import com.starpoin.pay.model.Pulsa;
import com.starpoin.pay.model.Topup;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class TopupActivity extends AbaseActivity implements View.OnClickListener {

    private final static int PICK_CONTACT = 0;
    private ConstraintLayout rootLayout;

    private Topup selectedProv;
    private EditText etNomor;
    private Button btnContact, btnShowProduct;
    private String response;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topup);

        setBarTitle("Dompet Elektronik");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        etNomor=(EditText) findViewById(R.id.etNomor);

        btnContact=(Button) findViewById(R.id.btnContact);
        btnContact.setOnClickListener(this);

        btnShowProduct = findViewById(R.id.btnShowProduct);
        btnShowProduct.setOnClickListener(this);

        reqProvider();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnContact:
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
                startActivityForResult(intent, PICK_CONTACT);
                break;
            case R.id.btnShowProduct:
                showBottomSheetDialogProductList();
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            switch (requestCode) {
                case (PICK_CONTACT):
                    if (resultCode == RESULT_OK) {
                        Cursor cursor = getContentResolver().query(data.getData(), new String[] {ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);

                        // True if the cursor is not empty
                        cursor.moveToFirst();
                        String number = cursor.getString((int) 0);

                        if (number.length() > 0 && number.substring(0, 1).equals("+")) {
                            number = "0" + number.substring(3);
                        }

                        etNomor.setText(number.replace("-", "").replace(" ", ""));

                    }

                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void reqProvider(){

        String params = "products/voucher_group/topup";
        OtherTask task = new OtherTask(TopupActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                response = content;
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void showBottomSheetDialogProductList() {
        ArrayList<Topup> listProvider=new Topup().buildProviderJson(response);
        final BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.bottom_sheet_dialog_product);

        final ListView lv = dialog.findViewById(R.id.lvProduct);
        lv.setAdapter(new ListTopupAdapter(this, listProvider));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                selectedProv=listProvider.get(position);
                String prov=selectedProv.getProvider();
                btnShowProduct.setText(selectedProv.getProvider());
                reqDenom(prov);
                dialog.dismiss();
            }
        });
        // Get the height of the screen
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenHeight = displayMetrics.heightPixels;
        dialog.getBehavior().setPeekHeight(screenHeight);
        dialog.show();
    }

    private void viewProvider(String content){
        ArrayList<Topup> listProvider=new Topup().buildProviderJson(content);
        TopupProvider adapter=new TopupProvider(TopupActivity.this,listProvider);
        GridLayoutManager layoutManager=new GridLayoutManager(this,3);
        RecyclerView rvDenom=findViewById(R.id.rvDenom);

        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);
        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                selectedProv=listProvider.get(position);
                String prov=selectedProv.getProvider();
                reqDenom(prov);
            }
        });
    }

    private void reqDenom(String prov){
        String noid=etNomor.getText().toString().trim();
        if(noid.length()<10){
            showMsg("Nomor belum sesuai");
            return;
        }

        String params = "products/voucher_group/topup/"+prov;
        OtherTask task = new OtherTask(TopupActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                viewDenom(content);
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewDenom(String content){
        ArrayList<Topup> listDenom=new Topup().topupDenomList(content);
        TopupDenom adapter=new TopupDenom(TopupActivity.this,listDenom);
        GridLayoutManager layoutManager=new GridLayoutManager(this,3);

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.denom_layout);

        RecyclerView rvDenom=bottomSheetDialog.findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);

        Button btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });


        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                bottomSheetDialog.dismiss();
                inquery(listDenom.get(position));
            }
        });

        bottomSheetDialog.show();
    }

    private void inquery(Topup topup){
        String noid=etNomor.getText().toString().trim();
        String idproduk=topup.getKode();
        if(noid.length()<10){
            showMsg("Nomor belum sesuai");
            return;
        }

        Map<String,Object> map = new Pulsa().paramsInq(noid,idproduk,"topup");
        String params= new JSONObject(map).toString();
        String finalNo = noid;
        TransTask task = new TransTask(TopupActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")){
                    String trxid=json.getObjectWithString(content,"data", "ref_id");
                    double amount =Double.parseDouble(json.getObjectWithString(content,"data", "price"));
                    String admin = "0";
                    double nominal = amount;
                    String time = json.getObjectWithString(content,"data", "time");
                    String voucher_code = json.getObjectWithString(content,"data", "voucher_code");
                    Intent intent=new Intent(TopupActivity.this, ResponseActivity.class);
                    intent.putExtra("produk", Produk.TOPUP);
                    intent.putExtra("result", content);
                    intent.putExtra("nominal", nominal);
                    intent.putExtra("amount", amount);
                    intent.putExtra("trxid", trxid);
                    intent.putExtra("admin", admin);
                    intent.putExtra("time", time);
                    intent.putExtra("noid", finalNo);
                    intent.putExtra("additional", voucher_code); //tambahan parameter
                    startActivity(intent);

                    etNomor.setText("");
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

}