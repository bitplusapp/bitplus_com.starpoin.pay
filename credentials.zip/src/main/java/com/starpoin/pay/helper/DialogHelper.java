package com.starpoin.pay.helper;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

public class DialogHelper {
	public static void alert(Context context, String title, String message) {
        AlertDialog alert = new AlertDialog.Builder(context)
            .setCancelable(false)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", new OnClickListener() {

				public void onClick(DialogInterface arg0, int arg1) {
					// TODO Auto-generated method stub
					arg0.cancel();
				}
            }).create();
        alert.show();
    }

	public static void confirm(Context context, String title, String message, OnClickListener yesClicked) {
		AlertDialog alert = new AlertDialog.Builder(context)
	       .setCancelable(false)
	       .setTitle(title)
	       .setMessage(message)
	       .setPositiveButton("Ya", yesClicked)
	       .setNegativeButton("Tidak", new OnClickListener() {

				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					dialog.cancel();
				}
	       	
	       }).create();
		alert.show();
	}
}
