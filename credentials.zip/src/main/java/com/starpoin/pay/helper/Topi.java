package com.starpoin.pay.helper;

public class Topi {

    public static final String TOPI_PRODUK_CREATE="CREATE TABLE `topi_produk` (\n" +
            "  `id` INTEGER PRIMARY KEY AUTOINCREMENT ,\n" +
            "  `id_merchant` varchar(20) DEFAULT NULL,\n" +
            "  `kode_produk` varchar(30) DEFAULT NULL,\n" +
            "  `nama_produk` varchar(100) DEFAULT NULL,\n" +
            "  `satuan` varchar(20) DEFAULT NULL,\n" +
            "  `harga_beli` integer(8) DEFAULT NULL,\n" +
            "  `harga_jual` integer(8) DEFAULT NULL,\n" +
            "  `stok` integer(8) DEFAULT NULL,\n" +
            "  `lastupdate` datetime default current_timestamp)";

    public static final String TOPI_BELI_CREATE="CREATE TABLE `topi_beli` (\n" +
            "  `id` INTEGER PRIMARY KEY AUTOINCREMENT ,\n" +
            "  `id_merchant` varchar(20) DEFAULT NULL,\n" +
            "  `kode_produk` varchar(30) DEFAULT NULL,\n" +
            "  `nama_produk` varchar(100) DEFAULT NULL,\n" +
            "  `satuan` varchar(20) DEFAULT NULL,\n" +
            "  `harga_beli` integer(8) DEFAULT NULL,\n" +
            "  `qty` integer(8) DEFAULT NULL,\n" +
            "  `lastupdate` datetime default current_timestamp)";

    public static final String TOPI_RETUR_BELI_CREATE="CREATE TABLE `topi_retur_beli` (\n" +
            "  `id` INTEGER PRIMARY KEY AUTOINCREMENT ,\n" +
            "  `id_merchant` varchar(20) DEFAULT NULL,\n" +
            "  `kode_produk` varchar(30) DEFAULT NULL,\n" +
            "  `nama_produk` varchar(100) DEFAULT NULL,\n" +
            "  `satuan` varchar(20) DEFAULT NULL,\n" +
            "  `harga_beli` integer(8) DEFAULT NULL,\n" +
            "  `qty` integer(8) DEFAULT NULL,\n" +
            "  `lastupdate` datetime default current_timestamp)";

    public static final String TOPI_JUAL_CREATE="CREATE TABLE `topi_jual` (\n" +
            "  `id` INTEGER PRIMARY KEY AUTOINCREMENT ,\n" +
            "  `id_merchant` varchar(20) DEFAULT NULL,\n" +
            "  `kode_produk` varchar(30) DEFAULT NULL,\n" +
            "  `nama_produk` varchar(100) DEFAULT NULL,\n" +
            "  `satuan` varchar(20) DEFAULT NULL,\n" +
            "  `harga_beli` integer(8) DEFAULT NULL,\n" +
            "  `harga_jual` integer(8) DEFAULT NULL,\n" +
            "  `qty` integer(8) DEFAULT NULL,\n" +
            "  `laba_rugi` integer(8) DEFAULT NULL,\n" +
            "  `lastupdate` datetime default current_timestamp)";


    public static final String TOPI_RETUR_JUAL_CREATE="CREATE TABLE `topi_retur_jual` (\n" +
            "  `id` INTEGER PRIMARY KEY AUTOINCREMENT ,\n" +
            "  `id_merchant` varchar(20) DEFAULT NULL,\n" +
            "  `kode_produk` varchar(30) DEFAULT NULL,\n" +
            "  `nama_produk` varchar(100) DEFAULT NULL,\n" +
            "  `satuan` varchar(20) DEFAULT NULL,\n" +
            "  `harga_beli` integer(8) DEFAULT NULL,\n" +
            "  `harga_jual` integer(8) DEFAULT NULL,\n" +
            "  `qty` integer(8) DEFAULT NULL,\n" +
            "  `laba_rugi` integer(8) DEFAULT NULL,\n" +
            "  `lastupdate` datetime default current_timestamp)";
    // data cetak ulang terakhir transaksi
    public static final String TOPI_PROFIL_CREATE="CREATE TABLE IF NOT EXISTS `topi_profil` (\n" +
            "  `id` INTEGER PRIMARY KEY AUTOINCREMENT ,\n" +
            "  `nama_toko` varchar(50) DEFAULT NULL,\n" +
            "  `alamat` varchar(50) DEFAULT NULL,\n" +
            "  `pesan` varchar(50) DEFAULT NULL,\n" +
            "  `tgl_nota` varchar(20) DEFAULT NULL,\n" +//tgl nota terakhir transaksi
            "  `nomor_nota` varchar(20) DEFAULT NULL,\n" +//nomor nota penjualan terakhir transaksi
            "  `cetak_ulang` TEXT DEFAULT NULL)";

    public static final String TOPI_PROFIL_INSERT="INSERT INTO topi_profil " +
            "(nama_toko,alamat,pesan,tgl_nota,nomor_nota,cetak_ulang) VALUES('Nama Toko','Alamat Toko','pesan','0','0','0')";
}
