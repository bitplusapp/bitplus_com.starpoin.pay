package com.starpoin.pay.helper;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.github.ybq.android.spinkit.SpinKitView;
import com.github.ybq.android.spinkit.sprite.Sprite;
import com.github.ybq.android.spinkit.style.ThreeBounce;
import com.starpoin.pay.R;

public class LoadingHelper {
    private final Activity activity;
    private FrameLayout overlayLayout;

    public LoadingHelper(Activity activity) {
        this.activity = activity;
    }

    public void showLoadingOverlay() {
        // Cek jika overlay sudah ditampilkan sebelumnya
        if (overlayLayout != null) {
            return;
        }

        // Inflate layout untuk overlay
        LayoutInflater inflater = LayoutInflater.from(activity);
        View overlayView = inflater.inflate(R.layout.progress_bar_spin, null);

        // Setup Spinner
        SpinKitView spinKitView = overlayView.findViewById(R.id.spin_kit);
        Sprite doubleBounce = new ThreeBounce();
        spinKitView.setIndeterminateDrawable(doubleBounce);

        // Setup Layout Params
        ViewGroup.LayoutParams layoutParams =
                new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        // Tambahkan overlay ke activity
        overlayLayout = new FrameLayout(activity);
        overlayLayout.setLayoutParams(layoutParams);
        overlayLayout.addView(overlayView);
        activity.addContentView(overlayLayout, layoutParams);
        overlayLayout.setAlpha(0f);
        overlayLayout.setVisibility(View.VISIBLE);
        overlayLayout.animate()
                .alpha(1f)
                .setDuration(200)
                .setListener(null);
    }

    public void hideLoadingOverlay() {
        // Cek jika overlay sudah ditampilkan sebelumnya
        if (overlayLayout == null) {
            return;
        }

        // Hapus overlay dari activity
//        ((ViewGroup) overlayLayout.getParent()).removeView(overlayLayout);
//        overlayLayout = null;
        overlayLayout.animate()
                .alpha(0f)
                .setDuration(200)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        ((ViewGroup) overlayLayout.getParent()).removeView(overlayLayout);
                        overlayLayout = null;
                    }
                });

    }
}
