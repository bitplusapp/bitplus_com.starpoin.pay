package com.starpoin.pay.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

	private static final String DATABASE_NAME = "payment.db";
	private static final int DATABASE_VERSION = 5;
	private Context context;
	public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
		this.context=context;
    }


	@Override
	public void onCreate(SQLiteDatabase db) {

		db.execSQL(Profil.CREATE_TABLE_PROFIL);
		db.execSQL(Profil.INSERT_PROFIL);

		db.execSQL(Notifikasi.NOTIFIKASI_CREATE);

		db.execSQL(Topi.TOPI_PRODUK_CREATE);
		db.execSQL(Topi.TOPI_BELI_CREATE);
		db.execSQL(Topi.TOPI_RETUR_BELI_CREATE);
		db.execSQL(Topi.TOPI_JUAL_CREATE);
		db.execSQL(Topi.TOPI_RETUR_JUAL_CREATE);
		db.execSQL(Topi.TOPI_PROFIL_CREATE);
		db.execSQL(Topi.TOPI_PROFIL_INSERT);

		db.execSQL(PrinterProfil.CREATE_TABLE_PRINTER);
		PrinterProfil.insertPrinter(context,db);

	}


    @Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		//db.execSQL("DROP TABLE IF EXISTS " + PROFIL_TABLE_NAME);
		//onCreate(db);

		/*db.execSQL("DROP TABLE IF EXISTS topi_produk");
		db.execSQL("DROP TABLE IF EXISTS topi_beli");
		db.execSQL("DROP TABLE IF EXISTS topi_retur_beli");
		db.execSQL("DROP TABLE IF EXISTS topi_jual");
		db.execSQL("DROP TABLE IF EXISTS topi_retur_jual");
		db.execSQL("DROP TABLE IF EXISTS topi_profil");

		db.execSQL(Topi.TOPI_PRODUK_CREATE);
		db.execSQL(Topi.TOPI_BELI_CREATE);
		db.execSQL(Topi.TOPI_RETUR_BELI_CREATE);
		db.execSQL(Topi.TOPI_JUAL_CREATE);
		db.execSQL(Topi.TOPI_RETUR_JUAL_CREATE);
		db.execSQL(Topi.TOPI_PROFIL_CREATE);
		db.execSQL(Topi.TOPI_PROFIL_INSERT);*/

		db.execSQL("DROP TABLE IF EXISTS tprinter");
		db.execSQL(PrinterProfil.CREATE_TABLE_PRINTER);
        db.execSQL("DROP TABLE IF EXISTS notifikasi");
        db.execSQL(Notifikasi.NOTIFIKASI_CREATE);
		PrinterProfil.onUpdatePrinter(context,this, db);
	}



}
