package com.starpoin.pay.helper;


public class Profil {

    public static final String PROFIL_TABLE = "profil";

    //PROFIL COLUMNS
    public static final String PROFIL_ID="profil_id";
    public static final String PROFIL_USERID="user_id";
    public static final String PROFIL_PASS="user_pass";
    public static final String PROFIL_PRINTER="printer";
    public static final String PROFIL_PRINTER_UUID="printer_uuid";

    public static final String CREATE_TABLE_PROFIL =
            "CREATE TABLE IF NOT EXISTS " + PROFIL_TABLE + "("
                    + PROFIL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + PROFIL_USERID + " TEXT,"
                    + PROFIL_PASS + " TEXT,"
                    + PROFIL_PRINTER + " TEXT,"
                    + PROFIL_PRINTER_UUID + " TEXT"
                    + ")";

    public static final String INSERT_PROFIL ="INSERT INTO "+PROFIL_TABLE+" " +
            "( "+ PROFIL_USERID + ","+ PROFIL_PASS + ","+ PROFIL_PRINTER + ","+ PROFIL_PRINTER +") VALUES " +
            "('','user','0','0')  ";

}
