package com.starpoin.pay.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.starpoin.pay.R;

import java.io.ByteArrayOutputStream;

public class PrinterProfil {

    private static final String TPRINTER="tprinter";
    private String printer,uuid;
    private int logo_view;
    private byte[] logo;

    public String getPrinter() {
        return printer;
    }

    public void setPrinter(String printer) {
        this.printer = printer;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public byte[] getLogo() {
        return logo;
    }

    public void setLogo(byte[] logo) {
        this.logo = logo;
    }

    public int getLogo_view() {
        return logo_view;
    }

    public void setLogo_view(int logo_view) {
        this.logo_view = logo_view;
    }

    public static final String CREATE_TABLE_PRINTER =
            "CREATE TABLE IF NOT EXISTS tprinter(id INTEGER,printer TEXT,printer_uuid TEXT,logo_view INTEGER,logo BLOB)";

    public static void insertPrinter(Context context, SQLiteDatabase db) {

        try{

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.print_logo);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] photo = baos.toByteArray();

            ContentValues cv = new ContentValues();
            cv.put("id", "1");
            cv.put("printer","0");
            cv.put("printer_uuid", "0");
            cv.put("logo_view",0);
            cv.put("logo",photo);
            db.insert("tprinter", null, cv);
            baos.close();
        }catch (Exception e){
            Log.d("insert printer error",e.toString());
        }
    }

    public static void onUpdatePrinter(Context context, DatabaseHelper dbHelper, SQLiteDatabase db){
        String printerName=null;
        String uuid=null;
        Cursor cursor = null;
        try{
            String[] args={};
            String sql="select printer,printer_uuid from profil";
            cursor = db.rawQuery(sql,args);
            while (cursor.moveToNext()){
                printerName=cursor.getString(0);
                uuid=cursor.getString(1);
            }
            //System.out.println("nama_printer: "+printerName);
            cursor.close();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.print_logo);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] photo = baos.toByteArray();

            ContentValues cv = new ContentValues();
            cv.put("id", "1");
            cv.put("printer",printerName);
            cv.put("printer_uuid", uuid);
            cv.put("logo_view",0);
            cv.put("logo",photo);
            db.insert("tprinter", null, cv);
            baos.close();
        }catch (Exception e){
            Log.d("upgrade printer error",e.toString());
        }
    }



    public PrinterProfil getPrinterProfil(Context context){
        PrinterProfil data=new PrinterProfil();
        Cursor cursor = null;
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        try{
            String[] args={};
             String sql="select id,printer,printer_uuid,logo_view,logo from tprinter";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,null);
            while (cursor.moveToNext()){
                printer=cursor.getString(1);
                uuid=cursor.getString(2);
                logo_view=cursor.getInt(3);
                logo=cursor.getBlob(4);

                data.setPrinter(printer);
                data.setUuid(uuid);
                data.setLogo_view(logo_view);
                data.setLogo(logo);
            }
        }catch (Exception e){
            System.out.println("get printer error: "+e.getMessage());
            data=null;
        }finally {
            cursor.close();
            dbHelper.close();
        }
        return data;
    }
}
