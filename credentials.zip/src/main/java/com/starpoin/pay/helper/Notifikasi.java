package com.starpoin.pay.helper;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.starpoin.pay.util.Wong;

import java.util.ArrayList;
import java.util.List;

public class Notifikasi {

    private static final String TABLE_NOTIFICATIONS = "notifikasi";

    private int id;
    private String id_message;
    private String title;
    private String message;
    private String waktu;
    private int status;

    public Notifikasi() {
    }

    public Notifikasi(int id, String id_message, String title, String message, String waktu, int status) {
        this.id = id;
        this.id_message = id_message;
        this.title = title;
        this.message = message;
        this.waktu = waktu;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getId_message() {
        return id_message;
    }

    public void setId_message(String id_message) {
        this.id_message = id_message;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public static final String NOTIFIKASI_CREATE="CREATE TABLE `notifikasi` (\n" +
            "  `id` INTEGER PRIMARY KEY AUTOINCREMENT ,\n" +
            "  `id_merchant` varchar(10) ,\n" +
            "  `id_message` TEXT  ,\n" +
            "  `title` TEXT DEFAULT NULL,\n" +
            "  `message` TEXT DEFAULT NULL,\n" +
            "  `waktu` varchar(100) DEFAULT NULL,\n" +
            "  `status` INTEGER)";
    public static void insertNotification(SQLiteDatabase db, ContentValues cv) {
        try{
            //System.out.println(cv.toString());
            db.insert(TABLE_NOTIFICATIONS, null, cv);
            db.close();
        }catch (Exception e){
            Log.d("insert notifikasi error",e.toString());
        }
    }

    public void updateStatusUnreadToRead(SQLiteDatabase db, String title){
        try{
            ContentValues values = new ContentValues();
            values.put("status", 1);
            db.update(TABLE_NOTIFICATIONS, values, "title=?", new String[]{ title });
            db.close();
        }catch (Exception e){
            Log.d("update notifikasi error",e.toString());
        }
    }

    public List<Notifikasi> getAllNotifications(SQLiteDatabase db) {
        List<Notifikasi> notificationsList = new ArrayList<Notifikasi>();
        String selectQuery = "SELECT id, id_message, title, message, waktu, status FROM " + TABLE_NOTIFICATIONS + " WHERE id_merchant = '"+Wong.getIdmerch()+"' ORDER BY id DESC";

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Notifikasi notification = new Notifikasi(cursor.getInt(0),cursor.getString(1), cursor.getString(2),cursor.getString(3), cursor.getString(4), cursor.getInt(5));
                notificationsList.add(notification);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return notificationsList;

    }

    public List<Notifikasi> getAllUnreadNotification(SQLiteDatabase db) {
        List<Notifikasi> notificationsList = new ArrayList<Notifikasi>();
        try{
            String selectQuery = "SELECT id, id_message, title, message, waktu, status FROM " + TABLE_NOTIFICATIONS+ " WHERE status = 0 AND id_merchant = '"+Wong.getIdmerch()+"' " + " ORDER BY id DESC";

            Cursor cursor = db.rawQuery(selectQuery, null);

            if (cursor.moveToFirst()) {
                do {
                    Notifikasi notification = new Notifikasi(cursor.getInt(0),cursor.getString(1), cursor.getString(2),cursor.getString(3), cursor.getString(4), cursor.getInt(5));
                    notificationsList.add(notification);
                } while (cursor.moveToNext());
            }

            cursor.close();
            db.close();
        }catch (Exception e) {
            e.printStackTrace();

        }
        return notificationsList;

    }

    public boolean deleteNotificationList(SQLiteDatabase db, String columnName, String columnValue) {
        String whereClause = columnName + " = ? AND status = ? ";
        String[] whereArgs = { columnValue, String.valueOf(1) };
        int deletedRows = db.delete(TABLE_NOTIFICATIONS, whereClause, whereArgs);
        db.close();
        if (deletedRows > 0) {
            return true;
        }
        return false;
    }
}
