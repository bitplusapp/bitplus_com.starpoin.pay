package com.starpoin.pay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.PbbAdapter;
import com.starpoin.pay.model.Pbb;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;

import java.util.ArrayList;

public class PbbActivity extends AbaseActivity implements View.OnClickListener {

    private static final int SCAN_REQ =1;
    private ConstraintLayout rootLayout;
    private Button btnScan;
    private EditText etNomor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pbb);

        setBarTitle("PBB");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
        etNomor=(EditText) findViewById(R.id.etNomor);

        btnScan=(Button) findViewById(R.id.btnScan);
        btnScan.setOnClickListener(this);

        reqArea();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK){
            switch (requestCode){
                case SCAN_REQ:
                    String kode_barcode = data.getStringExtra("barcode");
                    etNomor.setText(kode_barcode);
                    break;
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnScan:
                Intent intent = new Intent(this, ScanBarcodeActivity.class);
                startActivityForResult(intent, SCAN_REQ);
                break;
        }
    }

    private void reqArea(){
        String params= "products/tax";
        OtherTask task = new OtherTask(PbbActivity.this,PbbActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                viewArea(content);
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
                //Toast.makeText(getApplicationContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }

        });
        task.execute(params);

    }

    private void viewArea(String content){
        ArrayList<Pbb> listArea=new Pbb().listArea(content);
        PbbAdapter adapter=new PbbAdapter(PbbActivity.this,listArea);
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);
        //rvDenom=(RecyclerView) findViewById(R.id.rvDenom);
        RecyclerView rvDenom=findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);
        /*rvDenom.addOnItemTouchListener(new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Pbb pbb=listArea.get(position);
                inquery(pbb);
            }
        }));*/
        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                Pbb pbb=listArea.get(position);
                inquery(pbb);
            }
        });
    }

    private void inquery(Pbb pbb){
        String noid=etNomor.getText().toString().trim();
        String kode=pbb.getIdproduk();
        if(noid.length()<4){
            showMsg("Nomor belum sesuai");
            return;
        }

        String params=new Pbb().paramsInq(noid,kode);
        TransTask task = new TransTask(PbbActivity.this,PbbActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")) {
                    String data = json.getString(content, "data");
                    String trxid=json.getString(data,"ref_id");
                    double nominal = Double.parseDouble(json.getString(data,"tagihan"));
                    double amount =Double.parseDouble(json.getString(data,"amount"));
                    String admin = json.getString(data,"admin");
                    String time = json.getString(data, "time");
                    Intent intent=new Intent(PbbActivity.this,ResponseActivity.class);
                    intent.putExtra("produk", Produk.PBB);
                    intent.putExtra("result", content);
                    intent.putExtra("nominal", nominal);
                    intent.putExtra("amount", amount);
                    intent.putExtra("trxid", trxid);
                    intent.putExtra("admin", admin);
                    intent.putExtra("time", time);
                    intent.putExtra("noid", noid);
                    intent.putExtra("additional", kode); //tambahan parameter
                    startActivity(intent);


                    etNomor.setText("");

                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }
}