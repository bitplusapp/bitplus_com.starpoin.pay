package com.starpoin.pay;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;
import com.starpoin.pay.util.XmlIn;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class ProfilActivity extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;

    private EditText etIdmerchant,etUsername,etNohp,etNamaMerchant,etAlamat,etReferal;
    private Button btnEdit,btnBatal,btnSimpan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        this.setTitle("Profil Merchant");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        etUsername=(EditText) findViewById(R.id.etUsername);
        etUsername.setText(Wong.getEmail());

        etIdmerchant=(EditText) findViewById(R.id.etIdmerchant);
        etIdmerchant.setText(Wong.getIdmerch());

        etNohp=(EditText) findViewById(R.id.etNohp);
        //etNohp.setText(Wong.getHp());

        etNamaMerchant=(EditText) findViewById(R.id.etNamaMerchant);
        etAlamat=(EditText) findViewById(R.id.etAlamat);
        etReferal=(EditText) findViewById(R.id.etReferal);


        btnEdit=(Button) findViewById(R.id.btnEdit);
        btnEdit.setOnClickListener(this);
        btnBatal=(Button) findViewById(R.id.btnBatal);
        btnBatal.setOnClickListener(this);
        btnSimpan=(Button) findViewById(R.id.btnSimpan);
        btnSimpan.setOnClickListener(this);

        getProfil();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnEdit:
                String typeMerc=Wong.getTypeMerchant();
                if(typeMerc.equals("1")||typeMerc.equals("3")){
                    etNamaMerchant.setEnabled(true);
                    etNamaMerchant.setFocusable(true);
                    etAlamat.setEnabled(true);
                    etAlamat.setFocusable(true);
                    btnBatal.setVisibility(View.VISIBLE);
                    btnSimpan.setVisibility(View.VISIBLE);
                    etNamaMerchant.requestFocus();
                }

                break;
            case R.id.btnBatal:
                etNamaMerchant.setEnabled(false);
                etAlamat.setEnabled(false);

                btnBatal.setVisibility(View.INVISIBLE);
                btnSimpan.setVisibility(View.INVISIBLE);
                getProfil();
                break;
            case R.id.btnSimpan:
                String typeMer=Wong.getTypeMerchant();
                if(typeMer.equals("1")||typeMer.equals("3")){
                    String nama=etNamaMerchant.getText().toString().trim();
                    String alamat=etAlamat.getText().toString().trim();
                    if(nama.equals("")||alamat.equals("")){
                        Toast toast = Toast.makeText(ProfilActivity.this,
                                "Nama Merchant atau Alamat belum diisi", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.TOP, 25, 400);
                        toast.show();
                    }else{
                        confirmUpdate();
                    }
                }

                break;
        }
    }

    private void getProfil(){
        //MTI="lihat_profil";
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","lihat_profil");
        map.put("idmerc",Wong.getIdmerch());
        map.put("iduser",Wong.getEmail());
        String params="Trans"+new Params().buildParams(map);
        TransTask task = new TransTask(ProfilActivity.this,ProfilActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {

                XmlIn xml=new XmlIn();
                String rc=xml.getItem(content,"rc");
                if(rc.equals("0000")){

                    viewProfil(content);
                }else{
                    String desc=xml.getItem(content,"desc");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewProfil(String response){
        StringReader reader=null;
        reader=new StringReader(response);
        InputSource source = new InputSource(reader);
        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document doc = documentBuilder.parse(source);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("trx_response");
            Node nNode = nList.item(0);
            Element eElement = (Element) nNode;
            String rcode = eElement.getElementsByTagName("rc").item(0).getTextContent();

            if(rcode.equals("000")||rcode.equals("0000")){
                String namaMerchant=eElement.getElementsByTagName("nama_merchant").item(0).getTextContent();
                String alamat=eElement.getElementsByTagName("alamat").item(0).getTextContent();
                String hp=eElement.getElementsByTagName("hp").item(0).getTextContent();
                String ref=eElement.getElementsByTagName("referal").item(0).getTextContent();
                etNamaMerchant.setText(namaMerchant);
                etAlamat.setText(alamat);
                etNohp.setText(hp);
                etReferal.setText(ref);

            }else{
                String desc = eElement.getElementsByTagName("desc").item(0).getTextContent();
                Toast toast = Toast.makeText(ProfilActivity.this,
                        desc, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP, 25, 400);
                toast.show();
            }



        }catch (Exception e){
            //Log.i("err_prof",e.getMessage());
        }finally {
            if(reader != null){
                reader.close();
            }
        }


    }

    private void confirmUpdate(){
        AlertDialog.Builder builder = new AlertDialog.Builder(ProfilActivity.this);

        // Set a title for alert dialog
        builder.setTitle("Konfirmasi");

        // Ask the final question
        builder.setMessage("Update data profil ?");

        // Set the alert dialog yes button click listener
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                update();
            }
        });

        // Set the alert dialog no button click listener
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do something when No button clicked
                Toast.makeText(getApplicationContext(),
                        "No Button Clicked",Toast.LENGTH_SHORT).show();
            }
        });

        AlertDialog dialog = builder.create();
        // Display the alert dialog on interface
        dialog.show();
    }

    private void update(){
        String nama=etNamaMerchant.getText().toString().trim();
        String alamat=etAlamat.getText().toString().trim();

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","update_profil");
        map.put("idmerc",Wong.getIdmerch());
        map.put("iduser",Wong.getEmail());
        map.put("nama_merchant",nama);
        map.put("alamat",alamat);
        String params="Trans"+new Params().buildParams(map);
        TransTask task = new TransTask(ProfilActivity.this,ProfilActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {

                XmlIn xml=new XmlIn();
                String rc=xml.getItem(content,"rc");
                if(rc.equals("0000")){

                    getProfil();
                }else{
                    String desc=xml.getItem(content,"desc");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }
}