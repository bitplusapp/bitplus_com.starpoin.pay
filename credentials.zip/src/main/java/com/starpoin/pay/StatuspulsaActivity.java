package com.starpoin.pay;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.CekVoucherAdapter;
import com.starpoin.pay.model.ResultItem;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.DateParse;
import com.starpoin.pay.util.DatePick;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;
import com.starpoin.pay.util.XmlIn;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class StatuspulsaActivity extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;
    private RecyclerView rvDenom;
    private LinearLayout lyAmount;
    private EditText etNomor;
    private Button btntgl,btnCek;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statuspulsa);

        this.setTitle("Cek Status Voucher");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        //lyAmount=(LinearLayout) findViewById(R.id.lyAmount);

        etNomor=findViewById(R.id.etNomor);

        String tgl=new SimpleDateFormat("dd/MM/yyyy").format(new Date());
        btntgl=(Button) findViewById(R.id.btntgl);
        btntgl.setText(tgl);
        btntgl.setOnClickListener(this);


        btnCek=(Button) findViewById(R.id.btnCek);
        btnCek.setOnClickListener(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btntgl:
                new DatePick(StatuspulsaActivity.this,btntgl).onClick(v);
                break;
            case R.id.btnCek:
                cekStatus();
                break;
        }
    }

    private void cekStatus(){
        String no=etNomor.getText().toString().trim();

        if(no.length()<8){
            showMsg("Nomor belum lengkap");
            return;
        }
        String str=btntgl.getText().toString();
        String tgl=new DateParse().tglDefault(str);

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","cek_vou_stat");
        map.put("mti","cek_vou_stat");
        map.put("noid",no);
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("tanggal", tgl);
        String params="Trans"+new Params().buildParams(map);
        TransTask task = new TransTask(this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                XmlIn xml=new XmlIn();
                String rc=xml.getItem(content,"rc").trim();
                if(rc.equals("000")||rc.equals("0000")){
                    viewContent(content);
                }else{
                    String desc=xml.getItem(content,"desc");
                    showMsg(desc);
                }

            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewContent(String content){
        ArrayList<ResultItem> list=listContent(content);
        CekVoucherAdapter adapter=new CekVoucherAdapter(getBaseContext(),list);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);
        rvDenom=findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);
    }

    private ArrayList<ResultItem> listContent(String response){
        ArrayList<ResultItem> al=new ArrayList<>();
        XmlIn in=new XmlIn();
        String rc=in.getItem(response,"rc");
        if(rc.equals("000")||rc.equals("0000")){


            String provider=in.getItem(response,"provider");
            String desc_produk=in.getItem(response,"desc_produk");
            String status=in.getItem(response,"status");
            //Log.i("prov",provider);
            al.add(new ResultItem("Provider",provider));
            al.add(new ResultItem("Produk",provider+" "+desc_produk));
            al.add(new ResultItem("Status",status));


        }
        return al;
    }
}