package com.starpoin.pay.task;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;

import com.starpoin.pay.helper.LoadingHelper;
import com.starpoin.pay.util.PrinterLib;

public class PrinterTask extends AsyncTask<String, Void, String> {

    private String response;
    private Context context;
    private OnEventListener<String> mCallBack;
    public Exception mException;
    private LoadingHelper loading;

    public PrinterTask(Context context, Activity activity, OnEventListener callback){
        this.context=context;
        this.mCallBack=callback;
        this.loading = new LoadingHelper(activity);
    }

    protected void onPreExecute() {
        loading.showLoadingOverlay();
    }

    @Override
    protected String doInBackground(String... urls) {
        try{

            String URL = urls[0];

            response=new PrinterLib(context).print(URL);
        }catch (Exception e){
            //System.out.print(e.toString());
            response=e.getMessage();
        }


        return response;
    }

    protected void onCancelled() {
        loading.hideLoadingOverlay();
    }

    protected void onPostExecute(String content) {
        loading.hideLoadingOverlay();

        if (mCallBack != null) {
            if (mException == null) {
                mCallBack.onSuccess(content);

            } else {
                mCallBack.onFailure(mException);
            }
        }
    }
}
