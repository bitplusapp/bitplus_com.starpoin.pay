package com.starpoin.pay.task;

import android.content.Context;
import android.os.AsyncTask;

import com.starpoin.pay.util.HttpKoneksi;

public class FcmUpdateTask extends AsyncTask<String, Void, String> {


    private OnEventListener<String> mCallBack;
    private Context context;
    public Exception mException;
    private String response;

    public FcmUpdateTask(Context context, OnEventListener callback) {
        this.mCallBack = callback;
        this.context = context;
    }

    @Override
    protected void onPreExecute() {
        System.out.println("Process on background update fcm token");
    }

    @Override
    protected String doInBackground(String... params) {

        try{
            String action = params[0]; //path endpoint
            String jsonReq = params[1];
            response=new HttpKoneksi().ServicePost(action, jsonReq);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }

        return response;
    }

    protected void onCancelled() {
        System.out.println("Cancel update fcm token");
    }

    @Override
    protected void onPostExecute(String result) {
        //super.onPostExecute(result);
        System.out.println("Done Response from server "+result);

        if (mCallBack != null) {
            if (mException == null) {
                mCallBack.onSuccess(result);
            } else {
                mCallBack.onFailure(mException);
            }
        }
    }
}
