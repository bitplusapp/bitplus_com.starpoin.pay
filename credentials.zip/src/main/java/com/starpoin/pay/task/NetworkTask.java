package com.starpoin.pay.task;

import android.content.Context;
import android.os.AsyncTask;

import com.starpoin.pay.model.ConnectionQuality;
import com.starpoin.pay.util.HttpKoneksi;

public class NetworkTask extends AsyncTask<Void, Void, ConnectionQuality> {

    private ConnectionQuality response;
    private OnNetworkListener<ConnectionQuality> mCallBack;
    public Exception mException;
    private Context mContext;

    public NetworkTask(Context context, OnNetworkListener<ConnectionQuality> callback) {
        mCallBack = callback;
        mContext = context;
    }

    @Override
    protected ConnectionQuality doInBackground(Void... voids) {
        try{
            response=new HttpKoneksi().checkConnectionQuality();
        }catch (Exception e){
            e.printStackTrace();
            response = ConnectionQuality.POOR;
        }

        return response;
    }

    @Override
    protected void onPostExecute(ConnectionQuality quality) {
        if (mCallBack != null) {
            if (mException == null) {
                mCallBack.onSuccess(quality);
            } else {
                mCallBack.onFailure(mException);
            }
        }
    }
}

