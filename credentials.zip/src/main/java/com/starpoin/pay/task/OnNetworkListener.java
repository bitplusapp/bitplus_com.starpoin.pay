package com.starpoin.pay.task;

public interface OnNetworkListener<ConnectionQuality> {
    public void onSuccess(ConnectionQuality connectionQuality);
    public void onFailure(Exception e);
}
