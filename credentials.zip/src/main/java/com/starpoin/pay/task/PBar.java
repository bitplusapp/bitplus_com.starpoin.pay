package com.starpoin.pay.task;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.constraintlayout.widget.ConstraintLayout;

public class PBar extends ProgressBar {

    /*public PBar(Context context,ConstraintLayout rootLayout) {
        super(context);
        rootLayout.addView(this);

    }*/

    public PBar(Context context, ConstraintLayout rootLayout) {
        super(context);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(150, 150);
        lp.weight = 1.0f;
        lp.gravity = Gravity.CENTER;
        LinearLayout ll = new LinearLayout(context);
        ll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.addView(this, lp);

        rootLayout.addView(ll);

        this.setVisibility(View.GONE);

    }
    public void close(){
        this.close();
    }

}
