package com.starpoin.pay.task;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.starpoin.pay.helper.LoadingHelper;
import com.starpoin.pay.util.HttpKoneksi;
import com.starpoin.pay.util.JsonIn;

public class BannerTask extends AsyncTask<String, Void, String>{

        private OnEventListener<String> mCallBack;
        private Context mContext;
        public Exception mException;
        private String response;

        public BannerTask(Context context, Activity activity, OnEventListener callback) {
            mCallBack = callback;
            mContext = context;
        }

        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... params) {

            try{
                String param = params[0];
                response=new HttpKoneksi().Service(param);
            }catch (Exception e){
                response=new JsonIn().simpleOut("001",e.getMessage());
            }

            return response;
        }

        protected void onCancelled() {

        }

        @Override
        protected void onPostExecute(String result) {

            Log.v("resp_result", result);

            if (mCallBack != null) {
                if (mException == null) {
                    mCallBack.onSuccess(result);
                } else {
                    mCallBack.onFailure(mException);
                }
            }
        }
    }
