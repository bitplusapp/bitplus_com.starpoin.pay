package com.starpoin.pay.task;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

public class PBarLinear extends ProgressBar {

    public PBarLinear(Context context, RelativeLayout rootLayout) {
        super(context);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(150, 150);
        lp.weight = 1.0f;
        lp.gravity = Gravity.CENTER;
        LinearLayout ll = new LinearLayout(context);
        ll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.addView(this, lp);

        rootLayout.addView(ll);

        this.setVisibility(View.GONE);
    }


}
