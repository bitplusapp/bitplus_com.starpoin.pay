package com.starpoin.pay.task;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;

import com.starpoin.pay.helper.LoadingHelper;
import com.starpoin.pay.util.HttpKoneksi;

public class SaldoTask extends AsyncTask<String, Void, String> {

    private OnEventListener<String> mCallBack;
    private Context context;
    public Exception mException;
    private String response;
    private LoadingHelper loading;

    public SaldoTask(Context context, Activity activity, OnEventListener callback) {
        this.mCallBack = callback;
        this.context = context;
//        this.loading = new LoadingHelper(activity);
    }

    protected void onPreExecute() {
//        loading.showLoadingOverlay();
    }

    @Override
    protected String doInBackground(String... params) {

        try{
            response=new HttpKoneksi().checkBalance();
        }catch (Exception e){
            System.out.print(e.toString());
            //response=new SrvConnect().failledResp("001",e.getMessage());
        }

        return response;
    }

    protected void onCancelled() {
//        loading.hideLoadingOverlay();
    }

    @Override
    protected void onPostExecute(String result) {
        //super.onPostExecute(result);
        //loading.hideLoadingOverlay();

        if (mCallBack != null) {
            if (mException == null) {
                mCallBack.onSuccess(result);

            } else {
                mCallBack.onFailure(mException);
            }
        }

    }


}
