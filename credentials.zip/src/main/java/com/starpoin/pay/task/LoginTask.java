package com.starpoin.pay.task;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;

import com.starpoin.pay.helper.LoadingHelper;
import com.starpoin.pay.util.HttpKoneksi;

public class LoginTask extends AsyncTask<String, Void, String> {

    private OnEventListener<String> mCallBack;
    private Context context;
    public Exception mException;
    private String response;
    private LoadingHelper loading;

    public LoginTask(Context context, Activity activity, OnEventListener callback) {
        this.mCallBack = callback;
        this.context = context;
        this.loading = new LoadingHelper(activity);
    }

    @Override
    protected void onPreExecute() {
        loading.showLoadingOverlay();
    }

    @Override
    protected String doInBackground(String... params) {

        try{
            String user = params[0]; //username
            String pswd = params[1]; //password
            int loginVia = Integer.parseInt(params[2]); //login method
            //response=new SrvConnect().request(json,mContext);
            response=new HttpKoneksi().login(user,pswd, loginVia);
        }catch (Exception e){
            System.out.print(e.toString());
            //response=new SrvConnect().failledResp("001",e.getMessage());
        }

        return response;
    }

    protected void onCancelled() {
        loading.hideLoadingOverlay();

    }

    @Override
    protected void onPostExecute(String result) {
        //super.onPostExecute(result);
        loading.hideLoadingOverlay();

        if (mCallBack != null) {
            if (mException == null) {
                mCallBack.onSuccess(result);
            } else {
                mCallBack.onFailure(mException);
            }
        }

    }


}
