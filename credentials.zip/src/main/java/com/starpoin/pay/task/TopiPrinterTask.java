package com.starpoin.pay.task;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ProgressBar;

import com.starpoin.pay.topi.TopiPrintLib;

public class TopiPrinterTask extends AsyncTask<String, Void, String> {

    private String response;
    private Context context;
    private ProgressBar pbar;
    private OnEventListener<String> mCallBack;
    public Exception mException;

    public TopiPrinterTask(Context context, ProgressBar pbar, OnEventListener callback){
        this.context=context;
        this.pbar=pbar;
        this.mCallBack=callback;
    }

    protected void onPreExecute() {
        pbar.setVisibility(View.VISIBLE);
    }

    @Override
    protected String doInBackground(String... urls) {
        try{

            String URL = urls[0];

            //response=new PrinterLib(context).print(URL);
            response=new TopiPrintLib(context).print(URL);
        }catch (Exception e){
            //System.out.print(e.toString());
            response=e.getMessage();
        }


        return response;
    }

    protected void onCancelled() {
        pbar.setVisibility(View.GONE);
    }

    protected void onPostExecute(String content) {
        pbar.setVisibility(View.GONE);

        if (mCallBack != null) {
            if (mException == null) {
                mCallBack.onSuccess(content);

            } else {
                mCallBack.onFailure(mException);
            }
        }
    }
}
