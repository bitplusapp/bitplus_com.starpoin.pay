package com.starpoin.pay;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class OnBoardingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_on_boarding);
        List<OnBoarding> pages = new ArrayList<>();
        pages.add(new OnBoarding(R.drawable.banner1,"Apasih bitplus itu?","bitplus merupakan Agregator Transaksi Online (PPOB) untuk mitra H2H, Agen & Pengguna untuk Bayar PLN, Token Listrik, Telkom, PDAM, Telco Postpaid, Pulsa Prabayar, Paket Data, Dompet Elektronik & Biller lainnya."));
        pages.add(new OnBoarding(R.drawable.banner2,"Single Account","Kamu dapat menggunakan semua Platform (android, web, desktop) hanya dengan satu akun bitplus yang kamu daftarkan"));
        pages.add(new OnBoarding(R.drawable.banner3,"Printer Support","Kami mensupport segala jenis printer dan jenis kertas yang kamu miliki. jadi kamu gak perlu khawatir ya, segala kebutuhan kamu akan kami lengkapi"));

        OnBoarding.startOnBoarding(this, pages,null);
    }
}