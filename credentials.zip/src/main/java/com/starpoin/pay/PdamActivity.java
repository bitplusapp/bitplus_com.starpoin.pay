package com.starpoin.pay;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.adapter.ListPdamAdapter;
import com.starpoin.pay.adapter.PdamAdapter;
import com.starpoin.pay.model.Pdam;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.Produk;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class PdamActivity extends AbaseActivity implements View.OnClickListener {

    private static final int SCAN_REQ =1;
    private ConstraintLayout rootLayout;
    private RecyclerView rvDenom;
    private Button btnScan, btnShowProduct;
    private EditText etNomor;
    private Pdam selectedDenom;
    private String responseListPdam;

    private ArrayList<Pdam> listArea; // Jadikan variabel global
    private ListPdamAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdam);

        setBarTitle("PDAM");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
        etNomor=(EditText) findViewById(R.id.etNomor);

        btnScan=(Button) findViewById(R.id.btnScan);
        btnScan.setOnClickListener(this);

        btnShowProduct = findViewById(R.id.btnShowProduct);
        btnShowProduct.setOnClickListener(this);

        reqArea();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK){
            switch (requestCode){
                case SCAN_REQ:
                    String kode_barcode = data.getStringExtra("barcode");
                    etNomor.setText(kode_barcode);
                    break;
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnScan:
                Intent intent = new Intent(this, ScanBarcodeActivity.class);
                startActivityForResult(intent, SCAN_REQ);
                break;
            case R.id.btnShowProduct:
                showBottomSheetDialogProductList(responseListPdam);
                break;
        }
    }

    private void reqArea(){
        String params= "products/pdam";
        OtherTask task = new OtherTask(PdamActivity.this,PdamActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                responseListPdam = content;
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void showBottomSheetDialogProductList(String content) {
        listArea = new Pdam().listAreaPdam(content); // Update listArea saat pertama kali dijalankan
        final BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.bottom_sheet_dialog_pdam);

        final ListView lv = dialog.findViewById(R.id.lvProduct);
        adapter = new ListPdamAdapter(this, listArea); // Gunakan variabel adapter final
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                Pdam pdam = (Pdam) lv.getItemAtPosition(position);
                btnShowProduct.setText(pdam.getArea().toUpperCase());
                btnShowProduct.setCompoundDrawablesWithIntrinsicBounds(R.drawable.pdam_list, 0, 0, 0);
                dialog.dismiss();
                inquery(pdam);
            }
        });

        EditText searchEditText = dialog.findViewById(R.id.etSearch);
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Do nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 0) {
                    adapter.getFilter().filter(null);
                }
            }
        });

        // Get the height of the screen
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenHeight = displayMetrics.heightPixels;
        dialog.getBehavior().setPeekHeight(screenHeight);
        dialog.show();
    }

    private void viewArea(String content){
        ArrayList<Pdam> listArea=new Pdam().listAreaPdam(content);
        PdamAdapter adapter=new PdamAdapter(PdamActivity.this,listArea);
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);
        rvDenom=(RecyclerView) findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);

        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                selectedDenom=listArea.get(position);
                inquery(selectedDenom);
            }
        });
    }

    private void inquery(Pdam pdam){
        String noid=etNomor.getText().toString().trim();
        if(noid.length()<5){
            showMsg("Nomor belum sesuai");
            return;
        }

        String idbiller=pdam.getIdBiller();
        Map<String,Object> map = new Pdam().paramsInq(noid,idbiller, "");
        String params= new JSONObject(map).toString();
        TransTask task = new TransTask(PdamActivity.this,PdamActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                try {
                    JSONObject resp = new JSONObject(content);
                    String rc = resp.getString("rc");
                    if (rc.equals("0000")) {
                        JSONObject data = resp.getJSONObject("data");
                        JSONArray tagihanArray = data.getJSONArray("tagihan");
                        String trxid = data.getString("ref_id");
                        double amount = Double.parseDouble(data.getString("amount"));
                        String admin = data.getString("admin");
                        double rptag = 0;
                        double denda = 0;

                        for(int i=0; i < tagihanArray.length(); i++) {
                            rptag += tagihanArray.getJSONObject(i).getLong("rptag");
                            denda += tagihanArray.getJSONObject(i).getLong("denda");
                        }

                        double nominal = rptag+denda;
                        String time = data.getString("time");
                        Intent intent = new Intent(PdamActivity.this, ResponseActivity.class);

                        intent.putExtra("produk", Produk.PDAM);
                        intent.putExtra("result", content);
                        intent.putExtra("nominal", nominal);
                        intent.putExtra("amount", amount);
                        intent.putExtra("trxid", trxid);
                        intent.putExtra("admin", admin);
                        intent.putExtra("time", time);
                        intent.putExtra("noid", noid);
                        intent.putExtra("additional", idbiller); //tambahan parameter
                        startActivity(intent);

                        etNomor.setText("");
                    } else {
                        String desc = resp.getString("message");
                        showMsg(desc);
                    }
                }catch (Exception e) {

                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }
}