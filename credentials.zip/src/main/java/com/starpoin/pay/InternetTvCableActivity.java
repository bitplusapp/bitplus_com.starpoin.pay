package com.starpoin.pay;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.InetTvCableAdapter;
import com.starpoin.pay.model.InternetTvCable;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class InternetTvCableActivity extends AbaseActivity implements View.OnClickListener {

    private final static int PICK_CONTACT = 0;
    private ConstraintLayout rootLayout;
    private RecyclerView rvDenom;
    private EditText etNomor;
    private Button btnContact;
    private ArrayList<InternetTvCable> listProduk;
    private InternetTvCable selectedDenom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internet_tv_cable);
        setBarTitle("Internet TV Cable");
        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
        etNomor=(EditText) findViewById(R.id.etNomor);
        btnContact=(Button) findViewById(R.id.btnContact);
        btnContact.setOnClickListener(this);
        reqProdukISP();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnContact:
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
                startActivityForResult(intent, PICK_CONTACT);
                break;
        }
    }

    private void reqProdukISP() {
        String params= "products/inetv";
        OtherTask task = new OtherTask(InternetTvCableActivity.this,InternetTvCableActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                viewListIsp(content);
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            switch (requestCode) {
                case (PICK_CONTACT):
                    if (resultCode == RESULT_OK) {
                        Cursor cursor = getContentResolver().query(data.getData(), new String[] {ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);

                        // True if the cursor is not empty
                        cursor.moveToFirst();
                        String number = cursor.getString((int) 0);
                        etNomor.setText(number.replace("-", "").replace(" ", ""));
                    }

                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void viewListIsp(String content) {
        listProduk = new InternetTvCable().listIsp(content);
        InetTvCableAdapter adapter = new InetTvCableAdapter(InternetTvCableActivity.this, listProduk);
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);
        rvDenom=(RecyclerView) findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);

        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                selectedDenom=listProduk.get(position);
                inquery(selectedDenom);
            }
        });
    }

    private void inquery(InternetTvCable inetv) {
        String noid = etNomor.getText().toString().trim();
        if (noid.length() < 5) {
            showMsg("Nomor belum sesuai");
            return;
        }
        Map<String,Object> map=new InternetTvCable().paramsInq(noid, inetv.getCode());
        String params= new JSONObject(map).toString();
        TransTask task = new TransTask(InternetTvCableActivity.this,InternetTvCableActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                System.out.println(content);
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")){
                    String trxid=json.getObjectWithString(content,"data", "ref_id");
                    double amount =Double.parseDouble(json.getObjectWithString(content,"data", "amount"));
                    String admin = json.getObjectWithString(content,"data", "admin");
                    double nominal = Double.parseDouble(json.getObjectWithString(content, "data","total_tagihan"));
                    String time = json.getObjectWithString(content,"data", "time");
                    Intent intent=new Intent(InternetTvCableActivity.this,ResponseActivity.class);
                    intent.putExtra("produk", Produk.TVCABLE);
                    intent.putExtra("result", content);
                    intent.putExtra("nominal", nominal);
                    intent.putExtra("amount", amount);
                    intent.putExtra("trxid", trxid);
                    intent.putExtra("admin", admin);
                    intent.putExtra("time", time);
                    intent.putExtra("noid", noid);
                    intent.putExtra("additional", inetv.getCode()); //tambahan parameter
                    startActivity(intent);

                    etNomor.setText("");
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }
}