package com.starpoin.pay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.RegistrationTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Wong;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ResetPasswordActivity extends AbaseActivity implements View.OnClickListener {
    private ConstraintLayout rootLayout;
    private EditText etPin,etPassword,etPassword2;
    private Button btnReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        if(getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        setTitle("Reset Password");
        rootLayout=findViewById(R.id.rootLayout);

        etPin=findViewById(R.id.etPin);
        etPassword=findViewById(R.id.etPassword);
        etPassword2=findViewById(R.id.etPassword2);

        btnReset=findViewById(R.id.btnReset);
        btnReset.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnReset:
                resetPas();
                break;
        }
    }

    private void resetPas(){
        String email= Wong.getEmail();
        String pin=etPin.getText().toString().trim();
        String pass1=etPassword.getText().toString();
        String pass2=etPassword2.getText().toString();
        if(pin.length()<6){
            showMsg("Masukkan 6 digit PIN");
            return;
        }
        if(pass1.length()<4){
            showMsg("Password belum sesuai");
            return;
        }
        if(!pass2.equals(pass1)){
            showMsg("Password belum sesuai");
            return;
        }

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("email", email);
        map.put("pin_verification", pin);
        map.put("password", pass1);
        String params= new JSONObject(map).toString();
        RegistrationTask task = new RegistrationTask(ResetPasswordActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("000")||rc.equals("0000")){
                    //showMsg("Update password berhasil , silahkan login");
                    Toast.makeText(ResetPasswordActivity.this, "Reset password berhasil", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(ResetPasswordActivity.this, MlebuActivity.class);
                    startActivity(i);
                    //finish();
                    finishAffinity();
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
                //Toast.makeText(getApplicationContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }

        });
        task.execute("registration/user/updatepasswd",params);
    }
}