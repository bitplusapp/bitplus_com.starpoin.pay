package com.starpoin.pay;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.SecureOtherTask;
import com.starpoin.pay.util.JsonIn;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ChangePwdActivity extends AbaseActivity implements View.OnClickListener {

    private RelativeLayout rootLayout;
    private ImageButton btnBack;
    private EditText _passwordText;
    private EditText _newPasswordText;
    private EditText _confirmNewPasswordText;
    private CheckBox chkPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_passwd);

        if(getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        this.setTitle("Ganti Password");

        rootLayout=(RelativeLayout) findViewById(R.id.rootLayout);

        _passwordText = (EditText)findViewById(R.id.passwordText);
        _newPasswordText = (EditText)findViewById(R.id.newPasswordText);
        _confirmNewPasswordText = (EditText)findViewById(R.id.confirmNewPasswordText);

        btnBack = (ImageButton) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);

        Button submitButton = (Button)findViewById(R.id.submitButton);
        submitButton.setOnClickListener(this);

//        chkPass=(CheckBox) findViewById(R.id.chkPass);
//        chkPass.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                //is chkIos checked?
//                if (((CheckBox) v).isChecked()) {
//                    _passwordText.setTransformationMethod(null);
//                    _newPasswordText.setTransformationMethod(null);
//                    _confirmNewPasswordText.setTransformationMethod(null);
//                }else{
//                    _passwordText.setTransformationMethod(new PasswordTransformationMethod());
//                    _newPasswordText.setTransformationMethod(new PasswordTransformationMethod());
//                    _confirmNewPasswordText.setTransformationMethod(new PasswordTransformationMethod());
//                }
//
//            }
//        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.submitButton:
                if (isInputValid()) {
                    //_imm.hideSoftInputFromWindow(_passwordText.getWindowToken(), 0);
                    submit();
                }
                break;
            case R.id.btnBack:
                onBackPressed();
                break;
        }
    }

    private boolean isInputValid() {
        if (_passwordText.getText().toString().equals("")) {
            Toast.makeText(ChangePwdActivity.this, "Password lama harus di isi", Toast.LENGTH_SHORT).show();
            _passwordText.requestFocus();

            return false;
        }

        if (_newPasswordText.getText().toString().equals("")) {
            Toast.makeText(ChangePwdActivity.this, "Password baru harus di isi", Toast.LENGTH_SHORT).show();
            _newPasswordText.requestFocus();

            return false;
        }

        if (_confirmNewPasswordText.getText().toString().equals("")) {
            Toast.makeText(ChangePwdActivity.this, "Konfirmasi password baru harus di isi !", Toast.LENGTH_SHORT).show();
            _confirmNewPasswordText.requestFocus();

            return false;
        }

        if (!_newPasswordText.getText().toString().equals(_confirmNewPasswordText.getText().toString())) {
            Toast.makeText(ChangePwdActivity.this, "Password tidak sama !", Toast.LENGTH_SHORT).show();
            _confirmNewPasswordText.requestFocus();

            return false;
        }

        return true;
    }

    private void submit() {
        //String oldpass=_passwordText.getText().toString();
        String newpass=_newPasswordText.getText().toString();
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("password", newpass);
        String params= new JSONObject(map).toString();
        SecureOtherTask task = new SecureOtherTask(ChangePwdActivity.this,ChangePwdActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {

                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("000")||rc.equals("0000")){
                    showMsg("Ganti password berhasil. Silahkan Login Ulang");
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute("profile/update",params);
    }
}