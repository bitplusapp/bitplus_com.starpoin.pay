package com.starpoin.pay;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.starpoin.pay.adapter.NotificationAdapter;
import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.Notifikasi;
import com.starpoin.pay.util.Wong;

import java.util.List;

public class NotifikasiActivity extends AbaseActivity {

    private RecyclerView notificationList;
    private NotificationAdapter notificationAdapter;
    private List<Notifikasi> notificationData;
    private LinearLayout EmptyLayout;
    private FloatingActionButton fabTruncate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setBarTitle("Notifikasi");
        setContentView(R.layout.activity_notification_list);

        notificationList = findViewById(R.id.notification_list);
        notificationList.setLayoutManager(new LinearLayoutManager(this));

        EmptyLayout = findViewById(R.id.EmptyLayout);
        fabTruncate = findViewById(R.id.floatingActionButton);

        fabTruncate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(NotifikasiActivity.this, R.style.AlertDialog);
                builder.setMessage("Apakah Anda yakin ingin menghapus semua pesan notifikasi?")
                        .setCancelable(false)
                        .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Kode untuk menghapus elemen
                                DatabaseHelper dbHelper=new DatabaseHelper(NotifikasiActivity.this);
                                SQLiteDatabase db=dbHelper.getWritableDatabase();
                                boolean delete = new Notifikasi().deleteNotificationList(db, "id_merchant", Wong.getIdmerch());
                                if(delete) {
                                    loadNotificationData();
                                }
                            }
                        })
                        .setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Kode untuk membatalkan penghapusan
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }

    private void loadNotificationData() {
        DatabaseHelper dbHelper=new DatabaseHelper(NotifikasiActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        List<Notifikasi> notifikasi = new Notifikasi().getAllNotifications(db);
        notificationData = notifikasi;

        if (notificationData.size() == 0 || notificationData.isEmpty()) {
            EmptyLayout.setVisibility(View.VISIBLE);
            notificationList.setVisibility(View.GONE);
            fabTruncate.setVisibility(View.GONE);
        }else{
            // Create the adapter and set it to the RecyclerView
            notificationList.setVisibility(View.VISIBLE);
            EmptyLayout.setVisibility(View.GONE);
            fabTruncate.setVisibility(View.VISIBLE);
            notificationAdapter = new NotificationAdapter(this, notificationData);
            notificationAdapter.setOnItemClickListener(new NotificationAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(Notifikasi notif) {
                    Intent intent=new Intent(NotifikasiActivity.this, NotifikasiDetailActivity.class);
                    intent.putExtra("id", notif.getId_message());
                    intent.putExtra("title", notif.getTitle());
                    intent.putExtra("body", notif.getMessage());
                    intent.putExtra("time", notif.getWaktu());
                    startActivity(intent);
                }
            });
            notificationList.setAdapter(notificationAdapter);
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        loadNotificationData();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        loadNotificationData();
    }
}