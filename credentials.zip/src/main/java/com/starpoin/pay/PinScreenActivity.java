package com.starpoin.pay;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.Profil;
import com.starpoin.pay.model.LoginMethod;
import com.starpoin.pay.task.LoginTask;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Valid;
import com.starpoin.pay.util.Wong;

import in.aabhasjindal.otptextview.OTPListener;
import in.aabhasjindal.otptextview.OtpTextView;

public class PinScreenActivity extends AbaseActivity implements View.OnClickListener {

    private Button btn_num0, btn_num1, btn_num2, btn_num3,btn_num4,btn_num5,btn_num6,
                   btn_num7, btn_num8, btn_num9, btnDel;
    private TextView info_label;
    LinearLayout llDel;
    private OtpTextView otpTextView;
    private String otpResult = "";
    private String PIN, username, passwd;
    private SharedPreferences sp;
    private boolean isNewActivate;
    private String app_version;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin_screen);

        getSupportActionBar().hide();

        info_label = findViewById(R.id.info_label);

        Intent intent = getIntent();

        if(intent.hasExtra("pin")) {
            isNewActivate = true;
            PIN = intent.getStringExtra("pin");
            info_label.setText("HARAP SIMPAN PIN ANDA "+ intent.getStringExtra("pin"));
        }else{
            isNewActivate = false;
            sp = getSharedPreferences("Login", 0);
            username = sp.getString("unm", null);
            PIN = sp.getString("pin", null);
            info_label.setText("Nonaktifkan PIN ?");
            info_label.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences.Editor Ed = sp.edit();
                    Ed.remove("pin");
                    Ed.commit();
                    Toast.makeText(PinScreenActivity.this, "PIN Di Non aktifkan", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(PinScreenActivity.this, MlebuActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }
            });
        }

        btn_num0 = findViewById(R.id.btn_num0);
        btn_num1 = findViewById(R.id.btn_num1);
        btn_num2 = findViewById(R.id.btn_num2);
        btn_num3 = findViewById(R.id.btn_num3);
        btn_num4 = findViewById(R.id.btn_num4);
        btn_num5 = findViewById(R.id.btn_num5);
        btn_num6 = findViewById(R.id.btn_num6);
        btn_num7 = findViewById(R.id.btn_num7);
        btn_num8 = findViewById(R.id.btn_num8);
        btn_num9 = findViewById(R.id.btn_num9);
        btnDel   = findViewById(R.id.btn_del);
        llDel    = findViewById(R.id.ll_del);

        btn_num0.setOnClickListener(this);
        btn_num1.setOnClickListener(this);
        btn_num2.setOnClickListener(this);
        btn_num3.setOnClickListener(this);
        btn_num4.setOnClickListener(this);
        btn_num5.setOnClickListener(this);
        btn_num6.setOnClickListener(this);
        btn_num7.setOnClickListener(this);
        btn_num8.setOnClickListener(this);
        btn_num9.setOnClickListener(this);
        btnDel.setOnClickListener(this);

        otpTextView = findViewById(R.id.otp_view);
        otpTextView.setOnClickListener(this);
        otpTextView.setOtpListener(new OTPListener() {
            @Override
            public void onInteractionListener() {
                // fired when user types something in the Otpbox
            }
            @Override
            public void onOTPComplete(String otp) {
                // fired when user has entered the OTP fully.
                if(otp.equals(PIN)) {
                    if(isNewActivate) {
                        sp = getSharedPreferences("Login", 0);
                        String unm  = sp.getString("unm", null);
                        String pass = sp.getString("pas", null);
                        SharedPreferences.Editor Ed=sp.edit();
                        if(unm != null && pass != null) {
                            //tambahkan informasi PIN
                            Ed.putString("pin", PIN);
                        }else{
                            Ed.putString("unm", Wong.getEmail());
                            Ed.putString("idm", Wong.getIdmerch());
                            Ed.putString("pin", PIN);
                        }
                        Ed.commit();
                        FancyAlertDialog.Builder
                                .with(PinScreenActivity.this)
                                .setTitle("Berhasil")
                                .setBackgroundColor(Color.parseColor("#E2F3FD"))  // for @ColorRes use setBackgroundColorRes(R.color.colorvalue)
                                .setMessage("PIN Aplikasi sudah aktif")
                                .setPositiveBtnBackground(Color.parseColor("#0F78C9"))  // for @ColorRes use setPositiveBtnBackgroundRes(R.color.colorvalue)
                                .setPositiveBtnText("Lanjut")
                                .setNegativeBtnText("Tutup")
                                .onNegativeClicked(dialog -> finish())
                                .setAnimation(Animation.POP)
                                .isCancellable(false)
                                .setIcon(R.drawable.ic_baseline_pin_24, View.VISIBLE)
                                .onPositiveClicked(dialog -> {
                                    Intent intent=new Intent(PinScreenActivity.this,DashboardActivity.class);
                                    startActivity(intent);
                                    finish();
                                })
                                .onNegativeClicked(dialog -> {
                                    Intent intent=new Intent(PinScreenActivity.this,DashboardActivity.class);
                                    startActivity(intent);
                                    finish();
                                })
                                .build()
                                .show();
                    }else{
                        passwd = new Valid().encrypt(PIN);
                        login(username,passwd);
                    }
                }else{
                    Toast.makeText(PinScreenActivity.this, "PIN salah", Toast.LENGTH_SHORT).show();
                }
            }
        });


        try {
            PackageInfo pInfo = PinScreenActivity.this.getPackageManager().getPackageInfo(getPackageName(), 0);
            app_version = pInfo.versionName;
            Wong.setAppVersion(app_version);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }


    }

    private void login(String username, String password){
        String user=username;
        String pswd=password;

        LoginTask task = new LoginTask(PinScreenActivity.this,PinScreenActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc= json.getString(content, "rc");
                if(rc.equals("0000") || rc.equals("0127")) {
                    //Toast.makeText(MlebuActivity.this,"Login berhasil",Toast.LENGTH_LONG).show();
                    String idmerc=json.getString(content,"id_merchant");
                    String name=json.getString(content,"name_merchant");
                    String user_key=json.getString(content,"token");
                    String type_merchant=json.getString(content,"type_merchant");
                    //String topiStatus=xml.getItem(content,"topi_status");
                    String topiStatus="0";

                    Wong.setIdmerch(idmerc);
                    Wong.setMerchant(name);
                    Wong.setUser_key(user_key);
                    Wong.setTypeMerchant(type_merchant);
                    Wong.setTopiStatus(topiStatus);

                    String email=user.trim();
                    String passs=pswd;
                    Wong.setEmail(email);
                    Wong.setPassword(passs);

                    updateUser(email);
                    Wong.setUserLogin(true);

                    if(rc.equals("0127")) {
                        showUpdateDialog();
                    }else{
                        Intent intent=new Intent(PinScreenActivity.this,DashboardActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }else{
                    String desc=json.getString(content,"message");
                    Toast.makeText(PinScreenActivity.this,desc,Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Exception e) {
                Toast.makeText(getApplicationContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }

        });
        task.execute(user,pswd, Integer.toString(LoginMethod.PIN_APP));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    private void updateUser(String user){

        String userid=user;
        DatabaseHelper dbHelper=new DatabaseHelper(PinScreenActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            String strSQL = "UPDATE "+ Profil.PROFIL_TABLE+" SET "+Profil.PROFIL_USERID+" ='"+userid+"' ";

            db.execSQL(strSQL);
        }catch (Exception e){
            //Log.d("error",e.toString());
        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }

        }
    }

    public void showUpdateDialog() {
        FancyAlertDialog.Builder
                .with(this)
                .setTitle("Update tersedia")
                .setBackgroundColor(Color.parseColor("#E2F3FD"))  // for @ColorRes use setBackgroundColorRes(R.color.colorvalue)
                .setMessage("Jadilah orang pertama merasakan fitur terbaru")
                .setNegativeBtnText("Nanti")
                .setPositiveBtnBackground(Color.parseColor("#0F78C9"))  // for @ColorRes use setPositiveBtnBackgroundRes(R.color.colorvalue)
                .setPositiveBtnText("Update")
                .setNegativeBtnBackgroundRes(R.color.common_google_signin_btn_text_light)  // for @ColorRes use setNegativeBtnBackgroundRes(R.color.colorvalue)
                .setAnimation(Animation.POP)
                .isCancellable(true)
                .setIcon(R.drawable.info_rekening, View.VISIBLE)
                .onPositiveClicked(dialog -> openPlaystoreForUpdate())
                .onNegativeClicked(dialog -> {
                    Intent intent=new Intent(PinScreenActivity.this,DashboardActivity.class);
                    startActivity(intent);
                    finish();
                })
                .build()
                .show();
    }

    private void openPlaystoreForUpdate() {
        String appPackageName = getPackageName();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_del:
            case R.id.ll_del:
                int totalNum = otpTextView.getOTP().length();
                if(totalNum > 0) {
                    otpResult = otpTextView.getOTP().substring(0, totalNum-1);
                }
                break;
            case R.id.btn_num0:
                otpResult += "0";
                break;
            case R.id.btn_num1:
                otpResult += "1";
                break;
            case R.id.btn_num2:
                otpResult += "2";
                break;
            case R.id.btn_num3:
                otpResult += "3";
                break;
            case R.id.btn_num4:
                otpResult += "4";
                break;
            case R.id.btn_num5:
                otpResult += "5";
                break;
            case R.id.btn_num6:
                otpResult += "6";
                break;
            case R.id.btn_num7:
                otpResult += "7";
                break;
            case R.id.btn_num8:
                otpResult += "8";
                break;
            case R.id.btn_num9:
                otpResult += "9";
                break;
        }
        otpTextView.setOTP(otpResult);
    }
}