package com.starpoin.pay;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.adapter.ListProductAdapter;
import com.starpoin.pay.adapter.ReqPrintulangAdapter;
import com.starpoin.pay.model.LapTrans;
import com.starpoin.pay.model.ReqPrintItems;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.PBar;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.DateParse;
import com.starpoin.pay.util.DatePick;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;
import com.starpoin.pay.util.XmlIn;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class PrintUlangActivity extends AbaseActivity  implements View.OnClickListener {

    private ConstraintLayout rootLayout;
    //private RecyclerView rvDenom;
    private LinearLayout lyAmount;
    private Button btndrtgl,btnsdtgl, btnShowProduct;


    private int produk;
    private String MTI;
    //private boolean DLG_SHOW=true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print_ulang);

        this.setTitle("Cetak Ulang");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
        //rvDenom=findViewById(R.id.rvDenom);
        lyAmount=(LinearLayout) findViewById(R.id.lyAmount);

        String tgl=new SimpleDateFormat("dd/MM/yyyy").format(new Date());
        btndrtgl=(Button) findViewById(R.id.btndrtgl);
        btndrtgl.setText(tgl);
        btndrtgl.setOnClickListener(this);

        btnsdtgl=(Button) findViewById(R.id.btnsdtgl);
        btnsdtgl.setText(tgl);
        btnsdtgl.setOnClickListener(this);

        btnShowProduct= findViewById(R.id.btnShowProduct);
        btnShowProduct.setOnClickListener(this);

        //viewProduk();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        //viewProduk();
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btndrtgl:
                new DatePick(PrintUlangActivity.this,btndrtgl).onClick(v);

                break;
            case R.id.btnsdtgl:
                new DatePick(PrintUlangActivity.this,btnsdtgl).onClick(v);

                break;
//            case R.id.btnClear:
//
//                //viewProduk();
//                break;
            case R.id.btnShowProduct:
                showBottomSheetDialogProductList();
                break;
        }
    }

    private void showBottomSheetDialogProductList() {
        ArrayList<LapTrans> list=new LapTrans().listProductReprint();
        final BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.bottom_sheet_dialog_product);

        final ListView lv = dialog.findViewById(R.id.lvProduct);
        lv.setAdapter(new ListProductAdapter(this, list));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                LapTrans lapTrans = (LapTrans) lv.getItemAtPosition(position);
                MTI = lapTrans.getKey();
                produk = lapTrans.getId();
                btnShowProduct.setText(lapTrans.getLabel().toUpperCase());
                dialog.dismiss();
                inquery();
            }
        });
        // Get the height of the screen
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenHeight = displayMetrics.heightPixels;
        dialog.getBehavior().setPeekHeight(screenHeight);
        dialog.show();
    }

    private void inquery(){

        String str1=btndrtgl.getText().toString();
        String str2=btnsdtgl.getText().toString();
        String drtgl=new DateParse().tglDefault(str1);
        String sdtgl=new DateParse().tglDefault(str2);

        String params="report/reprint/"+MTI+"/"+drtgl+"/"+sdtgl;
        OtherTask task = new OtherTask(this, PrintUlangActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc").trim();


                if(rc.equals("000")||rc.equals("0000")){

                    //dialogContent(content);

                    Intent intent=new Intent(PrintUlangActivity.this,ReprintResultActivity.class);
                    intent.putExtra("content",content);
                    intent.putExtra("produk",String.valueOf(produk));
                    intent.putExtra("MTI",MTI);
                    startActivity(intent);
                }else{
                    showMsg("Tidak ada data ditemukan");
                }

            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void dialogContent(String content){
        ArrayList<ReqPrintItems> list=new ReqPrintItems().listPrint(content);
        ReqPrintulangAdapter adapter=new ReqPrintulangAdapter(PrintUlangActivity.this,list);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);

        final BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.reprint_content_layout);

        RecyclerView rvDenom=dialog.findViewById(R.id.rvContent);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);

        Button btnClose=dialog.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });

        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                dialog.dismiss();
                ReqPrintItems item=list.get(position);
                reqData(item);
            }
        });

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                //DLG_SHOW=true;
            }
        });
        dialog.show();
    }



    private void reqData(ReqPrintItems item){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","print_ulang");
        map.put("mti",MTI);
        map.put("noid",item.getNoid());
        map.put("trxid",item.getTrxid());
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("tanggal", item.getTanggal());
        map.put("pan", item.getPan());
        String params="Trans"+new Params().buildParams(map);
        //Log.i("param_inq2",params);

        final ProgressBar pbar=new PBar(this,rootLayout);
        TransTask task = new TransTask(this,PrintUlangActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                try {


                    XmlIn xml = new XmlIn();
                    String rc = xml.getItem(content, "rc").trim();

                    if (rc.equals("000") || rc.equals("0000")) {

                        double amount = Double.parseDouble(xml.getItem(content, "amount"));

                        Intent intent = new Intent(PrintUlangActivity.this, ReprintActivity.class);
                        intent.putExtra("produk", produk);
                        intent.putExtra("result", content);
                        intent.putExtra("amount", amount);
                        intent.putExtra("pan", item.getPan());
                        startActivity(intent);
                    } else {
                        showMsg("Tidak ada data ditemukan");
                    }
                }catch(Exception ex){
                    Log.v("err_resp",ex.getMessage());
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

}