package com.starpoin.pay;

import android.os.Bundle;
import android.widget.TextView;

import com.starpoin.pay.util.Wong;

public class InfoRekeningActivity extends AbaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_rekening);

        this.setTitle("Info Rekening");

        TextView tv_appversion=(TextView) findViewById(R.id.tv_appversion);
        tv_appversion.setText("bitplus app version "+ Wong.getAppVersion());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}