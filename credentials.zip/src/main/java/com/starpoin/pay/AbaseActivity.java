package com.starpoin.pay;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomsheet.BottomSheetDialog;

public class AbaseActivity extends AppCompatActivity {

    //public ConstraintLayout rootLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abase);

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
    }

    public void showMsg(String msg){

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.msg_dialog);
        //ImageButton btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        Button btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //bottomSheetDialog.cancel();
                bottomSheetDialog.dismiss();
            }
        });

        TextView tvError=bottomSheetDialog.findViewById(R.id.tvError);
        tvError.setText(msg);

        bottomSheetDialog.show();

    }

    public void setBarTitle(String title){
        getSupportActionBar().setTitle(title);

    }

    /*public void setWarnaTitle(String title){
        int labelColor = getResources().getColor(R.color.white);
        String сolorString = String.format("%X", labelColor).substring(2); // !!strip alpha value!!

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            //Html.fromHtml(String.format("<font color=\"#%s\">text</font>", сolorString));
            getSupportActionBar() .setTitle(Html.fromHtml(String.format("<font color=\"#%s\">"+title+"</font>", сolorString)));


        }
    }*/


}