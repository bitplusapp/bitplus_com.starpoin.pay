package com.starpoin.pay.util;

public class Produk {

    public final static int POSTPAID=1;
    public final static int PREPAID=2;
    public final static int NONTAGLIS=3;
    public final static int PULSA=4;
    public final static int PASCABAYAR=5;
    public final static int GAME=6;
    public final static int PAKETDATA=7;
    public final static int JASTEL=8;
    public final static int TOPUP=9;
    public final static int PDAM=10;
    public final static int PDAMBATANG=11;
    public final static int PBB=12;
    public final static int BPJS=13;
    public final static int TVCABLE=14;

    public final static int EVENT=15;

    //untuk laporan
    public final static int SEMUA=100;
    public final static int VOUCHER=101;
}
