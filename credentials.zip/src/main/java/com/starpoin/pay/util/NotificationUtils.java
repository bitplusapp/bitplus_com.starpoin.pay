package com.starpoin.pay.util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.starpoin.pay.R;

public class NotificationUtils extends ContextWrapper {

    private NotificationManager mManager;
    public final String ANDROID_CHANNEL_ID = this.getString(R.string.default_notification_channel_id);
    public final String ANDROID_CHANNEL_NAME = this.getString(R.string.default_notification_channel_name);


    public NotificationUtils(Context base) {
        super(base);
        createChannels();
    }
    public void createChannels() {
        // create android channel
        if(Build.VERSION.SDK_INT >= 26) {
            NotificationChannel mChannelInfo,mChannelDefault;
            Uri sound = Uri.parse("android.resource://" + getApplicationContext().getPackageName() + "/" + R.raw.bitplus);

            mChannelInfo = new NotificationChannel(ANDROID_CHANNEL_ID, ANDROID_CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            mChannelInfo.setLightColor(Color.GREEN);
            mChannelInfo.enableLights(true);
            mChannelInfo.setDescription("Notifikasi pembaharuan aplikasi, produk dan promo");

            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build();

            mChannelInfo.setSound(sound, audioAttributes);
            mChannelInfo.setImportance(NotificationManager.IMPORTANCE_DEFAULT);
            mChannelInfo.enableVibration(true);
            mChannelInfo.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
            mChannelInfo.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

            mChannelDefault = new NotificationChannel("Default", "Default", NotificationManager.IMPORTANCE_DEFAULT);
            mChannelDefault.setImportance(NotificationManager.IMPORTANCE_DEFAULT);
            Uri defaultRingtoneUri = RingtoneManager.getActualDefaultRingtoneUri(getApplicationContext(), RingtoneManager.TYPE_NOTIFICATION);
            mChannelDefault.setSound(defaultRingtoneUri, audioAttributes);
            mChannelDefault.enableVibration(true);
            mChannelDefault.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
            mChannelDefault.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

            getManager().createNotificationChannel(mChannelInfo);
            getManager().createNotificationChannel(mChannelDefault);
        }
    }

    public NotificationCompat.Builder builder(String title, String body, PendingIntent intent) {
        Uri sound = Uri.parse("android.resource://" + getApplicationContext().getPackageName() + "/" + R.raw.bitplus);
        return new NotificationCompat.Builder(this, ANDROID_CHANNEL_ID)
                .setSmallIcon(R.drawable.bitplus_b)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_EVENT)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setChannelId(ANDROID_CHANNEL_ID)
                .setContentIntent(intent)
                .setSound(sound)
                .setSmallIcon(R.drawable.payment)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.payment))
                //.addAction(R.drawable.arrow_right, "Buka bitplus", intent)
                .setDefaults(NotificationCompat.DEFAULT_ALL);
    }

    public NotificationManager getManager() {
        if (mManager == null) {
            mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return mManager;
    }
}
