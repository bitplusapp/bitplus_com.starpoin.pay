package com.starpoin.pay.util;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.starpoin.pay.helper.PrinterProfil;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class PrinterLib {

    private Context context;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;
    private BluetoothDevice bluetoothDevice;
    private OutputStream outputStream;
    private InputStream inputStream;

    private byte[] readBuffer;
    private int readBufferPosition;

    private String resp="0";
    private PrinterProfil pp;
    private String printerName;
    private int prinLogo;
    private byte[] logo;

    public PrinterLib(Context context){

        this.context=context;
        pp=new PrinterProfil().getPrinterProfil(context);
        printerName=pp.getPrinter();
        prinLogo=pp.getLogo_view();
        logo=pp.getLogo();
    }

    public String print(String text){

        IntentPrint(text);

        //return "1";
        return resp;
    }



    public void IntentPrint(String txtvalue){
        InitPrinter();

        String br=System.getProperty("line.separator");
        ByteArrayInputStream imageStream=null;
        try{

            if(prinLogo==1){
                imageStream = new ByteArrayInputStream(logo);
                Bitmap theImage= BitmapFactory.decodeStream(imageStream);
                byte[] command = ImgDecode.decodeBitmap(theImage);


                outputStream.write(command);
                outputStream.write(br.getBytes());
                outputStream.write(br.getBytes());
            }

            outputStream.write(txtvalue.getBytes());
            outputStream.write(0x0D);
            outputStream.write(br.getBytes());
            outputStream.write(br.getBytes());//dua line dibaca satu line

            outputStream.flush();
            try{
                Thread.sleep(400);
            }catch (Exception e){

            }
            outputStream.close();
            inputStream.close();
            socket.close();

            resp="1";
        }catch(Exception ex){
            //System.out.println("error ngeprint: "+ex.getMessage());
            resp="Printer tidak dapat dihubungi";
//            resp=ex.getMessage();
//            Map<String, Object> data = new HashMap<>();
//            data.put("error_msg", ex.getMessage());
//            data.put("activity_name", "IntentPrint");
//            new BugHunter().reportBugError(data);
        }finally {
            if(imageStream != null){
                try {
                    imageStream.close();
                }catch (Exception ex){

                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    public void  InitPrinter(){
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        try{
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
            if(pairedDevices.size() > 0){

                for(BluetoothDevice device : pairedDevices){
                    if(device.getName().equals(printerName)){
                        bluetoothDevice = device;
                        break;
                    }
                }

                Method m = bluetoothDevice.getClass().getMethod("createRfcommSocket", new Class[]{int.class});
                socket = (BluetoothSocket) m.invoke(bluetoothDevice, 1);
                bluetoothAdapter.cancelDiscovery();
                socket.connect();
                outputStream = socket.getOutputStream();
                inputStream = socket.getInputStream();
                beginListenForData();
            }
        }catch(Exception ex){
            resp="Printer tidak dapat dihubungi";
//            Map<String, Object> data = new HashMap<>();
//            data.put("error_msg", ex.getMessage());
//            data.put("activity_name", "InitPrinter");
//            new BugHunter().reportBugError(data);
        }
    }
    void beginListenForData() {
        try {


            // this is the ASCII code for a newline character
            final byte delimiter = 10;


            readBufferPosition = 0;
            readBuffer = new byte[1024];

            int bytesAvailable = inputStream.available();

            if (bytesAvailable > 0) {

                byte[] packetBytes = new byte[bytesAvailable];
                inputStream.read(packetBytes);

                for (int i = 0; i < bytesAvailable; i++) {

                    byte b = packetBytes[i];
                    if (b == delimiter) {

                        byte[] encodedBytes = new byte[readBufferPosition];
                        System.arraycopy(
                                readBuffer, 0,
                                encodedBytes, 0,
                                encodedBytes.length
                        );

                        // specify US-ASCII encoding
                        final String data = new String(encodedBytes, "US-ASCII");
                        readBufferPosition = 0;



                    } else {
                        readBuffer[readBufferPosition++] = b;
                    }
                }
            }

        } catch (Exception e) {
            resp="Printer tidak dapat dihubungi";
//            Map<String, Object> data = new HashMap<>();
//            data.put("error_msg", e.getMessage());
//            data.put("activity_name", "void beginListenForData");
//            new BugHunter().reportBugError(data);
            //e.printStackTrace();
        }
    }
}
