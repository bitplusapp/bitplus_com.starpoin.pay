package com.starpoin.pay.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class XmlIn {
    public String getItem(String xml,String tag){
        String out=null;
        try {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            InputSource src = new InputSource();
            src.setCharacterStream(new StringReader(xml));

            Document doc = builder.parse(src);
            out = doc.getElementsByTagName(tag).item(0).getTextContent();
            //String name = doc.getElementsByTagName("name").item(0).getTextContent();
        } catch (Exception ex) {
            out=xmlSimple("001", ex.getMessage());
        }
        return out;
    }

    public String xmlSimple(String rc,String desc) {
        String out = null;
        StringWriter outWriter = null;
        try {

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            Document doc = docBuilder.newDocument();
            //ProcessingInstruction pi = doc.createProcessingInstruction("xml-stylesheet", "type=\"text/xsl\" href=\"http://www.w3.org/1999/XSL/Transform\"");
            Element rootElement = doc.createElement("trx_response");
            doc.appendChild(rootElement);

            Element data = doc.createElement("data");
            rootElement.appendChild(data);

            //Element trxid = doc.createElement("ams_rc");
            Element trxid = doc.createElement("rc");
            trxid.appendChild(doc.createTextNode(rc));
            data.appendChild(trxid);

            //Element edesc = doc.createElement("ams_desc");
            Element edesc = doc.createElement("desc");
            edesc.appendChild(doc.createTextNode(desc));
            data.appendChild(edesc);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            outWriter = new StringWriter();
            //StreamResult result = new StreamResult(new File("file.xml"));
            StreamResult result = new StreamResult(outWriter);
            // Output to console for testing
            // StreamResult result = new StreamResult(System.out);

            transformer.transform(source, result);
            StringBuffer sbw = outWriter.getBuffer();
            out = sbw.toString();

        } catch (Exception ex) {
            //Log log=new Log();
            //log.InsertStream("Android", "001", "q", ex.toString(), "001");
        } finally {
            if (outWriter != null) {
                try {
                    outWriter.close();
                } catch (Exception e) {
                }
            }
        }
        return out;
    }

    public String toMd5(String s) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] array = md.digest(s.getBytes());
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < array.length; ++i) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
            }
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
        }
        return null;
    }
}
