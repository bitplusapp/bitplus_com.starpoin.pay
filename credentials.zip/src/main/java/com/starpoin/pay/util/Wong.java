package com.starpoin.pay.util;

import android.content.res.AssetManager;

/**
 * Created by acer on 11/07/2018.
 */

public class Wong {

    private static String appVersion;
    private static String email,device,hp, idmerch,merchant,typeMerchant,topiStatus,uniq,password,trxid,otp_via;
    private static String printerName,printerUUID;
    //private static String vcode;
    private static String alamat;
    private static String DBdir;
    private static String noid;//idpel
    private static String user_key;
    private static boolean userLogin=false;
    private String urlServer;
    private static String urlProd,authority;
    private static AssetManager assetManager;

    private static String pwd;

    public static String getAppVersion() {
        return appVersion;
    }

    public static void setAppVersion(String appVersion) {
        Wong.appVersion = appVersion;
    }

    public static boolean isUserLogin() {
        return userLogin;
    }

    public static void setUserLogin(boolean userLogin) {
        Wong.userLogin = userLogin;
    }

    public static boolean getUserLogin() {
        return Wong.userLogin;
    }

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        Wong.email = email;
    }

    public static String getOtp_via() {
        return otp_via;
    }

    public static void setOtp_via(String otp_via) {
        Wong.otp_via = otp_via;
    }

    public static String getDevice() {
        return device;
    }

    public static void setDevice(String device) {
        Wong.device = device;
    }

    public static String getHp() {
        return hp;
    }

    public static void setHp(String hp) {
        Wong.hp = hp;
    }

    public static String getIdmerch() {
        return idmerch;
    }

    public static void setIdmerch(String idmerch) {
        Wong.idmerch = idmerch;
    }

    public static String getMerchant() {
        return merchant;
    }

    public static void setMerchant(String merchant) {
        Wong.merchant = merchant;
    }

    public static String getTypeMerchant() {
        return typeMerchant;
    }

    public static void setTypeMerchant(String typeMerchant) {
        Wong.typeMerchant = typeMerchant;
    }

    public static String getTopiStatus() {
        return topiStatus;
    }

    public static void setTopiStatus(String topiStatus) {
        Wong.topiStatus = topiStatus;
    }

    public static String getUniq() {
        return uniq;
    }

    public static void setUniq(String uniq) {
        Wong.uniq = uniq;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        Wong.password = password;
    }

    public static String getTrxid() {
        return trxid;
    }

    public static void setTrxid(String trxid) {
        Wong.trxid = trxid;
    }

    public static String getPrinterName() {
        return printerName;
    }

    public static void setPrinterName(String printerName) {
        Wong.printerName = printerName;
    }

    public static String getPrinterUUID() {
        return printerUUID;
    }

    public static void setPrinterUUID(String printerUUID) {
        Wong.printerUUID = printerUUID;
    }

    /*public static String getVcode() {
        return vcode;
    }

    public static void setVcode(String vcode) {
        Wong.vcode = vcode;
    }*/

    public static String getAlamat() {
        return alamat;
    }

    public static void setAlamat(String alamat) {
        Wong.alamat = alamat;
    }

    public static String getDBdir() {
        return DBdir;
    }

    public static void setDBdir(String DBdir) {
        Wong.DBdir = DBdir;
    }

    public static String getNoid() {
        return noid;
    }

    public static void setNoid(String noid) {
        Wong.noid = noid;
    }

    public static String getUser_key() {
        return user_key;
    }

    public static void setUser_key(String user_key) {
        Wong.user_key = user_key;
    }

    public static String getUrlProd() {
        return urlProd;
    }

    public static void setUrlProd(String urlProd) {
        Wong.urlProd = urlProd;
    }



    public static String getAuthority() {
        return authority;
    }

    public static void setAuthority(String authority) {
        Wong.authority = authority;
    }

    public static AssetManager getAssetManager() {
        return assetManager;
    }

    public static void setAssetManager(AssetManager assetManager) {
        Wong.assetManager = assetManager;
    }



    public String getUrlServer() {


        String s=urlProd;
        return s;
    }

    public static String getPwd() {
        return pwd;
    }

    public static void setPwd(String pwd) {
        Wong.pwd = pwd;
    }

    public void setUrlServer(String urlServer) {
        this.urlServer = urlServer;
    }
}
