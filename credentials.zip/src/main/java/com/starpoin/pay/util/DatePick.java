package com.starpoin.pay.util;

import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

import java.util.Calendar;
import java.util.TimeZone;

public class DatePick implements View.OnClickListener, DatePickerDialog.OnDateSetListener {

    private Context context;
    private Button btn;

    private int _day;
    private int _month;
    private int _year;

    public DatePick(Context context, Button btn){
        this.context=context;
        this.btn=btn;
    }
    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

        _year = year;
        _month = month;
        _day = dayOfMonth;

        btn.setText(new StringBuilder()
                // Month is 0 based so add 1
                .append(_day).append("/").append(_month + 1).append("/").append(_year).append(" "));
    }


    @Override
    public void onClick(View v) {
        Calendar calendar = Calendar.getInstance(TimeZone.getDefault());

        DatePickerDialog dialog = new DatePickerDialog(context, this,
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));
        dialog.show();
        dialog.getButton(DatePickerDialog.BUTTON_NEGATIVE).setTextColor(Color.BLACK);
        dialog.getButton(DatePickerDialog.BUTTON_POSITIVE).setTextColor(Color.BLACK);
    }
}
