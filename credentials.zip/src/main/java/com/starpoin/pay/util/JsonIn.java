package com.starpoin.pay.util;

import org.json.JSONException;
import org.json.JSONObject;

public class JsonIn {

    public String getObjectWithString(String respJson, String objName, String strName){
        String out=null;
        JSONObject json = null;
        try {
            json = new JSONObject(respJson);
            out = json.getJSONObject(objName).getString(strName);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return out;
    }

    public String hasNameObj(String respJson, String name) {
        String out=null;
        JSONObject json = null;
        try {
            json = new JSONObject(respJson);
            out = json.has(name) ? json.getString(name) : "-";
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return out;
    }

    public String getString(String respJson, String str){
        String out=null;
        JSONObject json = null;
        try {
            json = new JSONObject(respJson);
            out = json.getString(str);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return out;
    }

    public String simpleOut(String rc, String data) {
        JSONObject json = null;
        try {
            json = new JSONObject();
            json.put("rc", rc);
            json.put("message", data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json.toString();
    }

}
