package com.starpoin.pay.util;

import java.util.Map;

public class Params {

    public String buildParams(Map<String,Object> map){
        StringBuilder sb=new StringBuilder();
        sb.append("?");
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String akey=entry.getKey();
            Object val=entry.getValue();
            sb.append(akey+"="+val);
            sb.append("&");
        }
        String str=sb.toString();
        int a=str.length();
        int b=a-1;
        String out=str.substring(0, b);
        return out;
    }
}
