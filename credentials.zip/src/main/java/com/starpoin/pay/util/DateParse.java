package com.starpoin.pay.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateParse {

    public String parse(String datetime){
        String s=null;
        SimpleDateFormat sdf=new SimpleDateFormat("dd MMM yyyy HH:mm");
        try {

            Date date = new SimpleDateFormat("yyyyMMddHHmmss").parse(datetime);
            //System.out.println(date);
            //System.out.println(sdf.format(date));
            s=sdf.format(date);
        } catch (ParseException e) {

        }
        return s;
    }

    public String parseCetakUlang(String datetime){
        String s=null;
        SimpleDateFormat sdf=new SimpleDateFormat("dd MMM yyyy HH:mm");
        try {
            Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(datetime);
            s=sdf.format(date);
        } catch (ParseException e) {
            Date date1 = null;
            try {
                date1 = new SimpleDateFormat("yyyy-MM-dd").parse(datetime);
                s=new SimpleDateFormat("dd MMM yyyy").format(date1);
            } catch (ParseException ex) {
                s=datetime;
            }
            //System.out.println(date);
            //System.out.println(sdf.format(date));

        }
        return s;
    }

    public String parseBulan(String datetime,int bill){
        String s=null;
        SimpleDateFormat sdf=new SimpleDateFormat("dd MMM yyyy HH:mm");
        try {

            Date date = new SimpleDateFormat("yyyyMMddHHmmss").parse(datetime);
            //System.out.println(date);
            System.out.println(sdf.format(date));
            s=sdf.format(date);
        } catch (ParseException e) {

        }
        return s;
    }

    public String tglDefault(String tanggal){
        String s=null;
        String[] arr=tanggal.split("/");
        String thn=arr[2].trim();
        String bln=arr[1].trim();
        String tgl=arr[0].trim();
        s=thn+"-"+bln+"-"+tgl;
        return s;
    }
}
