package com.starpoin.pay.util;

import static android.os.Build.MANUFACTURER;
import static android.os.Build.MODEL;
import static android.os.Build.PRODUCT;

import java.util.Map;

public class BugHunter {

    public void reportBugError(Map<String, Object> data) {
        data.put("mti","send_log_error");
        data.put("idmerc", Wong.getIdmerch());
        data.put("email", Wong.getEmail());
        data.put("device_name", MANUFACTURER + "("+PRODUCT+" : "+MODEL+")");
        data.put("device_build", getAndroidVersion());
        String params="Reg"+new Params().buildParams(data);
        //new HttpKoneksi().mGet(params);
    }

    public String getAndroidVersion() {
        String release = android.os.Build.VERSION.RELEASE;
        int sdkVersion = android.os.Build.VERSION.SDK_INT;
        return "Android SDK: " + sdkVersion + " (" + release +")";
    }

}
