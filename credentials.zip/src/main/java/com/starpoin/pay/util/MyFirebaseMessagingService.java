package com.starpoin.pay.util;

import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.starpoin.pay.DashboardActivity;
import com.starpoin.pay.MlebuActivity;
import com.starpoin.pay.R;
import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.Notifikasi;
import com.starpoin.pay.task.FcmUpdateTask;
import com.starpoin.pay.task.OnEventListener;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";
    private NotificationUtils mNotificationUtils;
    private static int count = 0;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        Log.d(TAG, "PESAN MASUK : " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            String action = remoteMessage.getData().get("action");
            if(action != null) {
                //Data retrieved from notification payload send
                String title = remoteMessage.getData().get("title");
                String body = remoteMessage.getData().get("body");
                System.out.println(title+"==========="+body);
            }
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "ISI PESAN : " + remoteMessage.getNotification().getBody());
            String notificationBody = remoteMessage.getNotification().getBody();
            String notificationTitle = remoteMessage.getNotification().getTitle();
            if (remoteMessage.getNotification().getBody() != null) {
                insertNotification(remoteMessage.getNotification());
                sendNotification(notificationTitle, notificationBody);
            }
        }
    }

    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "Refreshed token: " + token);
    }

    public void sendRegistrationToServer(Context context, String id_merchant, String token) {
        try {
            JSONObject jsonReq = new JSONObject();
            jsonReq.put("id_merchant", id_merchant);
            jsonReq.put("token", token);
            FcmUpdateTask fcmUpdateTask = new FcmUpdateTask(context, new OnEventListener<String>() {
                @Override
                public void onSuccess(String result) {
                    System.out.println(result);
                }

                @Override
                public void onFailure(Exception e) {
                    System.out.println(e.getMessage());
                }
            });
            fcmUpdateTask.execute("registration/user/setfcmtoken", jsonReq.toString());
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int flags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        } else {
            return PendingIntent.FLAG_UPDATE_CURRENT;
        }
    }

    public void sendNotification(String title, String messageBody) {
        Class activity = null;
        if(Wong.getUserLogin()) {
            activity = DashboardActivity.class;
        }else{
            activity = MlebuActivity.class;
        }

        Intent intent = new Intent(this, activity);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, flags());

        mNotificationUtils = new NotificationUtils(this);
        NotificationCompat.Builder nb = mNotificationUtils.builder(title, messageBody, pendingIntent);

        mNotificationUtils.getManager().notify(count, nb.build());
        count++;
    }

    public void insertNotification(RemoteMessage.Notification notification){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String dateNow = dateFormat.format(date);
        DatabaseHelper dbHelper=new DatabaseHelper(MyFirebaseMessagingService.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            ContentValues cv = new ContentValues();
            cv.put("id_message", this.getString(R.string.default_notification_channel_id));
            cv.put("title", notification.getTitle());
            cv.put("message", notification.getBody());
            cv.put("id_merchant", Wong.getIdmerch());
            cv.put("waktu", dateNow);
            cv.put("status", 0);

            new Notifikasi().insertNotification(db, cv);
        }catch (Exception e){
            e.printStackTrace();
            Log.d("error",e.toString());
        }finally {
            try{
                db.close();
            }catch (Exception se){

            }
        }
    }
}
