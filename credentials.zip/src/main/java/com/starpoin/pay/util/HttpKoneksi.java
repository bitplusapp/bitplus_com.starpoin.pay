package com.starpoin.pay.util;


import android.content.res.AssetManager;
import android.text.TextUtils;

import com.starpoin.pay.WelcomeActivity;
import com.starpoin.pay.model.ConnectionQuality;
import com.starpoin.pay.model.LoginMethod;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManagerFactory;

public class HttpKoneksi {


    private String urlpath=new Wong().getUrlServer();
    //private final int TIMEOUT=1000*60*2;//2 mnt
    private final int TIMEOUT=1000*35;//1 mnt
    static final String COOKIES_HEADER = "Set-Cookie";
    static CookieManager msCookieManager = new CookieManager();

    private static boolean isDevelopment = false; //set true if mode dev and uncomment ignoreSSLs

    public String login(String user, String pswd, int loginVia){
        String device=Wong.getAppVersion();
        String out=null;
        StringBuilder sb = null;
        JSONObject jsonReq = null;
        try {
            jsonReq = new JSONObject();
            jsonReq.put("username", user);
            jsonReq.put("password", pswd);

            String path = "";
            switch (loginVia) {
                case LoginMethod.GOOGLE:
                    path = "auth/identify";
                    break;
                case LoginMethod.PIN_APP:
                    path = "auth/pin";
                    break;
                default:
                    path = "auth";
                    break;
            }

            if(urlpath == null) {
                new WelcomeActivity().initialApp();
                urlpath=new Wong().getUrlServer();
            }

            URL url=new URL(urlpath+path);

            HttpURLConnection conn = null;
            if(isDevelopment) {
                //ignoreSSL();
                conn = (HttpURLConnection) url.openConnection();
            }else{
                conn = httpsConnection(url);
            }

            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("X-API-KEY", Wong.getAuthority());
            conn.setRequestProperty("X-APP-VER", device);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            try(OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonReq.toString().getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int httpStatus = conn.getResponseCode();

            Map<String, List<String>> headerFields = conn.getHeaderFields();
            List<String> cookiesHeader = headerFields.get(COOKIES_HEADER);

            if (cookiesHeader != null) {
                for (String cookie : cookiesHeader) {
                    msCookieManager.getCookieStore().add(null, HttpCookie.parse(cookie).get(0));
                }
            }

            if(httpStatus==200){
                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                String output;
                sb=new StringBuilder();

                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                //System.out.println(sb.toString());
                out=sb.toString();
            }else{
                out= new JsonIn().simpleOut("001", "Connection failed Code "+httpStatus);
            }

        } catch (Exception e) {
            out=new JsonIn().simpleOut("001", "Tidak ada data");

        }
        //System.out.println(out);
        return out;
    }

    public ConnectionQuality checkConnectionQuality() {
        try {
            long startTime = System.currentTimeMillis();
            URL url = new URL(urlpath+"network/ping"); // Ganti URL dengan server yang ingin diuji

            HttpURLConnection conn = null;
            if(isDevelopment) {
                //ignoreSSL();
                conn = (HttpURLConnection) url.openConnection();
            }else{
                conn = httpsConnection(url);
            }

            conn.setRequestMethod("GET");
            conn.setConnectTimeout(3000); // Atur waktu maksimum koneksi dalam milidetik
            conn.connect();
            long endTime = System.currentTimeMillis();

            long responseTime = endTime - startTime;
            if (responseTime < 1000) {
                return ConnectionQuality.GOOD;
            } else if (responseTime < 3000) {
                return ConnectionQuality.MODERATE;
            } else {
                return ConnectionQuality.POOR;
            }
        } catch (IOException e) {
            return ConnectionQuality.POOR;
        }
    }
    public String checkBalance() {
        String params = "";
        String out=null;
        StringBuilder sb = null;
        try {
            if(urlpath == null) {
                new WelcomeActivity().initialApp();
                urlpath=new Wong().getUrlServer();
            }

            URL url=new URL(urlpath+"balance");

            HttpURLConnection conn = null;
            if(isDevelopment) {
                //ignoreSSL();
                conn = (HttpURLConnection) url.openConnection();
            }else{
                conn = httpsConnection(url);
            }

            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + Wong.getUser_key());
            conn.setRequestProperty("X-API-KEY", Wong.getAuthority());
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            if (msCookieManager.getCookieStore().getCookies().size() > 0) {
                System.out.println("Set-Cookie = "+msCookieManager.getCookieStore().getCookies());
                // While joining the Cookies, use ',' or ';' as needed. Most of the servers are using ';'
                conn.setRequestProperty("Cookie",
                        TextUtils.join(";",  msCookieManager.getCookieStore().getCookies()));
            }

            try(OutputStream os = conn.getOutputStream()) {
                byte[] input = params.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int httpStatus = conn.getResponseCode();

            if(httpStatus==200) {
                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                String output;

                sb=new StringBuilder();

                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                out=sb.toString();
                //Log.d("resp server = ",out);
            }else{
                out=new JsonIn().simpleOut("001", "Transaksi Gagal");
            }

        } catch (Exception e) {
            out=new JsonIn().simpleOut("001", "Tidak ada data");


        }

        return out;
    }

    public String Transaction(String params) {
        System.out.println(params);
        String out=null;
        StringBuilder sb = null;
        try {
            

            if(urlpath == null) {
                new WelcomeActivity().initialApp();
                urlpath=new Wong().getUrlServer();
            }

            URL url=new URL(urlpath+"transaction");
            HttpURLConnection conn = null;
            if(isDevelopment) {
                //ignoreSSL();
                conn = (HttpURLConnection) url.openConnection();
            }else{
                conn = httpsConnection(url);
            }
            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + Wong.getUser_key());
            conn.setRequestProperty("X-API-KEY", Wong.getAuthority());
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            if (msCookieManager.getCookieStore().getCookies().size() > 0) {
                System.out.println("Set-Cookie = "+msCookieManager.getCookieStore().getCookies());
                // While joining the Cookies, use ',' or ';' as needed. Most of the servers are using ';'
                conn.setRequestProperty("Cookie",
                        TextUtils.join(";",  msCookieManager.getCookieStore().getCookies()));
            }

            try(OutputStream os = conn.getOutputStream()) {
                byte[] input = params.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int httpStatus = conn.getResponseCode();

            if(httpStatus==200){
                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                String output;
                sb=new StringBuilder();

                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                out=sb.toString();
                //Log.d("resp server = ",out);
            }else{
                out=new JsonIn().simpleOut("001", "Transaksi Gagal");
            }

        } catch (Exception e) {
            out=new JsonIn().simpleOut("001", "Tidak ada data");


        }

        return out;
    }

    public String ServicePost(String action, String params) {
        System.out.println(urlpath+action);
        System.out.println(params);
        String out=null;
        StringBuilder sb = null;
        try {
            

            if(urlpath == null) {
                new WelcomeActivity().initialApp();
                urlpath=new Wong().getUrlServer();
            }

            URL url=new URL(urlpath+action);
            HttpURLConnection conn = null;
            if(isDevelopment) {
                //ignoreSSL();
                conn = (HttpURLConnection) url.openConnection();
            }else{
                conn = httpsConnection(url);
            }
            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("X-API-KEY", Wong.getAuthority());
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            try(OutputStream os = conn.getOutputStream()) {
                byte[] input = params.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int httpStatus = conn.getResponseCode();

            if(httpStatus==200){
                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                String output;
                sb=new StringBuilder();

                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                out=sb.toString();
                //Log.d("resp server = ",out);
            }else{
                out=new JsonIn().simpleOut("001", "Transaksi Gagal");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out=new JsonIn().simpleOut("001", "Tidak ada data");
        }

        return out;
    }

    public String SecrueServicePost(String action, String params) {
        System.out.println(urlpath+action);
        System.out.println(params);
        String out=null;
        StringBuilder sb = null;
        try {
            

            if(urlpath == null) {
                new WelcomeActivity().initialApp();
                urlpath=new Wong().getUrlServer();
            }


            URL url=new URL(urlpath+action);
            HttpURLConnection conn = null;
            if(isDevelopment) {
                //ignoreSSL();
                conn = (HttpURLConnection) url.openConnection();
            }else{
                conn = httpsConnection(url);
            }
            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("X-API-KEY", Wong.getAuthority());
            conn.setRequestProperty("Authorization", "Bearer " + Wong.getUser_key());
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            if (msCookieManager.getCookieStore().getCookies().size() > 0) {
                System.out.println("Set-Cookie = "+msCookieManager.getCookieStore().getCookies());
                // While joining the Cookies, use ',' or ';' as needed. Most of the servers are using ';'
                conn.setRequestProperty("Cookie",
                        TextUtils.join(";",  msCookieManager.getCookieStore().getCookies()));
            }

            try(OutputStream os = conn.getOutputStream()) {
                byte[] input = params.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int httpStatus = conn.getResponseCode();

            if(httpStatus==200){
                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                String output;
                sb=new StringBuilder();

                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                out=sb.toString();
                //Log.d("resp server = ",out);
            }else{
                out=new JsonIn().simpleOut("001", "Transaksi Gagal");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out=new JsonIn().simpleOut("001", "Tidak ada data");
        }

        return out;
    }

    public String Service(String params) {
        //System.out.println(params);
        String out=null;
        StringBuilder sb = null;
        try {

            if(urlpath == null) {
                new WelcomeActivity().initialApp();
                urlpath=new Wong().getUrlServer();
            }

            URL url=new URL(urlpath+params);
            System.out.println(urlpath+params);
            HttpURLConnection conn = null;
            if(isDevelopment) {
                //ignoreSSL();
                conn = (HttpURLConnection) url.openConnection();
            }else{
                conn = httpsConnection(url);
            }
            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + Wong.getUser_key());
            conn.setRequestProperty("X-API-KEY", Wong.getAuthority());
            conn.setRequestMethod("GET");

            if (msCookieManager.getCookieStore().getCookies().size() > 0) {
                System.out.println("Set-Cookie = "+msCookieManager.getCookieStore().getCookies());
                // While joining the Cookies, use ',' or ';' as needed. Most of the servers are using ';'
                conn.setRequestProperty("Cookie",
                        TextUtils.join(";",  msCookieManager.getCookieStore().getCookies()));
            }

            int httpStatus = conn.getResponseCode();
            System.out.println("HTTP ERROR CODE "+httpStatus+ " - USING METHOD "+conn.getRequestMethod());

            if(httpStatus==200){
                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                String output;
                sb=new StringBuilder();

                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                out=sb.toString();
            }else{
                out=new JsonIn().simpleOut("001", "Transaksi Gagal");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out=new JsonIn().simpleOut("001", "Tidak ada data");
        }

        return out;
    }

//    public void ignoreSSL(){
//        try {
//            // Create a trust manager that does not validate certificate chains
//            TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
//                public X509Certificate[] getAcceptedIssuers() {
//                    return null;
//                }
//                public void checkClientTrusted(X509Certificate[] certs, String authType) {
//                }
//                public void checkServerTrusted(X509Certificate[] certs, String authType) {
//                }
//            }
//            };
//
//            // Install the all-trusting trust manager
//            //SSLContext sc = SSLContext.getInstance("SSL");
//            SSLContext sc = SSLContext.getInstance("TLS");
//            sc.init(null, trustAllCerts, new java.security.SecureRandom());
//            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
//
//            // Create all-trusting host name verifier
//            HostnameVerifier allHostsValid = new HostnameVerifier() {
//                public boolean verify(String hostname, SSLSession session) {
//                    String url=new Wong().getUrlServer();
//                    if (! hostname.equalsIgnoreCase(url))
//                        return true;
//                    else
//                        return false;
//                }
//            };
//
//            // Install the all-trusting host verifier
//            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
//        } catch (KeyManagementException ex) {
//            //Logger.getLogger(Ssl.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (NoSuchAlgorithmException ex) {
//            //Logger.getLogger(Ssl.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
    //-------production

    private HttpsURLConnection httpsConnection(URL url){

        InputStream caInput=null;
        HttpsURLConnection urlConnection = null;
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            AssetManager am=Wong.getAssetManager();
            caInput =am.open("bitplus.crt");

            Certificate ca = cf.generateCertificate(caInput);
            System.out.println("ca=" + ((X509Certificate) ca).getSubjectDN());

            // Create a KeyStore containing our trusted CAs
            String keyStoreType = KeyStore.getDefaultType();
            KeyStore keyStore = KeyStore.getInstance(keyStoreType);
            keyStore.load(null, null);
            keyStore.setCertificateEntry("ca", ca);

            // Create a TrustManager that trusts the CAs in our KeyStore
            String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
            tmf.init(keyStore);

            // Create an SSLContext that uses our TrustManager
            SSLContext context = SSLContext.getInstance("TLS");
            context.init(null, tmf.getTrustManagers(), null);

            // Tell the URLConnection to use a SocketFactory from our SSLContext

            urlConnection.setDefaultHostnameVerifier(new HostnameVerifier()
            {
                @Override
                public boolean verify(String hostname, SSLSession session)
                {
                    return true;
                }
            });

            urlConnection =(HttpsURLConnection)url.openConnection();
            urlConnection.setSSLSocketFactory(context.getSocketFactory());
        } catch (Exception e){
            e.printStackTrace();
            //Log.e("ca_install",e.getMessage());
        } finally {
            try {
                if(caInput != null){
                    caInput.close();
                }
            }catch (Exception ex){
            }
        }
        return urlConnection;
    }

}
