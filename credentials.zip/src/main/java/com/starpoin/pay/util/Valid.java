package com.starpoin.pay.util;

/**
 * Created by acer on 12/07/2018.
 */

public class Valid {

    public boolean isValidEmail(String email) {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);
        return m.matches();
    }

    public static String encrypt(String plaintext) {
        String ciphertext = "";
        int shift = 3;
        for (int i = 0; i < plaintext.length(); i++) {
            char c = plaintext.charAt(i);
            if (Character.isLetter(c)) {
                c = (char) ((c + shift - 'a') % 26 + 'a');
            } else if (Character.isDigit(c)) {
                c = (char) ((c + shift - '0') % 10 + '0');
            }
            ciphertext += c;
        }
        return ciphertext;
    }

    public static String decrypt(String ciphertext) {
        String plaintext = "";
        int shift = 3;
        for (int i = 0; i < ciphertext.length(); i++) {
            char c = ciphertext.charAt(i);
            if (Character.isLetter(c)) {
                c = (char) ((c - shift - 'a' + 26) % 26 + 'a');
            } else if (Character.isDigit(c)) {
                c = (char) ((c - shift - '0' + 10) % 10 + '0');
            }
            plaintext += c;
        }
        return plaintext;
    }

}
