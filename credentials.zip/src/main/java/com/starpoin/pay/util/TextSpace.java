package com.starpoin.pay.util;

public class TextSpace {

    public static String rataTengah(String text) {
        //int width = 42;
        String s = "";
        int x = 0;

        while(x < 15 - text.length() /2){
            s+=" ";
            x++;
        }
        s += text;

        return s;
    }

    public static String rataKiri(String label,String ttk2,String value) {
        //int width = 42;
        String s = "";
        int x = 0;

        s += label;

        while(x < 14 - label.length()){
            s+=" ";
            x++;
        }
        s+=ttk2;

        while(x < 16 - label.length()-ttk2.length()){
            s+=" ";
            x++;
        }
        s+=value;

        return s;
    }
}
