package com.starpoin.pay;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.starpoin.pay.model.Response;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PrintView extends AppCompatActivity {

    private int produk;
    private String result;
    private double amount;
    private double nominal;
    private String trxid;
    private String noid;
    private String kode;
    private String admin;
    private String time;

    private LinearLayout rootLayout;
    private Button btnBayar,btnCetak;
    private TextView tvAmount;
    private TextView adminbank, timestamp, ref_id, rptag;

    private String payResponse;
    private final Response response=new Response();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_print_view);

        this.setTitle("");

        produk=response.getExtraInt(this,"produk");
        result=response.getExtraString(this,"result");
        amount=response.getExtraDouble(this,"amount");
        trxid=response.getExtraString(this,"trxid");
        noid=response.getExtraString(this,"noid");
        kode=response.getExtraString(this,"kode");
        time=response.getExtraString(this, "time");
        admin=response.getExtraString(this, "admin");
        nominal=response.getExtraDouble(this, "nominal");

        rootLayout=(LinearLayout) findViewById(R.id.printLayout);

        tvAmount=(TextView) findViewById(R.id.tvAmount);
        tvAmount.setText("Rp."+new DecimalFormat("#,##0").format(amount));

        ref_id=(TextView) findViewById(R.id.ref_id);
        ref_id.setText(trxid);

        adminbank=(TextView) findViewById(R.id.admin);
        adminbank.setText("Rp."+new DecimalFormat("#,##0").format(Double.parseDouble(admin)));

        timestamp=(TextView) findViewById(R.id.time);

        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy | HH:mm:ss").format(date);
        timestamp.setText(formattedDate+" WIB");

        rptag=(TextView) findViewById(R.id.nominal);
        rptag.setText("Rp."+new DecimalFormat("#,##0").format(nominal));

    }
}