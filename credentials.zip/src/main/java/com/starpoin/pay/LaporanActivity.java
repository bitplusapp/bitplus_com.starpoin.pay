package com.starpoin.pay;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.adapter.LaporanAdapter;
import com.starpoin.pay.adapter.ListProductAdapter;
import com.starpoin.pay.model.LapTrans;
import com.starpoin.pay.model.LapTransaksi;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.util.DateParse;
import com.starpoin.pay.util.DatePick;
import com.starpoin.pay.util.JsonIn;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class LaporanActivity extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;
    private RecyclerView rvDenom;
    private LinearLayout lyAmount;
    private Button btndrtgl,btnsdtgl, btnShowProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laporan);

        this.setTitle("Laporan Transaksi");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
        rvDenom=findViewById(R.id.rvDenom);
        lyAmount=(LinearLayout) findViewById(R.id.lyAmount);

        btndrtgl=(Button) findViewById(R.id.btndrtgl);
        btndrtgl.setOnClickListener(this);

        btnsdtgl=(Button) findViewById(R.id.btnsdtgl);
        btnsdtgl.setOnClickListener(this);

        btnShowProduct = findViewById(R.id.btnShowProduct);
        btnShowProduct.setOnClickListener(this);

        String tgl=new SimpleDateFormat("dd/MM/yyyy").format(new Date());
        btndrtgl.setText(tgl);
        btnsdtgl.setText(tgl);

        //viewProduk();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btndrtgl:
                new DatePick(LaporanActivity.this,btndrtgl).onClick(v);

                break;
            case R.id.btnsdtgl:
                new DatePick(LaporanActivity.this,btnsdtgl).onClick(v);
                break;
            case R.id.btnShowProduct:
                showBottomSheetDialogProductList();
                break;
        }
    }

    private void showBottomSheetDialogProductList() {
        lyAmount.setVisibility(View.GONE);
        ArrayList<LapTrans> list=new LapTrans().listProduk();
        final BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.bottom_sheet_dialog_product);

        final ListView lv = dialog.findViewById(R.id.lvProduct);
        lv.setAdapter(new ListProductAdapter(this, list));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                LapTrans lapTrans = (LapTrans) lv.getItemAtPosition(position);
                btnShowProduct.setText(lapTrans.getLabel());
                inquery(lapTrans);
                dialog.dismiss();
            }
        });
        // Get the height of the screen
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenHeight = displayMetrics.heightPixels;
        dialog.getBehavior().setPeekHeight(screenHeight);
        dialog.show();
    }

    private void inquery(LapTrans lap){
        String str1=btndrtgl.getText().toString();
        String str2=btnsdtgl.getText().toString();
        if(!str1.contains("/")||!str2.contains("/")){
            showMsg("Tanggal belum dipilih");
            return;
        }
        String drtgl=new DateParse().tglDefault(str1);
        String sdtgl=new DateParse().tglDefault(str2);
        String params="report/trans/"+lap.getKey()+"/"+drtgl+"/"+sdtgl+"'";
        OtherTask task = new OtherTask(LaporanActivity.this,LaporanActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc").trim();
                if(rc.equals("000")||rc.equals("0000")){
                    viewContent(content);
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }

            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewContent(String content){
        rvDenom.removeAllViews();
        LapTransaksi lap=new LapTransaksi();
        ArrayList<LapTransaksi> list=lap.getListJson(content);
        LaporanAdapter adapter=new LaporanAdapter(LaporanActivity.this,list);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);

        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);

        lyAmount.setVisibility(View.VISIBLE);

        TextView tvTotalAmount=(TextView) findViewById(R.id.tvTotalAmount);
        TextView tvTotalItem=(TextView) findViewById(R.id.tvTotalItem);
//        Button btnClear=(Button) findViewById(R.id.btnClear);
//        btnClear.setOnClickListener(this);

        double amount=lap.getTotalAmount();
        int item=list.size();
        DecimalFormat df=new DecimalFormat("#,##0");
        tvTotalAmount.setText("Rp "+ df.format(amount));
        tvTotalItem.setText(df.format(item)+" Transaksi");

    }
}