package com.starpoin.pay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.LapTiketAdapter;
import com.starpoin.pay.model.LapTiket;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.util.JsonIn;

import java.util.ArrayList;

public class LapTiketActivity extends AbaseActivity {

    private ConstraintLayout rootLayout;
    private RecyclerView rvDenom;
    private LinearLayout layoutEmpty, layoutData;
    private ImageButton btnTopup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lap_tiket);

        this.setTitle("Status Topup");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
        rvDenom=findViewById(R.id.rvDenom);

        layoutData = findViewById(R.id.layoutData);
        layoutEmpty = findViewById(R.id.layoutEmpty);
        btnTopup = findViewById(R.id.btnTopup);
        btnTopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LapTiketActivity.this, TiketActivity.class));
            }
        });

        reqLap();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void reqLap(){
        String params="ticket";

        OtherTask task = new OtherTask(this,LapTiketActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("000")||rc.equals("0000")){
                    viewContent(content);
                    layoutEmpty.setVisibility(View.GONE);
                    layoutData.setVisibility(View.VISIBLE);
                }else{
                    layoutEmpty.setVisibility(View.VISIBLE);
                    layoutData.setVisibility(View.GONE);
                }

            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewContent(String content){
        ArrayList<LapTiket> list=new LapTiket().listContent(content);
        LapTiketAdapter adapter=new LapTiketAdapter(LapTiketActivity.this,list);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);
    }


}