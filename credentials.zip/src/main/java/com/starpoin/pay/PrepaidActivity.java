package com.starpoin.pay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.PrepaidAdapter;
import com.starpoin.pay.model.Prepaid;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class PrepaidActivity extends AbaseActivity implements View.OnClickListener {

    private static final int SCAN_REQ =1;
    private ConstraintLayout rootLayout;
    private RecyclerView rvDenom;
    private ArrayList<Prepaid> listDenom;
    private Prepaid selectedDenom;
    private Button btnScan;
    private EditText etNomor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prepaid);

        setBarTitle("Token Listrik");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
        etNomor=(EditText) findViewById(R.id.etNomor);


        btnScan=(Button) findViewById(R.id.btnScan);
        btnScan.setOnClickListener(this);

        listDenom=new Prepaid().listDenom();
        PrepaidAdapter preAdapter=new PrepaidAdapter(this,listDenom);
        GridLayoutManager layoutManager=new GridLayoutManager(this,3);

        rvDenom=findViewById(R.id.rvDenom);

        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(preAdapter);
        preAdapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                selectedDenom=listDenom.get(position);
                String no=etNomor.getText().toString().trim();
                String nominal=selectedDenom.getValue();
                inquery(no,nominal);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK){
            switch (requestCode){
                case SCAN_REQ:
                    String kode_barcode = data.getStringExtra("barcode");
                    etNomor.setText(kode_barcode);
                    break;
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnScan:
                Intent intent = new Intent(this, ScanBarcodeActivity.class);
                startActivityForResult(intent, SCAN_REQ);
                break;
        }
    }

    private void inquery(String no,String nominal){
        if(no.length()<10){
            showMsg("Nomor Meter / Pelanggan belum sesuai");
            return;
        }

        Map<String,Object> map=new Prepaid().paramsInq(no, nominal);
        String params= new JSONObject(map).toString();
        TransTask task = new TransTask(PrepaidActivity.this,PrepaidActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc = json.getString(content,"rc");
                String data = json.getString(content, "data");
                if(rc.equals("0000")){
                    String trxid= json.getString(data,"ref_id");
                    double amount =Double.parseDouble(json.getString(data,"amount"));
                    String admin = json.getString(data, "admin");
                    String time = json.getString(data, "time");
                    double denom = Long.parseLong(nominal);
                    String token = json.hasNameObj(data, "token");
                    Intent intent=new Intent(PrepaidActivity.this,ResponseActivity.class);
                    intent.putExtra("produk", Produk.PREPAID);
                    intent.putExtra("trxid", trxid);
                    intent.putExtra("result", content);
                    intent.putExtra("noid", no);
                    intent.putExtra("amount", amount);
                    intent.putExtra("admin", admin);
                    intent.putExtra("time", time);
                    intent.putExtra("nominal", denom);
                    intent.putExtra("additional", nominal);
                    startActivity(intent);

                    etNomor.setText("");

                }else{
                    String desc= json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);

    }



}