package com.starpoin.pay;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.WorkerThread;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.PaketDataAdapter;
import com.starpoin.pay.model.ProdukProvider;
import com.starpoin.pay.model.Pulsa;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class PaketdataActivity extends AbaseActivity implements View.OnClickListener {

    private final static int PICK_CONTACT = 0;
    private ConstraintLayout rootLayout;

    private Pulsa selectedDenom;
    private EditText etNomor;
    private Button btnContact;
    private ArrayList<ProdukProvider> listProduk;
    private ArrayList<Pulsa> LIST_DENOM=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paketdata);

        setBarTitle("Paket Data");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        etNomor=(EditText) findViewById(R.id.etNomor);
        etNomor.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int txtSize=etNomor.getText().toString().length();

                if(txtSize==4){
                    workerThread();
                }else if(txtSize==0){
                    workerThread();
                }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }
            @Override
            public void afterTextChanged(Editable s) {
                //paste listener
                int list_size=LIST_DENOM.size();
                if(list_size==0){
                    int txtSize=etNomor.getText().toString().length();

                    if(txtSize>=10){
                        workerThread();
                    }else if(txtSize==0){
                        workerThread();
                    }
                }
            }
        });

        btnContact=(Button) findViewById(R.id.btnContact);
        btnContact.setOnClickListener(this);

        reqProdukProvider();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnContact:
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
                startActivityForResult(intent, PICK_CONTACT);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            switch (requestCode) {
                case (PICK_CONTACT):
                    if (resultCode == RESULT_OK) {
                        Cursor cursor = getContentResolver().query(data.getData(), new String[] {ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);

                        // True if the cursor is not empty
                        cursor.moveToFirst();
                        String number = cursor.getString((int) 0);

                        if (number.length() > 0 && number.substring(0, 1).equals("+")) {
                            number = "0" + number.substring(3);
                        }

                        etNomor.setText(number.replace("-", "").replace(" ", ""));
                        workerThread();
                    }

                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void reqProdukProvider(){

        String params = "products/voucher/data";
        OtherTask task = new OtherTask(PaketdataActivity.this,PaketdataActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                listProduk=new ProdukProvider().listProdukVoucher(content);
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }





    private void viewDenom(ArrayList<Pulsa> listDenom){
        PaketDataAdapter adapter=new PaketDataAdapter(PaketdataActivity.this,listDenom);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);
        RecyclerView rvDenom=findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);
        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                selectedDenom=listDenom.get(position);
                String no=etNomor.getText().toString().trim();
                int nosize=no.length();
                if(nosize<10){
                    showMsg("Nomor belum sesuai");
                    return;
                }
                String kodeProd=selectedDenom.getKode();
                inquery(no,kodeProd);
            }
        });
    }

    private void inquery(String no,String idProduk){
        if(no.length()<10){
            showMsg("Nomor Meter / Pelanggan belum sesuai");
            return;
        }

        Map<String,Object> map = new Pulsa().paramsInq(no,idProduk,"data");
        String params= new JSONObject(map).toString();
        TransTask task = new TransTask(PaketdataActivity.this,PaketdataActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")){
                    String trxid=json.getObjectWithString(content,"data", "ref_id");
                    double amount =Double.parseDouble(json.getObjectWithString(content,"data", "price"));
                    String admin = "0";
                    double nominal = amount;
                    String time = json.getObjectWithString(content,"data", "time");
                    String voucher_code = json.getObjectWithString(content,"data", "voucher_code");
                    Intent intent=new Intent(PaketdataActivity.this, ResponseActivity.class);
                    intent.putExtra("produk", Produk.PAKETDATA);
                    intent.putExtra("result", content);
                    intent.putExtra("nominal", nominal);
                    intent.putExtra("amount", amount);
                    intent.putExtra("trxid", trxid);
                    intent.putExtra("admin", admin);
                    intent.putExtra("time", time);
                    intent.putExtra("noid", no);
                    intent.putExtra("additional", voucher_code); //tambahan parameter
                    startActivity(intent);

                    etNomor.setText("");
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);

    }

    @WorkerThread
    void workerThread(){
        ContextCompat.getMainExecutor(PaketdataActivity.this).execute(new Runnable() {
            @Override
            public void run() {

                int txtsize=etNomor.getText().toString().length();
                //Log.i("txtsize",String.valueOf(txtsize));
                if(txtsize>=4){
                    String no=etNomor.getText().toString().trim();
                    String subno=no.substring(0,4);
                    LIST_DENOM=new Pulsa().listDenomPulsa(listProduk,subno,"data");
                    viewDenom(LIST_DENOM);
                }else if(txtsize==0){
                    LIST_DENOM=new ArrayList<>();
                    viewDenom(LIST_DENOM);
                }
            }
        });
    }
}