package com.starpoin.pay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.adapter.BankAdapter;
import com.starpoin.pay.model.Bank;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.NumberTextWatcher;
import com.starpoin.pay.util.Wong;

import java.util.ArrayList;

public class TiketActivity extends AbaseActivity implements View.OnClickListener {

    private RelativeLayout rootLayout;
    private LinearLayout layoutNoRekening;
    private Bank selectedBank;
    private int selectedRow=0;
    //private Spinner spinner;
    private Button btnTiket;
    private EditText etJumlah;
    private ImageButton btnBack;
    private TextView tvNoRekening;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tiket_new);

        getSupportActionBar().hide();

        setBarTitle("");

        rootLayout=(RelativeLayout) findViewById(R.id.rootLayout);

        etJumlah=findViewById(R.id.etJumlah);
        etJumlah.addTextChangedListener(new NumberTextWatcher(etJumlah));

        btnBack = (ImageButton) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);

        btnTiket=findViewById(R.id.btnTiket);
        btnTiket.setOnClickListener(this);

        layoutNoRekening = (LinearLayout) findViewById(R.id.layoutNoRekening);
        tvNoRekening = (TextView) findViewById(R.id.tvNoRekening);

        viewBankList();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnTiket:
                //buatTiket();
                confirmasi();
                break;
            case R.id.btnBack:
                this.finish();
                break;
        }
    }

    private void viewBankList(){
        ArrayList<Bank> listBank=new Bank().listBank();
        BankAdapter adapter=new BankAdapter(TiketActivity.this,listBank,selectedRow);
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);
        RecyclerView rvDenom=findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);
        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                selectedRow=position;
                selectedBank=listBank.get(position);
                layoutNoRekening.setVisibility(View.VISIBLE);
                switch (selectedBank.getBankCode()) {
                    case "002":
                        //bri
                        tvNoRekening.setText("0601-01-000376-30-2");
                        break;
                    case "008":
                        //mandiri
                        tvNoRekening.setText("134000-9782-904");
                        break;
                    case "009":
                        //bni
                        tvNoRekening.setText("0374-1564-30");
                        break;
                    case "014":
                        //bca
                        tvNoRekening.setText("134-1655-001");
                        break;
                    default:
                        tvNoRekening.setText("0601-01-000376-30-2");
                        break;
                }
                viewBankList();

            }
        });

        if(selectedRow==0){
            selectedBank=listBank.get(0);
        }

    }

    private void buatTiket(){
        String jum=etJumlah.getText().toString().trim().replaceAll("\\.","").replaceAll(",","");

        if(etJumlah.length()<4){
            showMsg("Jumlah belum sesuai");
            return;
        }

        String params="ticket/process/"+selectedBank.getBankCode()+"/"+jum;

        OtherTask task = new OtherTask(TiketActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")||rc.equals("000")) {
                    //pbar.setVisibility(View.VISIBLE);
                    String data=json.getString(content,"data");
                    String amount = json.getString(data,"amount");
                    simpanTiket(jum, amount);
                    //viewContent(content);
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void confirmasi(){
        String jum=etJumlah.getText().toString().trim();
        if(jum.length()<4){
            showMsg("Jumlah belum sesuai");
            return;
        }
        String bankName=selectedBank.getBankName();
        String msg="Buat tiket Dari Bank "+bankName +" ?";

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.confirmasi_dialog);
        //ImageButton btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        Button btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //bottomSheetDialog.cancel();
                bottomSheetDialog.dismiss();
            }
        });
        Button btnBatal=bottomSheetDialog.findViewById(R.id.btnBatal);
        btnBatal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //bottomSheetDialog.cancel();
                bottomSheetDialog.dismiss();
            }
        });
        Button btnOk=bottomSheetDialog.findViewById(R.id.btnOk);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
                buatTiket();
            }
        });

        TextView tvMsg=bottomSheetDialog.findViewById(R.id.tvMsg);
        tvMsg.setText(msg);

        bottomSheetDialog.show();

    }

    private void simpanTiket(String jum,String tiket){
        String params="ticket/create/"+selectedBank.getBankCode()+"/"+jum+"/"+tiket;
        OtherTask task = new OtherTask(TiketActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")||rc.equals("000")) {
                    //btnTiket.setEnabled(false);
                    String data = json.getString(content, "data");
                    String time = json.getString(data, "time");
                    Intent intent=new Intent(TiketActivity.this,TicketResultActivity.class);
                    intent.putExtra("time", time);
                    intent.putExtra("id_merchant", Wong.getIdmerch());
                    intent.putExtra("result", content);
                    intent.putExtra("amount", json.getString(data, "amount"));
                    //pbar.setVisibility(View.GONE);
                    etJumlah.setText("");
                    startActivity(intent);
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }


}