package com.starpoin.pay;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import me.dm7.barcodescanner.zbar.Result;
import me.dm7.barcodescanner.zbar.ZBarScannerView;

public class ScanBarcodeActivity extends Activity implements ZBarScannerView.ResultHandler {

    private ZBarScannerView mScannerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_scan_barcode);

        mScannerView = new ZBarScannerView(this);    // Programmatically initialize the scanner view
        setContentView(mScannerView);
    }

    @Override
    public void handleResult(Result rawResult) {
        String kode=rawResult.getContents();
        //Log.i("kode_bar",kode);

        Intent intent = new Intent();
        intent.putExtra("barcode", kode);
        setResult(RESULT_OK, intent);
        mScannerView.stopCamera();
        finish();

    }



    @Override
    public void onBackPressed(){
        onPause();
        finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        mScannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
        mScannerView.startCamera();          // Start camera on resume
    }

    @Override
    public void onPause() {
        super.onPause();

        mScannerView.stopCamera();           // Stop camera on pause
    }
}
