package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.LapCashback;

import java.util.ArrayList;
import java.util.List;

public class LapCashbackAdapter extends RecyclerView.Adapter<LapCashbackAdapter.RecyclerViewHolder> {
    List<LapCashback> data = new ArrayList<>();
    Context context;


    public LapCashbackAdapter(Context context, ArrayList<LapCashback> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder  onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lap_cashback_adapter, viewGroup, false);

        return new RecyclerViewHolder (view);
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder  holder, int position) {
        LapCashback model = data.get(position);
        //holder.lbl_noid.setText("");
        holder.val_noid.setText(model.getProduk());
        //holder.lbl_nama.setText("");
        holder.val_nama.setText(model.getCashback());

    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView lbl_noid;
        TextView val_noid;
        TextView lbl_nama;
        TextView val_nama;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            lbl_noid = itemView.findViewById(R.id.lbl_noid);
            val_noid = itemView.findViewById(R.id.val_noid);
            lbl_nama = itemView.findViewById(R.id.lbl_nama);
            val_nama = itemView.findViewById(R.id.val_nama);
        }
    }

}
