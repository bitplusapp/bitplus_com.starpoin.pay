package com.starpoin.pay.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.OnBoarding;
import com.starpoin.pay.R;

import java.util.List;

public class ViewPagerOnBoardingAdapter extends RecyclerView.Adapter<ViewPagerOnBoardingAdapter.onBoardingViewHolder> {

    List<OnBoarding> pages;

    public ViewPagerOnBoardingAdapter(@NonNull List<OnBoarding> pages) {
        this.pages = pages;

    }

    @Override @NonNull
    public ViewPagerOnBoardingAdapter.onBoardingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewPagerOnBoardingAdapter.onBoardingViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.onboarding,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewPagerOnBoardingAdapter.onBoardingViewHolder holder, int position) {
        holder.imageView.setImageResource(pages.get(position).getImage());
        holder.heading.setText(pages.get(position).getTitle());
        holder.description.setText(pages.get(position).getDescription());
    }

    @Override
    public int getItemCount() {
        return pages.size();
    }

    protected static class onBoardingViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView heading;
        TextView description;
        public onBoardingViewHolder(View view) {
            super(view);
            imageView = view.findViewById(R.id.image);
            heading    = view.findViewById(R.id.heading);
            description= view.findViewById(R.id.description);
        }
    }
}
