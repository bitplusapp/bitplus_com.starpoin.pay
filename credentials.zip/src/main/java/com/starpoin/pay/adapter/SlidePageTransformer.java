package com.starpoin.pay.adapter;

import android.view.View;

import androidx.viewpager.widget.ViewPager;

public class SlidePageTransformer implements ViewPager.PageTransformer {
    private static final float MIN_SCALE = 0.75f;
    private static final float MIN_ALPHA = 0.5f;
    private static final float MAX_BOUNCE_SCALE = 0.9f;

    public void transformPage(View view, float position) {
        int pageWidth = view.getWidth();
        int pageHeight = view.getHeight();

        if (position < -1) { // Page to the left of the screen
            view.setAlpha(0f);
        } else if (position <= 1) { // Page in the center of the screen
            float scaleFactor = Math.max(MIN_SCALE, 1 - Math.abs(position));
            float vertMargin = pageHeight * (1 - scaleFactor) / 2;
            float horzMargin = pageWidth * (1 - scaleFactor) / 2;

            if (position < 0) {
                view.setTranslationX(horzMargin - vertMargin / 2);
            } else {
                view.setTranslationX(-horzMargin + vertMargin / 2);
            }

            view.setScaleX(scaleFactor);
            view.setScaleY(scaleFactor);

            view.setAlpha(MIN_ALPHA +
                    (scaleFactor - MIN_SCALE) /
                            (1 - MIN_SCALE) * (1 - MIN_ALPHA));

        } else { // Page to the right of the screen
            view.setAlpha(0f);
        }

        // Add bounce effect on click
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.animate()
                        .scaleX(MAX_BOUNCE_SCALE)
                        .scaleY(MAX_BOUNCE_SCALE)
                        .setDuration(100)
                        .withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100);
                            }
                        });
            }
        });
    }
}
