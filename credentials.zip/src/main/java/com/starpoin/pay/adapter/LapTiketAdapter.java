package com.starpoin.pay.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.LapTiket;

import java.util.ArrayList;
import java.util.List;

public class LapTiketAdapter extends RecyclerView.Adapter<LapTiketAdapter.RecyclerViewHolder>{

    List<LapTiket> data = new ArrayList<>();
    Context context;

    public LapTiketAdapter(Context context, List<LapTiket> data){
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lap_tiket_adapter, parent, false);

        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LapTiketAdapter.RecyclerViewHolder holder, int position) {
        LapTiket item=data.get(position);
//        holder.val_tanggal.setText(item.getTanggal());
//        holder.val_tiket.setText(item.getTiket());
//        holder.val_bank.setText(item.getBank());
//        holder.val_status.setText(item.getStatus());
        switch (item.getBank()) {
            case "BRI":
                holder.val_bank.setImageResource(R.drawable.ic_bri);
                break;
            case "Mandiri":
                holder.val_bank.setImageResource(R.drawable.ic_mandiri);
                break;
            case "BNI":
                holder.val_bank.setImageResource(R.drawable.ic_bni);
                break;
            case "BCA":
                holder.val_bank.setImageResource(R.drawable.ic_bca);
                break;
            default:
                holder.val_bank.setImageResource(R.drawable.info_rekening);
                break;
        }
        int colorRes = R.color.bootstrap_success;
        switch (item.getStatus()) {
            case "Menunggu":
                holder.vStatus.setBackgroundResource(R.color.bootstrap_warning);
                colorRes = R.color.bootstrap_warning;
                break;
            case "Sukses":
                holder.vStatus.setBackgroundResource(R.color.bootstrap_success);
                break;
            default:
                holder.vStatus.setBackgroundResource(R.color.bootstrap_primary);
                colorRes = R.color.bootstrap_primary;
                break;
        }
        int color = ContextCompat.getColor(context, colorRes);
        holder.val_status.setTextColor(color);
        holder.val_tiket.setText("+"+item.getTiket());
        holder.val_status.setText(item.getStatus());
        holder.val_tanggal.setText(item.getTanggal());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        Button val_tanggal;
        TextView val_tiket;
        ImageView val_bank;
        TextView val_status;
        View vStatus;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            val_tanggal = itemView.findViewById(R.id.btnTime);
            val_tiket = itemView.findViewById(R.id.val_tiket);
            val_bank = itemView.findViewById(R.id.ivBank);
            val_status = itemView.findViewById(R.id.val_status);
            vStatus = itemView.findViewById(R.id.leftLineView);
        }
    }
}
