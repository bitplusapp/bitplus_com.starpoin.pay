package com.starpoin.pay.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Game;

import java.util.ArrayList;
import java.util.List;

public class GameProviderAdapter extends RecyclerView.Adapter<GameProviderAdapter.RecyclerViewHolder>{

    List<Game> data = new ArrayList<>();
    Context context;
    private View.OnClickListener mOnItemClickListener;

    public GameProviderAdapter(Context context, ArrayList<Game> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public GameProviderAdapter.RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        //View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.prepaid_denom_adapter, viewGroup, false);
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.topup_provider, viewGroup, false);

        return new GameProviderAdapter.RecyclerViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(GameProviderAdapter.RecyclerViewHolder holder, int position) {
        Game game = data.get(position);
        String prov=game.getProvider();
        Drawable img=context.getDrawable(R.drawable.ic_game_24);
        if(prov.contains("Battle")){
            img=context.getDrawable(R.drawable.battle);
        }else if(prov.contains("FREE FIRE")){
            img=context.getDrawable(R.drawable.free_fire);
        }else if(prov.contains("Gemscool")){
            img=context.getDrawable(R.drawable.gemscool);
        }else if(prov.contains("Google Play")){
            img=context.getDrawable(R.drawable.google_play);
        }else if(prov.contains("Itunes")){
            img=context.getDrawable(R.drawable.itunes);
        }else if(prov.contains("Lyto")){
            img=context.getDrawable(R.drawable.lyto);
        }else if(prov.contains("Megaxus")){
            img=context.getDrawable(R.drawable.megaxus);
        }else if(prov.contains("MLBB")||prov.contains("Mobile Legend")){
            img=context.getDrawable(R.drawable.mobile_legend);
        }else if(prov.contains("Playstation")){
            img=context.getDrawable(R.drawable.playstation_store);
        }else if(prov.contains("PUBG")){
            img=context.getDrawable(R.drawable.pubg);
        }else if(prov.contains("Nintendo")){
            img=context.getDrawable(R.drawable.nintendo);
        }else if(prov.contains("Steam")){
            img=context.getDrawable(R.drawable.steam);
        }else if(prov.contains("Travian")){
            img=context.getDrawable(R.drawable.travian);
        }else if(prov.contains("Xbox")){
            img=context.getDrawable(R.drawable.xbox);
        }else if(prov.contains("MOGCAZ")){
            img=context.getDrawable(R.drawable.mogcaz);
        }else if(prov.contains("MOGPlay")){
            img=context.getDrawable(R.drawable.mogplay);
        }
        holder.tvProvider.setText(prov);
        holder.imgProvider.setImageDrawable(img);

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {

        //TextView tvProvider;
        TextView tvProvider;
        ImageView imgProvider;
        //CardView cv;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvProvider = itemView.findViewById(R.id.tvProvider);
            imgProvider = itemView.findViewById(R.id.imgProvider);
            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }
}
