package com.starpoin.pay.adapter;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View view, int position);
}
