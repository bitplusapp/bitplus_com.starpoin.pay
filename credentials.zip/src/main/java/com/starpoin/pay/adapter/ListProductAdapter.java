package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.LapTrans;

import java.util.List;

public class ListProductAdapter extends ArrayAdapter<LapTrans> {

    public ListProductAdapter(Context context, List<LapTrans> items) {
        super(context, R.layout.products_item_list, items);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.products_item_list, parent, false);
        }

        TextView textView = convertView.findViewById(R.id.tvLabelProduk);
        LapTrans item = getItem(position);
        textView.setText(item.getLabel());
        ImageView imageProduct = convertView.findViewById(R.id.ivPdam);

        switch (item.getKey()) {
            case LapTrans.PASKABAYAR:
                imageProduct.setImageResource(R.drawable.paska_bayar);
                break;
            case LapTrans.BPJS:
                imageProduct.setImageResource(R.drawable.bpjs);
                break;
            case LapTrans.JASTEL:
                imageProduct.setImageResource(R.drawable.telkom);
                break;
            case LapTrans.NONTAGLIS:
                imageProduct.setImageResource(R.drawable.nontaglis);
                break;
            case LapTrans.VOUCHER:
                imageProduct.setImageResource(R.drawable.voucher);
                break;
            case LapTrans.PBB:
                imageProduct.setImageResource(R.drawable.pbb);
                break;
            case LapTrans.PDAM:
                imageProduct.setImageResource(R.drawable.pdam);
                break;
            case LapTrans.TVCABLE:
                imageProduct.setImageResource(R.drawable.tv_cable);
                break;
            case LapTrans.PREPAID:
                imageProduct.setImageResource(R.drawable.prepaid);
                break;
            case LapTrans.POSTPAID:
                imageProduct.setImageResource(R.drawable.postpaid);
                break;
            default:
                imageProduct.setImageResource(R.drawable.other_product);
                break;
        }

        return convertView;
    }

}