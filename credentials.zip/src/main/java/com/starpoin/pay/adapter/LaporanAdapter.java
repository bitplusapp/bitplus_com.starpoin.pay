package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.LapTransaksi;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LaporanAdapter extends RecyclerView.Adapter<LaporanAdapter.RecyclerViewHolder> {
    List<LapTransaksi> data = new ArrayList<>();
    Context context;


    public LaporanAdapter(Context context, ArrayList<LapTransaksi> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder  onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.laptrans_adapter, viewGroup, false);

        return new RecyclerViewHolder (view);
    }

    private String timestampFormattedWIB(String timestamp) {
        String input = timestamp;
        SimpleDateFormat inputFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        try {
            Date date = inputFormatter.parse(input);
            SimpleDateFormat outputFormatter = new SimpleDateFormat("d MMM yyyy | HH:mm:ss");
            String output = outputFormatter.format(date);
            return output+" WIB";
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return input;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder  holder, int position) {
        DecimalFormat df=new DecimalFormat("#,##0");
        LapTransaksi model = data.get(position);
        holder.name.setText(model.getNama());
        holder.subsID.setText(model.getNoid());
        holder.transType.setText(model.getProduk().toUpperCase());
        holder.lap_labeldesc.setText(model.getLbl_blth());
        holder.description.setText(model.getBlth());
        String samount=model.getAmount();
        holder.amount.setText("-Rp "+df.format(Integer.parseInt(samount)));
        holder.dateTime.setText(timestampFormattedWIB(model.getDatetime()));

        String produk = model.getProduk().toLowerCase();

        if(produk.contains("postpaid")) {
            holder.ivProduct.setImageResource(R.drawable.postpaid);
        }else if(produk.contains("prepaid")) {
            holder.ivProduct.setImageResource(R.drawable.prepaid);
        }else if(produk.contains("nontaglis")) {
            holder.ivProduct.setImageResource(R.drawable.nontaglis);
        }else if(produk.contains("pdam")) {
            holder.ivProduct.setImageResource(R.drawable.pdam);
        }else if(produk.contains("tv")) {
            holder.ivProduct.setImageResource(R.drawable.tv_cable);
        }else if(produk.contains("pbb")) {
            holder.ivProduct.setImageResource(R.drawable.pbb);
        }else if(produk.contains("bpjs")) {
            holder.ivProduct.setImageResource(R.drawable.bpjs);
        }else if(produk.contains("voucher")) {
            holder.ivProduct.setImageResource(R.drawable.voucher);
        }else if(produk.contains("telkom")) {
            holder.ivProduct.setImageResource(R.drawable.telkom);
        }else if(produk.contains("bayar")) {
            holder.ivProduct.setImageResource(R.drawable.paska_bayar);
        }

    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        ImageView ivProduct;
        TextView subsID;
        TextView name;
        TextView transType;
        TextView description;
        TextView amount;
        TextView dateTime;
        TextView lap_labeldesc;//blth atau token

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            //tvDenom = itemView.findViewById(R.id.tvDesc);
            ivProduct=itemView.findViewById(R.id.ivProduct);
            name = itemView.findViewById(R.id.lap_valnama);
            subsID = itemView.findViewById(R.id.lap_valsubsID);
            transType = itemView.findViewById(R.id.lap_valtransType);
            lap_labeldesc = itemView.findViewById(R.id.lap_labeldesc);
            description = itemView.findViewById(R.id.lap_valdescription);
            amount = itemView.findViewById(R.id.lap_valamount);
            dateTime = itemView.findViewById(R.id.lap_val_datetime);
        }
    }

}
