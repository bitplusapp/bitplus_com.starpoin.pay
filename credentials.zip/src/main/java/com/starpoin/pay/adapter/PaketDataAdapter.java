package com.starpoin.pay.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Pulsa;

import java.util.ArrayList;
import java.util.List;

public class PaketDataAdapter extends RecyclerView.Adapter<PaketDataAdapter.RecyclerViewHolder>{

    List<Pulsa> data = new ArrayList<Pulsa>();
    Context context;
    private View.OnClickListener mOnItemClickListener;

    public PaketDataAdapter(Context context, ArrayList<Pulsa> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        //View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.pulsa_denom_adapter, viewGroup, false);
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.paket_data_nominal_adapter, viewGroup, false);

        return new RecyclerViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        Pulsa pulsa = data.get(position);
        String prov=pulsa.getProvider();
        String desc=pulsa.getDesc();
        holder.tvProvider.setText(prov);
        holder.tvDesc.setText(desc.toUpperCase());
        Drawable img=context.getDrawable(R.drawable.ic_pulsa_24);
        String str=prov.toLowerCase();
        if(str.contains("telk")){
            img=context.getDrawable(R.drawable.telkomsel);
        }else if(str.contains("axis")){
            img=context.getDrawable(R.drawable.axis);
        }else if(str.contains("xl")){
            img=context.getDrawable(R.drawable.xl);
        }else if(str.contains("tri")){
            img=context.getDrawable(R.drawable.tri);
        }else if(str.contains("smart")){
            img=context.getDrawable(R.drawable.smartfren);
        }else if(str.contains("indo")){
            img=context.getDrawable(R.drawable.indosat);
        }
        holder.imgLogo.setImageDrawable(img);
        /*holder.cvDenom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });*/
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {

        TextView tvProvider;
        TextView tvDesc;
        ImageView imgLogo;
        //CardView cv;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvProvider = itemView.findViewById(R.id.tvProvider);
            imgLogo = itemView.findViewById(R.id.imgLogo);
            tvDesc = itemView.findViewById(R.id.tvDesc);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }
}
