package com.starpoin.pay.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.InternetTvCable;

import java.util.ArrayList;
import java.util.List;

public class InetTvCableAdapter extends RecyclerView.Adapter<InetTvCableAdapter.RecyclerViewHolder> {
    List<InternetTvCable> data = new ArrayList<InternetTvCable>();
    Context context;
    private View.OnClickListener mOnItemClickListener;

    public InetTvCableAdapter(Context context, ArrayList<InternetTvCable> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public InetTvCableAdapter.RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.pulsa_nominal_adapter, viewGroup, false);
        return new InetTvCableAdapter.RecyclerViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        InternetTvCable inetv = data.get(position);
        String code = inetv.getCode();
        String name = inetv.getName();
        holder.tvProvider.setText(code);
        holder.tvDesc.setText(name.toLowerCase());
        Drawable img = context.getDrawable(R.drawable.tv_cable);
        if (code.contains("telkom")) {
            img = context.getDrawable(R.drawable.indihome);
        } else if (code.contains("okevision")) {
            img = context.getDrawable(R.drawable.okevision);
        } else if (code.contains("toptv")) {
            img = context.getDrawable(R.drawable.toptv);
        } else if (code.contains("indovision")) {
            img = context.getDrawable(R.drawable.indovision);
        } else if (code.contains("firstmedia")) {
            img = context.getDrawable(R.drawable.firstmedia);
        }
        holder.imgLogo.setImageDrawable(img);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {

        TextView tvProvider;
        TextView tvDesc;
        ImageView imgLogo;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProvider = itemView.findViewById(R.id.tvProvider);
            imgLogo = itemView.findViewById(R.id.imgLogo);
            tvDesc = itemView.findViewById(R.id.tvDesc);
            tvProvider.setVisibility(View.GONE);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }
}