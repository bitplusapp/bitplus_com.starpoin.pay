package com.starpoin.pay.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.CustomRaceData;
import com.starpoin.pay.model.LapTransaksi;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class EventAdapterResult extends RecyclerView.Adapter<EventAdapterResult.RecyclerViewHolder> {

    List<CustomRaceData> data = new ArrayList<>();
    Context context;

    public EventAdapterResult(Context context, ArrayList<CustomRaceData> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public EventAdapterResult.RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_adapter_result, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventAdapterResult.RecyclerViewHolder holder, int position) {
        CustomRaceData model = data.get(position);
        int noUrut = position + 1; // Mengambil nomor urut dengan menambahkan 1 pada posisi item
        holder.tvNoRace.setText(String.valueOf(noUrut));
        holder.tvNamaRider.setText(model.getNama());
        holder.btnTime.setText(model.getFormattedTimeDifference());
        holder.tvTim.setText("NO : "+model.getNoRace()+" | " +model.getTim());

        switch (noUrut) {
            case 1:
                holder.leftLineView.setBackgroundColor(Color.parseColor("#00ED00"));
                holder.tvNoRace.setBackgroundColor(Color.parseColor("#00ED00"));
                break;
            case 2:
            case 3:
                holder.leftLineView.setBackgroundColor(Color.parseColor("#FE8A01"));
                holder.tvNoRace.setBackgroundColor(Color.parseColor("#FE8A01"));
                break;
            case 4:
            case 5:
                holder.leftLineView.setBackgroundColor(Color.RED);
                holder.tvNoRace.setBackgroundColor(Color.RED);
                break;
            default:
                holder.leftLineView.setBackgroundColor(Color.BLACK);
                holder.tvNoRace.setBackgroundColor(Color.BLACK);
                break;
        }

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {

        TextView tvNamaRider, tvTim, tvNoRace;
        Button btnTime;
        View leftLineView;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvNoRace = itemView.findViewById(R.id.tvNoRace);
            tvNamaRider= itemView.findViewById(R.id.tvNamaRider);
            btnTime = itemView.findViewById(R.id.btnTime);
            tvTim = itemView.findViewById(R.id.tvTim);
            leftLineView = itemView.findViewById(R.id.leftLineView);
        }
    }
}
