package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Topup;

import java.util.List;

public class ListTopupAdapter extends ArrayAdapter<Topup> {

    public ListTopupAdapter(Context context, List<Topup> items) {
        super(context, R.layout.products_item_list, items);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.products_item_list, parent, false);
        }

        TextView textView = convertView.findViewById(R.id.tvLabelProduk);
        ImageView imageView = convertView.findViewById(R.id.ivPdam);
        Topup item = getItem(position);
        textView.setText(item.getProvider().toUpperCase());
        imageView.setVisibility(View.VISIBLE);

        switch (item.getProvider()) {
            case "DANA":
                imageView.setImageResource(R.drawable.dana);
                break;
            case "LINKAJA":
                imageView.setImageResource(R.drawable.linkaja);
                break;
            case "NUJEK":
                imageView.setImageResource(R.drawable.nujek);
                break;
            case "OVO":
                imageView.setImageResource(R.drawable.ovo);
                break;
            case "SHOPEEPAY":
                imageView.setImageResource(R.drawable.shopeepay);
                break;
            default:
                imageView.setImageResource(R.drawable.gopay);
                break;
        }

        return convertView;
    }

}