package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Pdam;

import java.util.ArrayList;
import java.util.List;

public class ListPdamAdapter extends ArrayAdapter<Pdam> {

    private List<Pdam> originalItems;
    private List<Pdam> filteredItems;
    private Filter filter;

    public ListPdamAdapter(Context context, List<Pdam> items) {
        super(context, R.layout.products_item_list, items);
        this.originalItems = new ArrayList<>(items);
        this.filteredItems = new ArrayList<>(items);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.products_item_list, parent, false);
        }

        TextView textView = convertView.findViewById(R.id.tvLabelProduk);
        ImageView imageView = convertView.findViewById(R.id.ivPdam);
        Pdam item = getItem(position);
        textView.setText(item.getArea().toUpperCase());
        imageView.setVisibility(View.VISIBLE);

        return convertView;
    }

    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new PdamFilter();
        }
        return filter;
    }

    private class PdamFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            if (constraint == null || constraint.length() == 0) {
                // No filter applied, return the original list
                results.count = originalItems.size();
                results.values = originalItems;
            } else {
                List<Pdam> filteredList = new ArrayList<>();
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (Pdam item : originalItems) {
                    if (item.getArea().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
                results.count = filteredList.size();
                results.values = filteredList;
            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            filteredItems = (List<Pdam>) results.values;
            clear();
            addAll(filteredItems);
            notifyDataSetChanged();
        }
    }
}