package com.starpoin.pay.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Topup;

import java.util.ArrayList;
import java.util.List;

public class TopupProvider extends RecyclerView.Adapter<TopupProvider.RecyclerViewHolder>{

    List<Topup> data = new ArrayList<>();
    Context context;
    private View.OnClickListener mOnItemClickListener;

    public TopupProvider(Context context, ArrayList<Topup> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.topup_provider, viewGroup, false);

        return new RecyclerViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        Topup tprov = data.get(position);
        String prov=tprov.getProvider();
        Drawable img=context.getDrawable(R.drawable.ic_topup_24);
        if(prov.equalsIgnoreCase("OVO")){
            img=context.getDrawable(R.drawable.ovo);
        }else if(prov.equalsIgnoreCase("dana")){
            img=context.getDrawable(R.drawable.dana);
        }else if(prov.equalsIgnoreCase("linkaja")){
            img=context.getDrawable(R.drawable.linkaja);
        }else if(prov.equalsIgnoreCase("gopay")||prov.equalsIgnoreCase("gopay driver")){
            img=context.getDrawable(R.drawable.gopay);
        }else if(prov.equalsIgnoreCase("shopeepay")){
            img=context.getDrawable(R.drawable.shopeepay);
        }else if(prov.equalsIgnoreCase("nujek")){
            img=context.getDrawable(R.drawable.nujek);
        }
        holder.tvProvider.setText(prov);
        holder.imgProvider.setImageDrawable(img);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView tvProvider;
        ImageView imgProvider;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvProvider = itemView.findViewById(R.id.tvProvider);
            imgProvider = itemView.findViewById(R.id.imgProvider);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }
}
