package com.starpoin.pay.adapter;

public interface OnFinishLastPage {
    void onNext();
}
