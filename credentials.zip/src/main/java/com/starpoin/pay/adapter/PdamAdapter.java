package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Pdam;

import java.util.ArrayList;
import java.util.List;

public class PdamAdapter extends RecyclerView.Adapter<PdamAdapter.RecyclerViewHolder> {
    List<Pdam> data = new ArrayList<>();
    Context context;
    private View.OnClickListener mOnItemClickListener;


    public PdamAdapter(Context context, ArrayList<Pdam> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder  onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.prepaid_denom_adapter, viewGroup, false);

        return new RecyclerViewHolder (view);
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder  holder, int position) {
        Pdam pdam = data.get(position);
        String area=pdam.getArea();
        String str=area.toUpperCase().replaceAll("PDAM","").trim();
        //holder.tvDenom.setText(area);
        holder.tvDenom.setText(str);

    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView tvDenom;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvDenom = itemView.findViewById(R.id.tvDesc);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }

}
