package com.starpoin.pay.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.NewResultItem;

import java.util.ArrayList;
import java.util.List;

public class NewResultAdapter extends RecyclerView.Adapter<NewResultAdapter.RecyclerViewHolder>{

    List<NewResultItem> data = new ArrayList<NewResultItem>();
    Context context;

    public NewResultAdapter(Context context,List<NewResultItem> data){
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.result_adapter, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewResultAdapter.RecyclerViewHolder holder, int position) {
        NewResultItem item=data.get(position);

        if(item.getTitle().contains("-")){
            //separator (-)
            holder.tvTitle.setText(item.getSparator());
            holder.tvTitle.setTypeface(null, Typeface.BOLD);
            holder.separator.setText("");
            holder.tvValue.setText("");
        }else{
            holder.tvTitle.setText(item.getTitle());
            holder.separator.setText(item.getSparator());
            holder.tvValue.setText(item.getValue());
            holder.tvValue.setTypeface(null, Typeface.BOLD);
        }

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView tvTitle;
        TextView separator;
        TextView tvValue;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvDesc);
            separator = itemView.findViewById(R.id.separator);
            tvValue = itemView.findViewById(R.id.tvValue);
        }
    }
}