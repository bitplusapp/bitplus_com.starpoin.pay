package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.ResultItem;

import java.util.ArrayList;
import java.util.List;

public class ResultAdapter extends RecyclerView.Adapter<ResultAdapter.RecyclerViewHolder>{

    List<ResultItem> data = new ArrayList<ResultItem>();
    Context context;

    public ResultAdapter(Context context,List<ResultItem> data){
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.result_adapter, parent, false);

        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ResultAdapter.RecyclerViewHolder holder, int position) {
        ResultItem item=data.get(position);
        holder.tvTitle.setText(item.getTitle());
        holder.tvValue.setText(item.getValue());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView tvTitle;
        TextView tvValue;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvDesc);
            tvValue = itemView.findViewById(R.id.tvValue);
        }
    }
}
