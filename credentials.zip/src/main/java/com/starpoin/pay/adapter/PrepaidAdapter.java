package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Prepaid;

import java.util.ArrayList;
import java.util.List;

public class PrepaidAdapter extends RecyclerView.Adapter<PrepaidAdapter.RecyclerViewHolder> {
    List<Prepaid> data = new ArrayList<Prepaid>();
    Context context;
    private View.OnClickListener mOnItemClickListener;


    public PrepaidAdapter(Context context, ArrayList<Prepaid> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder  onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.prepaid_denom_adapter, viewGroup, false);

        return new RecyclerViewHolder (view);
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder  holder, int position) {
        Prepaid prepaidDenom = data.get(position);
        String title=prepaidDenom.getTitle();
        holder.tvDenom.setText(title);

    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView tvDenom;
        CardView cvDenom;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvDenom = itemView.findViewById(R.id.tvDesc);
            cvDenom = itemView.findViewById(R.id.cvDenom);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }

}
