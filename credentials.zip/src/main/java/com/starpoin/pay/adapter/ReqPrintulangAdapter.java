package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.ReqPrintItems;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReqPrintulangAdapter extends RecyclerView.Adapter<ReqPrintulangAdapter.RecyclerViewHolder> {
    List<ReqPrintItems> data = new ArrayList<>();
    Context context;
    private View.OnClickListener mOnItemClickListener;


    public ReqPrintulangAdapter(Context context, ArrayList<ReqPrintItems> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder  onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.req_printulang_new_layout, viewGroup, false);

        return new RecyclerViewHolder (view);
    }

    private String timestampFormattedWIB(String timestamp) {
        String input = timestamp;
        SimpleDateFormat inputFormatter = new SimpleDateFormat("yyyy-MM-dd");

        try {
            Date date = inputFormatter.parse(input);
            SimpleDateFormat outputFormatter = new SimpleDateFormat("d MMM yyyy");
            String output = outputFormatter.format(date);
            return output.toUpperCase();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return input;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder  holder, int position) {
        ReqPrintItems item = data.get(position);

        holder.reqprint_noidlabel.setText(item.getLabelid());
        holder.reqprint_noid.setText(item.getNoid());
        holder.reqprint_nama.setText(item.getNama());

        if(item.getPan().contains("postpaid")) {
            holder.lap_valtransType.setText("PLN POSTPAID");
            holder.ivProduct.setImageResource(R.drawable.postpaid);
        }else if(item.getPan().contains("prepaid")) {
            holder.lap_valtransType.setText("PLN TOKEN");
            holder.ivProduct.setImageResource(R.drawable.prepaid);
        }else if(item.getPan().contains("nontaglis")) {
            holder.lap_valtransType.setText("PLN NONTAGLIS");
            holder.ivProduct.setImageResource(R.drawable.nontaglis);
        }else if(item.getPan().contains("inetv")) {
            holder.lap_valtransType.setText("INTERNET & TV CABLE");
            holder.ivProduct.setImageResource(R.drawable.tv_cable);
        }else if(item.getPan().contains("pbb")) {
            holder.lap_valtransType.setText("PAJAK PBB");
            holder.ivProduct.setImageResource(R.drawable.pbb);
        }else if(item.getPan().contains("kesehatan")) {
            holder.lap_valtransType.setText("BPJS KESEHATAN");
            holder.ivProduct.setImageResource(R.drawable.bpjs);
        }else if(item.getPan().contains("voucher")) {
            holder.lap_valtransType.setText("VOUCHER");
            holder.ivProduct.setImageResource(R.drawable.voucher);
        }else if(item.getPan().contains("telkom")) {
            holder.lap_valtransType.setText("TELKOM INDIHOME");
            holder.ivProduct.setImageResource(R.drawable.telkom);
        }else if(item.getPan().contains("telco")) {
            holder.lap_valtransType.setText("PASKA BAYAR");
            holder.ivProduct.setImageResource(R.drawable.paska_bayar);
        }else{
            holder.lap_valtransType.setText("AIR PDAM");
            holder.ivProduct.setImageResource(R.drawable.pdam);
        }

        holder.reqprint_tanggal.setText(timestampFormattedWIB(item.getTanggal()));

    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView reqprint_noidlabel;
        TextView reqprint_noid;
        TextView reqprint_nama;
        TextView reqprint_tanggal;
        TextView lap_valtransType;
        ImageView ivProduct;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            reqprint_noidlabel = itemView.findViewById(R.id.reqprint_noidlabel);
            reqprint_noid = itemView.findViewById(R.id.reqprint_noid);
            reqprint_nama = itemView.findViewById(R.id.reqprint_nama);
            reqprint_tanggal = itemView.findViewById(R.id.reqprint_tanggal);

            ivProduct = itemView.findViewById(R.id.ivProduct);
            ivProduct = itemView.findViewById(R.id.ivProduct);
            lap_valtransType=itemView.findViewById(R.id.lap_valtransType);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }

}
