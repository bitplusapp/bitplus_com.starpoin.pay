package com.starpoin.pay.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.LapTrans;
import com.starpoin.pay.util.Produk;

import java.util.List;

public class GridMenuAdapter extends RecyclerView.Adapter<GridMenuAdapter.ProductViewHolder> {

    private List<LapTrans> productList;
    private OnItemClickListener onItemClickListener;

    public GridMenuAdapter(List<LapTrans> productList) {
        this.productList = productList;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener {
        void onItemClick(LapTrans product);
    }


    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        LapTrans product = productList.get(position);
        holder.bind(product);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener  {

        private ImageView imageView;
        private TextView nameTextView;
        private LapTrans product;
        private TextView newProdukTextView;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.product_image);
            nameTextView = itemView.findViewById(R.id.product_name);
            newProdukTextView=itemView.findViewById(R.id.new_text);
            itemView.setOnClickListener(this);
        }

        public void bind(LapTrans product) {
            this.product = product;
            imageView.setImageResource(product.getImageResource());
            nameTextView.setText(product.getLabel());

            switch (product.getId()) {
                case Produk.PBB:
                case Produk.TVCABLE:
                case Produk.SEMUA:
                    newProdukTextView.setVisibility(View.VISIBLE);
                    break;
                default:
                    newProdukTextView.setVisibility(View.GONE);
                    break;
            }
        }

        @Override
        public void onClick(View v) {
            // Call the onItemClick method of the OnItemClickListener interface
            if (onItemClickListener != null && product != null) {
                onItemClickListener.onItemClick(product);
            }
        }
    }
}
