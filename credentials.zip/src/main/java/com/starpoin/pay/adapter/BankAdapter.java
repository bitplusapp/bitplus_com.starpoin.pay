package com.starpoin.pay.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Bank;

import java.util.ArrayList;
import java.util.List;

public class BankAdapter extends RecyclerView.Adapter<BankAdapter.RecyclerViewHolder> {
    List<Bank> data = new ArrayList<>();
    Context context;
    private int selectedRow=0;
    private View.OnClickListener mOnItemClickListener;


    public BankAdapter(Context context, ArrayList<Bank> data,int selectedRow) {
        this.context = context;
        this.data = data;
        this.selectedRow=selectedRow;
    }

    @NonNull
    @Override
    public RecyclerViewHolder  onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.topup_provider, viewGroup, false);

        return new RecyclerViewHolder (view);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(RecyclerViewHolder  holder, @SuppressLint("RecyclerView") int position) {
        Bank bank = data.get(position);
        String kode=bank.getBankCode();
        String nama=bank.getBankName();
        Drawable img=null;
        switch (kode){
            case "002":
                img=context.getDrawable(R.drawable.ic_bri);
                break;
            case "008":
                img=context.getDrawable(R.drawable.ic_mandiri);
                break;
            case "009":
                img=context.getDrawable(R.drawable.ic_bni);
                break;
            case "014":
                img=context.getDrawable(R.drawable.ic_bca);
                break;
        }

        holder.tvProvider.setText(nama);
        holder.imgProvider.setImageDrawable(img);
        Log.i("row_index_x",String.valueOf(selectedRow));
        if(selectedRow==position){
            holder.cvDenom.setBackgroundColor(Color.parseColor("#E2F3FD"));
        }else{
            holder.cvDenom.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
        }
    }





    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        CardView cvDenom;
        TextView tvProvider;
        ImageView imgProvider;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            cvDenom=itemView.findViewById(R.id.cvDenom);
            tvProvider = itemView.findViewById(R.id.tvProvider);
            imgProvider = itemView.findViewById(R.id.imgProvider);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }


}
