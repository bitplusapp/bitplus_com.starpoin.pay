package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.ResultItem;

import java.util.ArrayList;
import java.util.List;

public class CekVoucherAdapter extends RecyclerView.Adapter<CekVoucherAdapter.RecyclerViewHolder> {
    List<ResultItem> data = new ArrayList<>();
    Context context;


    public CekVoucherAdapter(Context context, ArrayList<ResultItem> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder  onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.single_item, viewGroup, false);

        return new RecyclerViewHolder (view);
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder  holder, int position) {
        ResultItem model = data.get(position);
        holder.label.setText(model.getTitle());
        holder.value.setText(model.getValue());


    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView label;
        TextView value;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            //tvDenom = itemView.findViewById(R.id.tvDesc);
            label = itemView.findViewById(R.id.captionLabel);
            value = itemView.findViewById(R.id.valueLabel);
        }
    }



}
