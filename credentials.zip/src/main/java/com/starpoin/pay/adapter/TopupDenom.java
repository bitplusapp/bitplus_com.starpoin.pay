package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Topup;

import java.util.ArrayList;
import java.util.List;

public class TopupDenom extends RecyclerView.Adapter<TopupDenom.RecyclerViewHolder>{

    List<Topup> data = new ArrayList<>();
    Context context;
    private View.OnClickListener mOnItemClickListener;

    public TopupDenom(Context context, ArrayList<Topup> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.pulsa_denom_adapter, viewGroup, false);

        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        Topup tprov = data.get(position);
        String prov=tprov.getProvider();
        String desc=tprov.getDesc();
        holder.tvProvider.setText(prov);
        holder.tvDesc.setText(desc);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView tvProvider;
        TextView tvDesc;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvProvider = itemView.findViewById(R.id.tvProvider);
            tvDesc = itemView.findViewById(R.id.tvDesc);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }
}
