package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.helper.Notifikasi;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private Context context;
    private List<Notifikasi> notificationList;
    private OnItemClickListener onItemClickListener;

    public NotificationAdapter(Context context, List<Notifikasi> notificationList) {
        this.context = context;
        this.notificationList = notificationList;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener {
        void onItemClick(Notifikasi notif);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_notification, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationAdapter.ViewHolder holder, int position) {
        Notifikasi notification = notificationList.get(position);
        holder.bind(notification);
    }

    @Override
    public int getItemCount() {
        return notificationList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener  {

        private ImageView icon;
        private TextView title;
        private TextView message;
        private Notifikasi notifikasi;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.notification_icon);
            title = itemView.findViewById(R.id.notification_title);
            message = itemView.findViewById(R.id.notification_message);
            itemView.setOnClickListener(this);
        }

        public void bind(Notifikasi notifikasi) {
            this.notifikasi = notifikasi;
            this.title.setText(notifikasi.getTitle());
            String body = notifikasi.getMessage();

            if(body.length() > 50) {
                body=body.substring(0,49)+"...";
            }

            this.message.setText(body);

            switch (notifikasi.getStatus()) {
                case 0:
                    icon.setImageResource(R.drawable.unread);
                    break;
                case 1:
                    icon.setImageResource(R.drawable.ic_check_24);
                    break;
            }
        }

        @Override
        public void onClick(View v) {
            // Call the onItemClick method of the OnItemClickListener interface
            if (onItemClickListener != null && notifikasi != null) {
                onItemClickListener.onItemClick(notifikasi);
            }
        }
    }
}