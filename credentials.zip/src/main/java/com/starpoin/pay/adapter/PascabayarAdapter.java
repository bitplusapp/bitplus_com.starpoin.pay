package com.starpoin.pay.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.PascaBayar;

import java.util.ArrayList;
import java.util.List;

public class PascabayarAdapter extends RecyclerView.Adapter<PascabayarAdapter.RecyclerViewHolder>{

    List<PascaBayar> data = new ArrayList<>();
    Context context;
    private View.OnClickListener mOnItemClickListener;

    public PascabayarAdapter(Context context, ArrayList<PascaBayar> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        //View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.prepaid_denom_adapter, viewGroup, false);
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.topup_provider, viewGroup, false);

        return new RecyclerViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        PascaBayar pascaBayar = data.get(position);
        String kode=pascaBayar.getKode();
        String prov=pascaBayar.getProvider();
        //holder.tvProvider.setText(prov);
        Drawable img=context.getDrawable(R.drawable.paskabayar32);
        if(kode.equalsIgnoreCase("halo")){
            img=context.getDrawable(R.drawable.kartu_halo);
        }else if(kode.equalsIgnoreCase("xplore")){
            img=context.getDrawable(R.drawable.xl_prioritas);
        }else if(kode.equalsIgnoreCase("matrix")){
            img=context.getDrawable(R.drawable.matrix);
        }
        holder.tvProvider.setText(prov);
        holder.imgProvider.setImageDrawable(img);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        TextView tvProvider;
        ImageView imgProvider;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            tvProvider = itemView.findViewById(R.id.tvProvider);
            imgProvider = itemView.findViewById(R.id.imgProvider);

            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
    }
}
