package com.starpoin.pay.adapter;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.Tiket;

import java.util.ArrayList;
import java.util.List;

public class TiketAdapter extends RecyclerView.Adapter<TiketAdapter.RecyclerViewHolder> {
    List<Tiket> data = new ArrayList<>();
    Context context;
    private ClipboardManager clipboardManager;
    private ClipData myClip;
    public ImageButton actionCopy;

    public TiketAdapter(Context context, ArrayList<Tiket> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public RecyclerViewHolder  onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.tiket_adapter, viewGroup, false);
        actionCopy = (ImageButton) view.findViewById(R.id.btnCopy);
        return new RecyclerViewHolder (view);
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder  holder, int position) {
        Tiket tiket = data.get(position);
        holder.tvBankName.setText(tiket.getBankName());
        holder.tvNoAcc.setText(tiket.getAccNumber());
        holder.tvNamaAcc.setText(tiket.getAccName());
        holder.btnCopy.setOnClickListener((new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                clipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                myClip = ClipData.newPlainText("text", tiket.getAccNumber());
                clipboardManager.setPrimaryClip(myClip);
                Toast.makeText(context, "Nomor rekening berhasil disalin", Toast.LENGTH_SHORT).show();
            }
        }));
    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    public ImageButton getActionCopy() {
        return actionCopy;
    }

    public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
        //TextView tvTiket;
        TextView tvBankName;
        TextView tvNoAcc;
        TextView tvNamaAcc;
        ImageButton btnCopy;

        public RecyclerViewHolder (@NonNull View itemView) {
            super(itemView);
            //tvTiket = itemView.findViewById(R.id.tvTiket);
            tvBankName = itemView.findViewById(R.id.tvBankName);
            tvNoAcc = itemView.findViewById(R.id.tvNoAcc);
            tvNamaAcc = itemView.findViewById(R.id.tvNamaAcc);
            btnCopy = itemView.findViewById(R.id.btnCopy);
        }
    }

}
