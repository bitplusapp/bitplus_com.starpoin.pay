package com.starpoin.pay.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.starpoin.pay.R;
import com.starpoin.pay.model.ListViewModel;

import java.util.List;

public class ListViewAdapter extends ArrayAdapter<ListViewModel> {

    public ListViewAdapter(Context context, List<ListViewModel> items) {
        super(context, R.layout.list_view_global_only_text, items);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_view_global_only_text, parent, false);
        }

        ListViewModel item = getItem(position);
        TextView textView = convertView.findViewById(R.id.tvValue);
        textView.setText(item.getValue());

        return  convertView;
    }

}
