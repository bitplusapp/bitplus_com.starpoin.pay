package com.starpoin.pay;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.starpoin.pay.model.Response;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.RegistrationTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Valid;
import com.starpoin.pay.util.Wong;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegistrasiActivity extends AbaseActivity implements View.OnClickListener {

    private RelativeLayout rootLayout;

    private EditText reg_ca, reg_email, reg_pass1, reg_pass2, reg_hp,etNamaMerchant,etAlamat;
    private Button reg_btnreg;
    private RadioGroup radio_group;
    private String typeVer="WhatsApp";
    private ImageView pass1, pass2;
    private ImageButton btn_back;

    private final Response response=new Response();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_registrasi);

        if(getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        rootLayout=(RelativeLayout) findViewById(R.id.rootLayout);

        reg_ca = (EditText) findViewById(R.id.reg_ca);

        pass1 = (ImageView) findViewById(R.id.btnShowHidePass1);
        pass1.setOnClickListener(this);
        pass2 = (ImageView) findViewById(R.id.btnShowHidePass2);
        pass2.setOnClickListener(this);

        btn_back = (ImageButton) findViewById(R.id.btnBack);
        btn_back.setOnClickListener(this);

        reg_email = (EditText) findViewById(R.id.reg_email);
        reg_pass1 = (EditText) findViewById(R.id.reg_pass1);
        reg_pass2 = (EditText) findViewById(R.id.reg_pass2);
        reg_hp = (EditText) findViewById(R.id.reg_hp);
        etNamaMerchant = (EditText) findViewById(R.id.etNamaMerchant);
        etAlamat = (EditText) findViewById(R.id.etAlamat);

        Intent intent = getIntent();
        if(intent.hasExtra( "email") && intent.hasExtra("name_merchant")) {
            reg_email.setText(response.getExtraString(this, "email"));
            reg_email.setEnabled(false);
            etNamaMerchant.setText(response.getExtraString(this,"name_merchant"));
        }

        reg_btnreg = (Button) findViewById(R.id.reg_btnreg);
        reg_btnreg.setOnClickListener(this);

        radio_group=(RadioGroup) findViewById(R.id.radio_group);
        radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) group.findViewById(checkedId);
                if (null != rb && checkedId > -1) {

                    typeVer=rb.getText().toString();
                    //Toast.makeText(RegistrasiActivity.this, typeVer, Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.reg_btnreg:

                cekData();
                //Intent i = new Intent(RegistrasiActivity.this, VerifikasiRegActivity.class);
                //startActivity(i);
                break;
            case R.id.btnShowHidePass1:
                if(reg_pass1.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    (pass1).setImageResource(R.drawable.hide_pass_icon);

                    //Show Password
                    reg_pass1.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    reg_pass1.setSelection(reg_pass1.getText().length());
                }
                else{
                    (pass1).setImageResource(R.drawable.show_pass_icon);

                    //Hide Password
                    reg_pass1.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    reg_pass1.setSelection(reg_pass1.getText().length());
                }
                break;
            case R.id.btnShowHidePass2:
                if(reg_pass2.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    (pass1).setImageResource(R.drawable.hide_pass_icon);

                    //Show Password
                    reg_pass2.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    reg_pass2.setSelection(reg_pass2.getText().length());
                }
                else{
                    (pass2).setImageResource(R.drawable.show_pass_icon);

                    //Hide Password
                    reg_pass2.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    reg_pass2.setSelection(reg_pass2.getText().length());
                }
                break;
            case R.id.btnBack:
                this.finish();
                break;
        }
    }



    private void cekData(){
        //String ca = reg_ca.getText().toString();
        String email = reg_email.getText().toString().trim();
        String pass1 = reg_pass1.getText().toString();
        String pass2 = reg_pass2.getText().toString();
        String nama_merchant = etNamaMerchant.getText().toString().trim();
        String alamat = etAlamat.getText().toString().trim();

        String hp = reg_hp.getText().toString().trim();
        int pass1size = pass1.length();
        int hpsize = hp.length();
        int namasize = nama_merchant.length();
        int alamatsize = alamat.length();

        boolean emailValid = new Valid().isValidEmail(email);
        if(email.equals("")){
            showDialog("Email harus diisi");
        }else if (emailValid == false) {
            showDialog("Format email salah");
        } else if (pass1size < 4) {
            showDialog("Password minimal 4 huruf/angka");
        } else if (!pass2.equals(pass1)) {
            showDialog("Password tidak sesuai");
        } else if (hpsize < 10) {
            showDialog("Nomor HP minimal 10 nomor");
        }else if(typeVer.equals("")){
            showDialog("Pilih Jalur Verifikasi");
        }else if(namasize<4){
            showDialog("Nama Toko/Merchant belum diisi");
        }else if(alamatsize<6){
            showDialog("Alamat Toko/Merchant belum diisi");
        }
        else {
            submitData();
        }

    }

    private void submitData() {
        String ca = reg_ca.getText().toString().trim().toUpperCase();
        String email = reg_email.getText().toString().trim();
        String pass1 = reg_pass1.getText().toString();
        //String device= Wong.getDevice();

        String hp=reg_hp.getText().toString().trim();
        String nama_merchant = etNamaMerchant.getText().toString().trim();
        String alamat = etAlamat.getText().toString().trim();

        Wong.setEmail(email);
        Wong.setHp(hp);
        Wong.setMerchant(nama_merchant);//untuk update biodata
        Wong.setAlamat(alamat);//untuk update biodata

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("referal",ca);
        map.put("email",email);
        map.put("password",pass1);
        map.put("phoneNumber",hp);
        map.put("group","ams");
        map.put("otpVia",typeVer);
        String params= new JSONObject(map).toString();
        RegistrationTask task = new RegistrationTask(RegistrasiActivity.this,RegistrasiActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")) {
                    Wong.setOtp_via(typeVer);
                    Wong.setPassword(pass1);
                    Intent i = new Intent(RegistrasiActivity.this, VerifikasiRegActivity.class);
                    startActivity(i);
                    finish();
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute("registration/user",params);
    }

    private void showDialog(String pesan){
        Toast toast = Toast.makeText(RegistrasiActivity.this,pesan, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP, 25, 400);
        toast.show();
    }

    private String getEmailID() {
        AccountManager accountManager = AccountManager.get(RegistrasiActivity.this);
        Account account = getAccount(accountManager);
        if (account == null) {
            return null;
        } else {
            return account.name;
        }
    }

    private Account getAccount(AccountManager accountManager) {
        Account[] accounts = accountManager.getAccountsByType("com.google");
        Account account;
        if (accounts.length > 0) {
            account = accounts[0];
        } else {
            account = null;
        }
        return account;
    }
}