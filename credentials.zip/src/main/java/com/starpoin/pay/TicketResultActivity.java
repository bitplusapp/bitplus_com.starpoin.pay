package com.starpoin.pay;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.TiketAdapter;
import com.starpoin.pay.model.Response;
import com.starpoin.pay.model.Tiket;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class TicketResultActivity extends AppCompatActivity implements View.OnClickListener {

    public LinearLayout rootLayout, actionLayout;

    Context context;

    private String time;
    private String id_merchant;
    private String amount;
    private String result;

    private TextView tvAmount, tvTime, tvIdmerchant;
    private ImageButton btnBack;
    private Button btnSimpan;
    private TiketAdapter adapter;
    private ScrollView scrollbar;
    JSONObject data = null;
    private ClipboardManager clipboardManager;
    private ClipData myClip;
    public ImageButton actionCopy;

    private final Response response=new Response();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_tiket_invoice);

        this.setTitle("");

        context = this;
        try {
            rootLayout = findViewById(R.id.rootLayout);

            data = new JSONObject(response.getExtraString(this, "result"));

            actionLayout = (LinearLayout) findViewById(R.id.LayoutAction);
            scrollbar = (ScrollView) findViewById(R.id.scrollbar);

            result = response.getExtraString(this, "result");
            time = response.getExtraString(this, "time");
            id_merchant = response.getExtraString(this, "id_merchant");
            amount = response.getExtraString(this, "amount");

            tvTime = (TextView) findViewById(R.id.tvTime);
            tvTime.setText(timestampFormattedWIB(time));

            tvIdmerchant = (TextView) findViewById(R.id.tvIdmerchant);
            tvIdmerchant.setText(id_merchant);

            tvAmount = (TextView) findViewById(R.id.tvAmount);
            tvAmount.setText("Rp "+new DecimalFormat("#,##0").format(Double.parseDouble(amount)));

            btnBack = (ImageButton) findViewById(R.id.btnBack);
            btnBack.setOnClickListener(this);

            btnSimpan = (Button) findViewById(R.id.btnSimpan);
            btnSimpan.setOnClickListener(this);

            actionCopy = findViewById(R.id.btnCopy);
            actionCopy.setOnClickListener((new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View v) {
                    clipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                    myClip = ClipData.newPlainText("text", amount);
                    clipboardManager.setPrimaryClip(myClip);
                    Toast.makeText(context, "Nominal transfer berhasil disalin", Toast.LENGTH_SHORT).show();
                }
            }));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        switcView();

    }

    private void screenShotTiket() {
        actionLayout.setVisibility(View.GONE);
        btnBack.setVisibility(View.GONE);
        adapter.actionCopy.setVisibility(View.GONE);
        actionCopy.setVisibility(View.GONE);
        Bitmap bitmap = Bitmap.createBitmap(scrollbar.getWidth(), scrollbar.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable bgDrawable = scrollbar.getBackground();
        if (bgDrawable != null)
            bgDrawable.draw(canvas);
        else
            canvas.drawColor(Color.parseColor("#DFE7EE"));
        scrollbar.draw(canvas);
        MediaStore.Images.Media.insertImage(context.getContentResolver(),
                bitmap,"IMG_" + Calendar.getInstance().getTime(), null);
        actionLayout.setVisibility(View.VISIBLE);
        actionCopy.setVisibility(View.VISIBLE);

        btnBack.setVisibility(View.VISIBLE);
        adapter.actionCopy.setVisibility(View.VISIBLE);
        Toast.makeText(context, "Tiket berhasil disimpan digaleri", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnBack:
                onBackPressed();
                break;
            case R.id.btnSimpan:
                screenShotTiket();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy | HH:mm:ss").format(date) + " WIB";
        return formattedDate;
    }

    private void switcView() {
        ArrayList<Tiket> listTiket=new Tiket().listTiket(result);
        adapter=new TiketAdapter(this,listTiket);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);

        RecyclerView recycleView = findViewById(R.id.recycleView);
        recycleView.setLayoutManager(layoutManager);
        recycleView.setAdapter(adapter);
    }
}