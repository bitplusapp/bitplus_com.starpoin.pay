package com.starpoin.pay;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.topi.Produk;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class TopiViewProdukActivity extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;
    private EditText etKodeProduk,etNamaProduk,etSatuan,etHargaBeli,etHargaJual,etStok;
    private String kode_produk;
    private Button btnUpdate,btnHapus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topi_view_produk);

        setTitle("Produk");

        rootLayout=findViewById(R.id.rootLayout);

        kode_produk= getIntent().getStringExtra("kode_produk");
        String nama_produk= getIntent().getStringExtra("nama_produk");
        String satuan= getIntent().getStringExtra("satuan");
        String harga_beli= getIntent().getStringExtra("harga_beli");
        String harga_jual= getIntent().getStringExtra("harga_jual");

        String stok= getIntent().getStringExtra("stok");

        etNamaProduk=(EditText) findViewById(R.id.etNamaProduk);
        etNamaProduk.setText(nama_produk);
        etSatuan=(EditText) findViewById(R.id.etSatuan);
        etSatuan.setText(satuan);
        etHargaBeli=(EditText) findViewById(R.id.etHargaBeli);
        etHargaBeli.setText(harga_beli);
        etHargaJual=(EditText) findViewById(R.id.etHargaJual);
        etHargaJual.setText(harga_jual);

        etStok=(EditText) findViewById(R.id.etStok);
        etStok.setText(stok);

        btnUpdate=findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(this);

        btnHapus=findViewById(R.id.btnHapus);
        btnHapus.setOnClickListener(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnUpdate:
                confirmUpdate();
                break;
            case R.id.btnHapus:
                confirmasiHapus();
                break;
        }
    }

    private void confirmUpdate(){
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        dialog.dismiss();
                        updateProduk();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        //No button clicked
                        dialog.dismiss();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Update Data Produk?").setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    private void updateProduk(){
        String namaProduk=etNamaProduk.getText().toString().trim().replaceAll("'","`");
        String satuan=etSatuan.getText().toString().trim();
        String hargaBeli=etHargaBeli.getText().toString().trim();
        String hargaJual=etHargaJual.getText().toString().trim();
        String stok=etStok.getText().toString().trim();

        Map<String,Object> mapJson=new HashMap<>();
        mapJson.put("kode_produk",kode_produk);
        mapJson.put("nama_produk",namaProduk);
        mapJson.put("satuan",satuan);
        mapJson.put("harga_beli",hargaBeli);
        mapJson.put("harga_jual",hargaJual);
        mapJson.put("stok",stok);
        JSONObject job=new JSONObject(mapJson);

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","update_produk");
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("json",job.toString());
        String params="Topi"+new Params().buildParams(map);
        TransTask task = new TransTask(TopiViewProdukActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                malik.org.json.JSONObject job=new malik.org.json.JSONObject(content);

                String rc=job.getString("rc");
                if(rc.equals("0000")){
                    Produk prod=new Produk();
                    prod.setKode_produk(kode_produk);
                    prod.setNama_produk(namaProduk);
                    prod.setSatuan(satuan);
                    prod.setHarga_beli(hargaBeli);
                    prod.setHarga_jual(hargaJual);
                    prod.setStok(stok);
                    new Produk().updateProduk(TopiViewProdukActivity.this,prod);
                    showMsg("Berhasil update produk");
                }else{
                    String desc=job.getString("desc");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void confirmasiHapus(){
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        dialog.dismiss();
                        hapusProduk();

                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        //No button clicked
                        dialog.dismiss();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Yakin Ingin Dihapus?").setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    private void hapusProduk(){
        try {
            JSONObject job=new JSONObject();
            job.put("kode_produk",kode_produk);

            Map<String,Object> map=new HashMap<String, Object>();
            map.put("q","del_produk");
            map.put("idmerc", Wong.getIdmerch());
            map.put("iduser", Wong.getEmail());
            map.put("json",job.toString());
            String params="Topi"+new Params().buildParams(map);
            TransTask task = new TransTask(TopiViewProdukActivity.this,this, new OnEventListener<String>() {
                @Override
                public void onSuccess(String content) {
                    malik.org.json.JSONObject job=new malik.org.json.JSONObject(content);

                    String rc=job.getString("rc");
                    if(rc.equals("0000")){
                        new Produk().hapusProduk(TopiViewProdukActivity.this,kode_produk);
                        showMsg("Produk dihapus");
                    }else{
                        String desc=job.getString("desc");
                        showMsg(desc);
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    showMsg(e.getMessage());
                }

            });
            task.execute(params);
        }catch (Exception ex){

        }

    }

}