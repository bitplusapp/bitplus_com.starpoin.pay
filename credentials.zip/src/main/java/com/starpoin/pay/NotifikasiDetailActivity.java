package com.starpoin.pay;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.Notifikasi;
import com.starpoin.pay.model.Response;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NotifikasiDetailActivity extends AbaseActivity {

    private TextView tvTitle, tvTime, tvBody;
    private final Response response=new Response();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifikasi_detail);

        tvTitle = findViewById(R.id.tvTitle);
        tvTime = findViewById(R.id.tvTime);
        tvBody = findViewById(R.id.tvBody);

        tvTitle.setText(response.getExtraString(this, "title"));
        tvTime.setText(timestampFormattedWIB(response.getExtraString(this, "time")));
        tvBody.setText(response.getExtraString(this, "body"));

        setBarTitle((String) tvTitle.getText());

        //set ke read
        DatabaseHelper dbHelper=new DatabaseHelper(NotifikasiDetailActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        new Notifikasi().updateStatusUnreadToRead(db, response.getExtraString(this, "title"));
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy | HH:mm:ss").format(date) + " WIB";
        return formattedDate;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


}