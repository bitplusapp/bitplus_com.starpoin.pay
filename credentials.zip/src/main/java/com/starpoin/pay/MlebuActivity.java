package com.starpoin.pay;


import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.tasks.Task;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.Profil;
import com.starpoin.pay.model.LoginMethod;
import com.starpoin.pay.task.LoginTask;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.PBarLinear;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Wong;

import java.util.concurrent.Executor;

public class MlebuActivity extends AbaseActivity implements View.OnClickListener{

    private RelativeLayout rootLayout;
    private TextView linkBitplus, lupaPasswd, Registrasi;
    private ImageView iconPasswordToggle;
    private EditText etUser,etPassword;
    private Button btnLogin,btnLupa,btnBantuan,btnFaq;
    private ImageButton btnBack, btnBiometric;
    private String userdb;
    private String app_version;
    private GoogleSignInClient mGoogleSignInClient;

    private Executor executor;
    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo promptInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);


        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        updateUI(account);

        setContentView(R.layout.activity_asup);

        getSupportActionBar().hide();

        if (getIntent().getBooleanExtra("EXIT", false)) {
            finish();
        }

        rootLayout=(RelativeLayout) findViewById(R.id.rootLayout);

        etUser=(EditText) findViewById(R.id.etUser);
        etPassword=(EditText) findViewById(R.id.etPassword);

        iconPasswordToggle = (ImageView) findViewById(R.id.btnShowHidePass);
        iconPasswordToggle.setOnClickListener(this);

        userdb=userDB();
        etUser.setText(userdb);

        btnLogin=(Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        lupaPasswd=(TextView) findViewById(R.id.btnLupa);
        lupaPasswd.setOnClickListener(this);

        Registrasi=(TextView) findViewById(R.id.Registrasi);
        Registrasi.setOnClickListener(this);

        btnBack=(ImageButton) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);

        btnBiometric=findViewById(R.id.btnBiometric);

        executor = ContextCompat.getMainExecutor(this);
        //setup title,description on auth dialog

        btnBiometric.setOnClickListener(View -> {
            if(isSupportBiometricPrompt()) {
                showDialogBiometric(LoginMethod.BIOMETRIC, null);
            }else{
                showMessage("Device anda tidak support biometrik (Fingerprint)");
            }
        });

        SignInButton signInButton = findViewById(R.id.sign_in_button);
        signInButton.setStyle(SignInButton.SIZE_WIDE, SignInButton.COLOR_LIGHT);
        signInButton.setOnClickListener(this);

        try {
            PackageInfo pInfo = MlebuActivity.this.getPackageManager().getPackageInfo(getPackageName(), 0);
            app_version = pInfo.versionName;
            Wong.setAppVersion(app_version);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()){
            case R.id.btnLogin:
                btnLogin.setEnabled(false);
                login(etUser.getText().toString(), etPassword.getText().toString());
                break;
            case R.id.btnLupa:
                intent=new Intent(MlebuActivity.this,ReqPassActivity.class);
                startActivity(intent);
                break;
            case R.id.btnBack:
                finish();
                break;
            case R.id.Registrasi:
                intent=new Intent(MlebuActivity.this,RegistrasiActivity.class);
                startActivity(intent);
                break;
            case R.id.btnShowHidePass:
                if(etPassword.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    (iconPasswordToggle).setImageResource(R.drawable.hide_pass_icon);

                    //Show Password
                    etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    etPassword.setSelection(etPassword.getText().length());
                }
                else{
                    (iconPasswordToggle).setImageResource(R.drawable.show_pass_icon);

                    //Hide Password
                    etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    etPassword.setSelection(etPassword.getText().length());
                }
                break;
            case R.id.sign_in_button:
                if(isSupportBiometricPrompt()) {
                    Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                    startActivityForResult(signInIntent, 1);
                }else{
                    showMessage("Untuk menggunakan fitur ini device anda harus support biometrik (fingerprint)");
                }
            break;
        }
    }

    private void showDialogBiometric(int loginVia, GoogleSignInAccount account) {
        promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Otentikasi Biometrik")
                .setSubtitle("Scan sidik jari anda")
                .setNegativeButtonText("Batal")
                .build();

        biometricPrompt = new BiometricPrompt(MlebuActivity.this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                Toast.makeText(MlebuActivity.this, (String) errString, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                //authentication succeed, continue tasts that requires auth

                switch (loginVia) {
                    case LoginMethod.BIOMETRIC:
                        SharedPreferences sp1=getSharedPreferences("Login",0);
                        String unm  = sp1.getString("unm", null);
                        String pass = sp1.getString("pas", null);

                        if(unm != null && pass != null) {
                            login(unm, pass);
                            Toast.makeText(MlebuActivity.this, "Otentikasi berhasil", Toast.LENGTH_SHORT).show();
                        }else{
                            showMessage("Anda harus login minimal 1x untuk menggunakan fitur biometrik");
                        }
                        break;
                    case LoginMethod.GOOGLE:
                        loginUsingGoogleSign(account);
                        break;
                }
            }

            @Override
            public void onAuthenticationFailed() {
                showMessage("Otentikasi gagal");
            }
        });

        biometricPrompt.authenticate(promptInfo);
    }

    private boolean isSupportBiometricPrompt() {
        PackageManager packageManager = this.getPackageManager();
        if (packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)) {
            return true;
        }
        return false;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == 1) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            if (resultCode == Activity.RESULT_OK) {
                Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                handleSignInResult(task);
            }
        }
    }

    private void updateUI(GoogleSignInAccount account) {
        if(account != null) {
            mGoogleSignInClient.signOut();
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> task) {
        if(task != null) {
            //send to server
            if(task.getResult() != null) {
                showDialogBiometric(LoginMethod.GOOGLE, task.getResult());
                //loginUsingGoogleSign(task.getResult());
            }
        }else{
            Toast.makeText(getApplicationContext(), "Otentikasi GAGAL", Toast.LENGTH_LONG).show();
        }
    }

    private void loginUsingGoogleSign(GoogleSignInAccount account) {
        String user = account.getEmail();
        String pswd = account.getIdToken();
        LoginTask task = new LoginTask(MlebuActivity.this,MlebuActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc= json.getString(content, "rc");
                if(rc.equals("0000") || rc.equals("0127")) {
                    //Toast.makeText(MlebuActivity.this,"Login berhasil",Toast.LENGTH_LONG).show();
                    String idmerc=json.getString(content,"id_merchant");
                    String name=json.getString(content,"name_merchant");
                    String user_key=json.getString(content,"token");
                    String type_merchant=json.getString(content,"type_merchant");
                    //String topiStatus=xml.getItem(content,"topi_status");
                    String topiStatus="0";

                    Wong.setIdmerch(idmerc);
                    Wong.setMerchant(name);
                    Wong.setUser_key(user_key);
                    Wong.setTypeMerchant(type_merchant);
                    Wong.setTopiStatus(topiStatus);

                    String email=user.trim();
                    String passs=pswd;
                    Wong.setEmail(email);
                    Wong.setPassword(passs);


                    updateUser(email);
                    Wong.setUserLogin(true);

                    if(rc.equals("0127")) {
                        showUpdateDialog();
                    }else{
                        Intent intent=new Intent(MlebuActivity.this,DashboardActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }else if(rc.equals("0104")) {
                    //redirect to registration activity
                    Intent intent=new Intent(MlebuActivity.this, RegistrasiActivity.class);
                    intent.putExtra("email", user);
                    intent.putExtra("name_merchant", account.getDisplayName());
                    startActivity(intent);
                    //finish();
                }else if(rc.equals("0128")) {
                    btnLogin.setEnabled(true);
                    String desc=json.getString(content,"message");
                    Toast.makeText(MlebuActivity.this,desc,Toast.LENGTH_LONG).show();
                }else{
                    btnLogin.setEnabled(true);
                    String desc=json.getString(content,"message");
                    Toast.makeText(MlebuActivity.this,desc,Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Exception e) {
                Toast.makeText(getApplicationContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }

        });
        task.execute(user,pswd, Integer.toString(LoginMethod.GOOGLE));
    }

    private void login(String username, String password){
        String user=username;
        String pswd=password;
        if(user.equals("") || pswd.equals("")){
            btnLogin.setEnabled(true);
            Toast.makeText(this,"User & Password harus diisi",Toast.LENGTH_SHORT).show();
            return;
        }
        final ProgressBar pbar=new PBarLinear(MlebuActivity.this, rootLayout);
        LoginTask task = new LoginTask(MlebuActivity.this,MlebuActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc= json.getString(content, "rc");
                if(rc.equals("0000") || rc.equals("0127")) {
                    //Toast.makeText(MlebuActivity.this,"Login berhasil",Toast.LENGTH_LONG).show();
                    String idmerc=json.getString(content,"id_merchant");
                    String name=json.getString(content,"name_merchant");
                    String user_key=json.getString(content,"token");
                    String type_merchant=json.getString(content,"type_merchant");
                    //String topiStatus=xml.getItem(content,"topi_status");
                    String topiStatus="0";

                    Wong.setIdmerch(idmerc);
                    Wong.setMerchant(name);
                    Wong.setUser_key(user_key);
                    Wong.setTypeMerchant(type_merchant);
                    Wong.setTopiStatus(topiStatus);

                    String email=user.trim();
                    String passs=pswd;
                    Wong.setEmail(email);
                    Wong.setPassword(passs);

                    updateUser(email);
                    Wong.setUserLogin(true);

                    SharedPreferences sp=getSharedPreferences("Login", 0);
                    SharedPreferences.Editor Ed=sp.edit();
                    Ed.putString("unm",email);
                    Ed.putString("pas",passs);
                    Ed.putString("idm", idmerc);
                    Ed.commit();

                    if(rc.equals("0127")) {
                        showUpdateDialog();
                    }else{
                        Intent intent=new Intent(MlebuActivity.this,DashboardActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }else{
                    btnLogin.setEnabled(true);
                    String desc=json.getString(content,"message");
                    Toast.makeText(MlebuActivity.this,desc,Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Exception e) {
                Toast.makeText(getApplicationContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }

        });
        task.execute(user,pswd, Integer.toString(LoginMethod.EMAIL_PASSWORD));
    }

    public void showUpdateDialog() {
        btnLogin.setEnabled(true);
        FancyAlertDialog.Builder
                .with(this)
                .setTitle("Update tersedia")
                .setBackgroundColor(Color.parseColor("#E2F3FD"))  // for @ColorRes use setBackgroundColorRes(R.color.colorvalue)
                .setMessage("Jadilah orang pertama merasakan fitur terbaru")
                .setNegativeBtnText("Nanti")
                .setPositiveBtnBackground(Color.parseColor("#0F78C9"))  // for @ColorRes use setPositiveBtnBackgroundRes(R.color.colorvalue)
                .setPositiveBtnText("Update")
                .setNegativeBtnBackgroundRes(R.color.common_google_signin_btn_text_light)  // for @ColorRes use setNegativeBtnBackgroundRes(R.color.colorvalue)
                .setAnimation(Animation.POP)
                .isCancellable(true)
                .setIcon(R.drawable.info_rekening, View.VISIBLE)
                .onPositiveClicked(dialog -> openPlaystoreForUpdate())
                .onNegativeClicked(dialog -> {
                    Intent intent=new Intent(MlebuActivity.this,DashboardActivity.class);
                    startActivity(intent);
                    finish();
                })
                .build()
                .show();
    }

    private void openPlaystoreForUpdate() {
        String appPackageName = getPackageName();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }

    private String userDB(){
        String s=null;
        DatabaseHelper dbHelper=new DatabaseHelper(MlebuActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        Cursor cursor = null;
        try{
            String[] args={};
            String sql="select "+ Profil.PROFIL_USERID+" ,"+Profil.PROFIL_PRINTER+","+Profil.PROFIL_PRINTER_UUID+" from "+Profil.PROFIL_TABLE+" ";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,args);
            if (cursor != null && cursor.getCount() > 0){
                cursor.moveToFirst();
                s=cursor.getString(0);
                String printer=cursor.getString(1);
                String uuid=cursor.getString(2);
                if(!printer.equals("0")){
                    Wong.setPrinterName(printer);
                }
                if(!uuid.equals("0")){
                    Wong.setPrinterUUID(uuid);
                }

                //Log.i("print dev",printer);
                //Log.i("print uuid",uuid);
            }
        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {

            try{
                if(cursor!=null){
                    cursor.close();
                }
                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return s;
    }

    private void updateUser(String user){

        String userid=user;
        DatabaseHelper dbHelper=new DatabaseHelper(MlebuActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            String strSQL = "UPDATE "+ Profil.PROFIL_TABLE+" SET "+Profil.PROFIL_USERID+" ='"+userid+"' ";

            db.execSQL(strSQL);
        }catch (Exception e){
            //Log.d("error",e.toString());
        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }

        }
    }

    private void showMessage(String message){
        Toast toast = Toast.makeText(MlebuActivity.this,message, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.TOP, 25, 400);
        toast.show();
    }


}