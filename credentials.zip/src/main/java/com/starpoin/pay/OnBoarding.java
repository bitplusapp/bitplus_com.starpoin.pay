package com.starpoin.pay;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.starpoin.pay.adapter.OnFinishLastPage;
import com.starpoin.pay.adapter.ViewPagerOnBoardingAdapter;

import java.util.List;

public class OnBoarding extends OnBoardingActivity {

    private int image;
    private int bgColor;
    private int txtColor;
    private String title;
    private String description;


    public OnBoarding(int image, int bgColor, int txtColor, String title, String description) {
        this.title = title;
        this.bgColor = bgColor;
        this.txtColor = txtColor;
        this.image = image;
        this.description = description;
    }

    public OnBoarding(int image, String title, String description) {
        this.title = title;
        this.image = image;
        bgColor = Color.WHITE;
        this.description = description;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getBgColor() {
        return bgColor;
    }

    public void setBgColor(int bgColor) {
        this.bgColor = bgColor;
    }

    public int getTxtColor() {
        return txtColor;
    }

    public void setTxtColor(int txtColor) {
        this.txtColor = txtColor;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public static void startOnBoarding(@NonNull Activity activity, @NonNull List<OnBoarding> pages, @Nullable OnFinishLastPage onFinishClick){
        if (pages.size() < 3 || pages.size() > 6)
            throw new MaterialGuidelinesViolationException("This library follows material design guidelines and according to that, On-boarding screen must be of at least 3 & at most 6 pages");
        activity.setContentView(R.layout.activity_on_boarding);
        activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        if (activity instanceof AppCompatActivity){
            AppCompatActivity app = (AppCompatActivity) activity;
            if (app.getSupportActionBar() != null)
                app.getSupportActionBar().hide();
        } else {
            if (activity.getActionBar() != null)
                activity.getActionBar().hide();
        }

        Button next = activity.findViewById(R.id.next);
        ViewPager2 pager = activity.findViewById(R.id.viewpager);
        LinearLayout indicator = activity.findViewById(R.id.indicator);
        ViewPagerOnBoardingAdapter adapter = new ViewPagerOnBoardingAdapter(pages);
        TextView[] dots = new TextView[pages.size()];
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView(activity);
            dots[i].setText("•");
            dots[i].setTextSize(40);
            dots[i].setTextColor(Color.rgb(164,194,253));
            indicator.addView(dots[i]);
        }
        pager.setAdapter(adapter);
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                if (position != 0)
                    dots[position - 1].setTextColor(Color.rgb(164,194,253));
                if (position < pages.size() - 1)
                    dots[position + 1].setTextColor(Color.rgb(164,194,253));
                if (position == pages.size() - 1)
                    next.setText("Selesai");
                else
                    next.setText("Lanjut");
                dots[position].setTextColor(Color.rgb(107,148,234));
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentPage = pager.getCurrentItem();
                if (currentPage == pages.size() - 1){
                    if (onFinishClick != null){
                        onFinishClick.onNext();
                    } else {
                        activity.finish();
                    }
                } else
                    pager.setCurrentItem(currentPage + 1);
            }
        });
    }
}

class MaterialGuidelinesViolationException extends RuntimeException {
    public MaterialGuidelinesViolationException(String message){
        super(message);
    }
}


