package com.starpoin.pay;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.topi.Beli;
import com.starpoin.pay.topi.DataProduk;
import com.starpoin.pay.topi.Produk;
import com.starpoin.pay.topi.adapter.BeliAdapter;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import malik.org.json.JSONObject;

public class TopibeliActivity extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;
    private AutoCompleteTextView etProduk;
    private EditText etQty;
    private Button btnScan,btnTambah,btnSimpan;
    private TextView tvTotal;
    private int REQUEST_CODE=1;
    private Produk SELECTED_PRODUK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topibeli);

        setTitle("Pembelian");

        rootLayout=findViewById(R.id.rootLayout);

        etProduk=findViewById(R.id.etProduk);
        etQty=findViewById(R.id.etQty);

        btnScan=findViewById(R.id.btnScan);
        btnScan.setOnClickListener(this);

        btnTambah=findViewById(R.id.btnTambah);
        btnTambah.setOnClickListener(this);

        btnSimpan=findViewById(R.id.btnSimpan);
        btnSimpan.setOnClickListener(this);

        tvTotal=findViewById(R.id.tvTotal);

        List<Produk> list=new DataProduk().getListProduk(TopibeliActivity.this);
        ArrayAdapter<Produk> adapterProduk=new ArrayAdapter<>(TopibeliActivity.this,R.layout.support_simple_spinner_dropdown_item,list);
        etProduk.setAdapter(adapterProduk);
        etProduk.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                SELECTED_PRODUK =(Produk) parent.getItemAtPosition(position);
                String kode=SELECTED_PRODUK.getKode_produk();
                etProduk.setText(kode);

            }
        });

        setListBeli();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //getMenuInflater().inflate(R.menu.topi_jual_menu, menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.topi_jual_menu, menu);
        MenuItem itemPrint=menu.findItem(R.id.print);
        itemPrint.setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.print:
                //printUlang();
                return true;
            case R.id.reset:
                new Beli().clearItem(TopibeliActivity.this);
                setListBeli();

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Check that it is the SecondActivity with an OK result
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {

                // Get String data from Intent
                String kode_barcode = data.getStringExtra("barcode");
                etProduk.setText(kode_barcode);
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnScan:
                Intent intent = new Intent(this, ScanBarcodeActivity.class);
                startActivityForResult(intent, REQUEST_CODE);

                break;
            case R.id.btnTambah:
                tambahItem();
                break;
            case R.id.btnSimpan:
                confirmSimpan();
                break;
        }
    }

    private void setListBeli(){
        ArrayList<Beli> listJual=new Beli().listBeli(TopibeliActivity.this);
        BeliAdapter adapter=new BeliAdapter(TopibeliActivity.this,R.layout.topi_jual_adapter,listJual);
        ListView listview=findViewById(R.id.listview);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Beli jual=(Beli)parent.getItemAtPosition(position);

                updateItem(jual);
            }
        });
        int total=0;
        for(Beli j:listJual){
            int hj=Integer.parseInt(j.getHarga_beli());
            int qty=Integer.parseInt(j.getQty());
            int sub=hj*qty;
            total+=sub;
        }
        DecimalFormat df=new DecimalFormat("#,##0");
        //TextView tvTotal=findViewById(R.id.tvTotal);
        tvTotal.setText(df.format(total));

        int rows=listJual.size();
        if(rows>=1){
            if(!btnSimpan.isEnabled()){
                btnSimpan.setEnabled(true);
            }
        }else{
            btnSimpan.setEnabled(false);
        }
    }

    private void tambahItem(){
        String kode=etProduk.getText().toString().trim();
        String qty=etQty.getText().toString().trim().replaceAll("\\.","").replaceAll(",","");

        if(kode.length()<1){
            showMsg("Produk belum sesuai");
            return;
        }
        if(qty.length()<1){
            showMsg("Qty belum diisi");
            return;
        }

        Produk prod=new DataProduk().getDataByKode(TopibeliActivity.this,kode);

        if(prod==null){
            showMsg("Produk belum terdaftar");
            return;
        }
        String nama_produk=prod.getNama_produk();
        String satuan=prod.getSatuan();
        String hb=prod.getHarga_beli();
        String hj=prod.getHarga_jual();
        String idmerc= Wong.getIdmerch();

        Beli beli=new Beli();
        beli.setId_merchant(idmerc);
        beli.setKode_produk(kode);
        beli.setNama_produk(nama_produk);
        beli.setSatuan(satuan);
        beli.setQty(qty);
        beli.setHarga_beli(hb);

        String str=new Beli().addItemBeli(TopibeliActivity.this,beli);
        if(str.equals("00")){
            setListBeli();
            etProduk.setText("");
            etQty.setText("");
        }else{
            showMsg(str);
        }
    }

    private void updateItem(Beli beli){
        final BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.topi_update_item);
        EditText etQty=dialog.findViewById(R.id.etQty);
        etQty.setText(beli.getQty());
        Button btnHapus=dialog.findViewById(R.id.btnHapus);
        btnHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                String msg=new Beli().deleteItem(TopibeliActivity.this,beli.getId());
                if(msg.equals("00")){
                    setListBeli();
                }
            }
        });

        Button btnUpdate=dialog.findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                String newqty=etQty.getText().toString().trim().replaceAll("\\.","").replaceAll(",","");
                String msg=new Beli().updateItem(TopibeliActivity.this,beli,newqty);
                if(msg.equals("00")){
                    setListBeli();
                }
            }
        });

        Button btnBatal=dialog.findViewById(R.id.btnBatal);
        btnBatal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        dialog.show();
    }

    private void confirmSimpan(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Konfirmasi");
        builder.setMessage("Simpan transaksi ?");

        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Do nothing but close the dialog
                simpanTrans();
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                // Do nothing
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();

    }

    private void simpanTrans(){
        ArrayList<Beli> listBeli=new Beli().listBeli(this);
        Map<String,Object> maplist=new HashMap<>();
        maplist.put("item",listBeli);
        malik.org.json.JSONObject job=new malik.org.json.JSONObject(maplist);


        Map<String,Object> map=new HashMap<>();
        map.put("q","add_beli");
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("json",job.toString());
        String params="Topi"+new Params().buildParams(map);
        TransTask task = new TransTask(TopibeliActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JSONObject job=new JSONObject(content);

                String rc=job.getString("rc");
                if(rc.equals("0000")){
                    updateStokLocal(listBeli);
                    new Beli().clearItem(TopibeliActivity.this);
                    setListBeli();
                }else{
                    String desc=job.getString("desc");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void updateStokLocal(ArrayList<Beli> listBeli){
        ArrayList<Produk> list=new ArrayList<>();
        for(Beli beli:listBeli){
            Produk prod=new Produk();
            prod.setKode_produk(beli.getKode_produk());
            prod.setQty(beli.getQty());
            list.add(prod);
        }
        new DataProduk().updateStok(TopibeliActivity.this,list);
    }
}