package com.starpoin.pay;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.topi.Laporan;
import com.starpoin.pay.topi.Produk;
import com.starpoin.pay.topi.adapter.LaporanAdapter;
import com.starpoin.pay.util.DateParse;
import com.starpoin.pay.util.DatePick;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import malik.org.json.JSONObject;

public class TopiLapjualActivity extends AbaseActivity implements View.OnClickListener {
    private ConstraintLayout rootLayout;
    private Button btnDrtgl,btnSdtgl,btnCari;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topi_lapjual);

        setTitle("Laporan Penjualan");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        btnDrtgl=findViewById(R.id.btnDrtgl);
        btnDrtgl.setOnClickListener(this);

        btnSdtgl=findViewById(R.id.btnSdtgl);
        btnSdtgl.setOnClickListener(this);

        btnCari=findViewById(R.id.btnCari);
        btnCari.setOnClickListener(this);

        String tgl=new SimpleDateFormat("dd/MM/yyyy").format(new Date());
        btnDrtgl.setText(tgl);
        btnSdtgl.setText(tgl);

        String str1=btnDrtgl.getText().toString();
        String str2=btnSdtgl.getText().toString();

        String drtgl=new DateParse().tglDefault(str1);
        String sdtgl=new DateParse().tglDefault(str2);
        searchReport(drtgl,sdtgl);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnDrtgl:
                new DatePick(TopiLapjualActivity.this,btnDrtgl).onClick(v);
                break;
            case R.id.btnSdtgl:
                new DatePick(TopiLapjualActivity.this,btnSdtgl).onClick(v);
                break;
            case R.id.btnCari:
                String str1=btnDrtgl.getText().toString();
                String str2=btnSdtgl.getText().toString();

                String drtgl=new DateParse().tglDefault(str1);
                String sdtgl=new DateParse().tglDefault(str2);
                searchReport(drtgl,sdtgl);
                break;
        }
    }

    private void searchReport(String drtgl, String sdtgl){
        Map<String,Object> mapJson=new HashMap<>();
        mapJson.put("dari_tanggal",drtgl);
        mapJson.put("sampai_tanggal",sdtgl);
        JSONObject job=new JSONObject(mapJson);

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","lap_jual_produk");
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("json", job);
        String params="Topi"+new Params().buildParams(map);
        TransTask task = new TransTask(TopiLapjualActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JSONObject resp=new JSONObject(content);
                String rc=resp.getString("rc");
                if(rc.equals("0000")){
                    viewContent(resp);
                }else{
                    String desc=resp.getString("desc");
                    showMsg(desc);
                }

            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewContent(JSONObject resp){
        EditText etFilter = (EditText) findViewById(R.id.etFilter);


        ArrayList<Produk> list=new Laporan().lapJual(resp);
        LaporanAdapter adapter=new LaporanAdapter(TopiLapjualActivity.this,R.layout.topi_laporan_adapter,list,etFilter);
        ListView listview=findViewById(R.id.listview);
        listview.setAdapter(adapter);
        etFilter.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                // When user changed the Text

                adapter.getFilter().filter(cs.toString());
            }

            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                          int arg3) {
                // TODO Auto-generated method stub

            }

            public void afterTextChanged(Editable arg0) {
                // TODO Auto-generated method stub
            }
        });

        TextView tvQty=findViewById(R.id.tvQty);
        TextView tvTotal=findViewById(R.id.tvTotal);

        DecimalFormat df=new DecimalFormat("#,##0");
        Produk prod=new Laporan().getTotal(resp);
        double totQty= Double.parseDouble(prod.getQty());
        double total= Double.parseDouble(prod.getStok());
        tvQty.setText(df.format(totQty));
        tvTotal.setText(df.format(total));
        //LinearLayout layout=findViewById(R.id.layoutTitle);
        //layout.setVisibility(View.VISIBLE);
    }
}