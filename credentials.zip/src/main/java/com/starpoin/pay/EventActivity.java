package com.starpoin.pay;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.starpoin.pay.helper.LoadingHelper;

public class EventActivity extends AppCompatActivity {

    private Button button_info;
    private Context context;
    private FirebaseApp app;
    private FirebaseAuth mAuth;
    private static String email = "bitplus@jtmbiketrack.com";
    private static String password = "12345678";
    private LoadingHelper loading;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);
        getSupportActionBar().hide();

        context = this;

        loading = new LoadingHelper(this);
        loading.showLoadingOverlay();

        try{
            app = FirebaseApp.getInstance("secondary");
        }catch (Exception e) {
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApplicationId("1:741341997351:android:2cf9648693f49615032102") // Required for Analytics.
                    .setApiKey("AIzaSyCZTsboUVB1p7mDSd5HeGz4UqZUZygl9io") // Required for Auth.
                    .setDatabaseUrl("https://jtmtimingsystem-dab4a-default-rtdb.firebaseio.com") // Required for RTDB.
                    .build();

            // Inisialisasi FirebaseApp di sini
            FirebaseApp.initializeApp(this /* Context */, options, "secondary");
            app = FirebaseApp.getInstance("secondary");
        }
        mAuth = FirebaseAuth.getInstance(app);

        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {
            //siginfirst
            SiginToFirebaseAuth();
        }else{
            loading.hideLoadingOverlay();
        }

        button_info = findViewById(R.id.button_info);
        button_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, DetailEvent.class));
            }
        });

    }

    private void SiginToFirebaseAuth() {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign-in successful, user is signed in
                            FirebaseUser user = mAuth.getCurrentUser();
                            loading.hideLoadingOverlay();
                        } else {
                            // Sign-in failed
                            Toast.makeText(context, "Gagal Mengambil data.", Toast.LENGTH_SHORT).show();
                            loading.hideLoadingOverlay();
                        }
                    }
                });
    }
}