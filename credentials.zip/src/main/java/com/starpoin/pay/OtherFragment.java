package com.starpoin.pay;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.SaldoTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.PrinterLib;
import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;

import java.text.DecimalFormat;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link OtherFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OtherFragment extends Fragment implements View.OnClickListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    //private TextView titleLabel,lblIdmerc;
    private Button btnLapOn,btnCashback,btnVouStatus,btnCekTrans,btnLapTiket,btnSaldo;//laporan
    private Button btnReqPrint,btnAdminbank,btnPrinterSetup,btnTestprint,btnPassword,btnInfo,btnLogo;//utility
    //private Button btnTiket;

    private ConstraintLayout rootLayout;
    private BluetoothAdapter btAdapter;

    public OtherFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OtherFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OtherFragment newInstance(String param1, String param2) {
        OtherFragment fragment = new OtherFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        btAdapter = BluetoothAdapter.getDefaultAdapter();
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_other, container, false);
        rootLayout=view.findViewById(R.id.rootLayout);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getActivity().getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor("#0F78C9"));
        }

        btnLapOn=(Button) view.findViewById(R.id.btnLapOn);
        btnLapOn.setOnClickListener(this);

        btnCashback=(Button) view.findViewById(R.id.btnCashback);
        btnCashback.setOnClickListener(this);

        btnCekTrans=(Button) view.findViewById(R.id.btnCekTrans);
        btnCekTrans.setOnClickListener(this);

        btnLapTiket=(Button) view.findViewById(R.id.btnLapTiket);
        btnLapTiket.setOnClickListener(this);

        btnSaldo=(Button) view.findViewById(R.id.btnSaldo);
        btnSaldo.setOnClickListener(this);

        btnReqPrint=(Button) view.findViewById(R.id.btnReqPrint);
        btnReqPrint.setOnClickListener(this);

        btnAdminbank=(Button) view.findViewById(R.id.btnAdminbank);
        btnAdminbank.setOnClickListener(this);

        btnPrinterSetup=(Button) view.findViewById(R.id.btnPrinterSetup);
        btnPrinterSetup.setOnClickListener(this);


        btnTestprint=(Button) view.findViewById(R.id.btnTestprint);
        btnTestprint.setOnClickListener(this);

        btnPassword=(Button) view.findViewById(R.id.btnPassword);
        btnPassword.setOnClickListener(this);

        btnInfo=(Button) view.findViewById(R.id.btnInfo);
        btnInfo.setOnClickListener(this);

        btnLogo=(Button) view.findViewById(R.id.btnLogo);
        btnLogo.setOnClickListener(this);


        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }



    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View view) {
        Intent intent=null;
        switch (view.getId()){
            case R.id.btnPrinterSetup:
                intent=new Intent(OtherFragment.this.getContext(),PrinterListActivity.class);
                startActivity(intent);
                break;
            case R.id.btnTestprint:
                btAdapter = BluetoothAdapter.getDefaultAdapter();
                if (!btAdapter.isEnabled()) {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent,2);
                }else{
                    String text=createContentDataPrint();
                    new PrinterTask().execute(text);
                }
                break;
            case R.id.btnLapOn:
                intent=new Intent(OtherFragment.this.getContext(),LaporanActivity.class);
                startActivity(intent);
                break;
            case R.id.btnCashback:
                intent=new Intent(OtherFragment.this.getContext(),LapCashbackActivity.class);
                startActivity(intent);
                break;
            case R.id.btnCekTrans:
                intent=new Intent(OtherFragment.this.getContext(),CektransaksiActivity.class);
                startActivity(intent);
                break;
            case R.id.btnSaldo:
                reqSaldo();
                break;
            case R.id.btnLapTiket:
                intent=new Intent(OtherFragment.this.getContext(),LapTiketActivity.class);
                startActivity(intent);
                break;
            case R.id.btnReqPrint:
                intent=new Intent(OtherFragment.this.getContext(),PrintUlangActivity.class);
                startActivity(intent);
                break;
            case R.id.btnPassword:
                intent=new Intent(OtherFragment.this.getContext(),ChangePwdActivity.class);
                startActivity(intent);
                break;
            case R.id.btnLogo:
                intent=new Intent(OtherFragment.this.getContext(),LogoActivity.class);
                startActivity(intent);
                break;
            case R.id.btnInfo:
                intent=new Intent(OtherFragment.this.getContext(),InfoRekeningActivity.class);
                startActivity(intent);
                break;

        }




    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }





    private String createContentDataPrint() {
        String line ="------------------------------";
        String br=System.getProperty("line.separator");

        StringBuilder sb = new StringBuilder();
        sb.append("__                          __");
        sb.append("\n");
        sb.append("|                             |");
        sb.append("");
        sb.append(TextSpace.rataTengah("PEMBELIAN TOKEN PLN"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("Simple & Mudah"));
        sb.append("\n");
        sb.append(line);
        sb.append("\n");
        sb.append("Tgl Trans  : 123456789");
        sb.append("\n");
        sb.append("No Meter   : 12345678901");
        sb.append("\n");
        sb.append("ID Pel     : 123456789012");
        sb.append("\n");
        sb.append("Nama       : Test Cetak Printer");
        sb.append("\n");
        sb.append("Tarif/Daya : R1/1300");
        sb.append("\n");
        sb.append("Denom      : Rp. 20.000");
        sb.append("\n");
        sb.append("kWh        : 10");
        sb.append("\n");
        sb.append(line);
        sb.append(br);
        sb.append(TextSpace.rataTengah("TOKEN"));
        sb.append(br);
        sb.append(TextSpace.rataTengah("1111-2222-3333-4444-5555"));
        sb.append(br);
        sb.append(line);
        sb.append(br);
        sb.append(TextSpace.rataTengah("Terima Kasih"));
        sb.append(br);
        sb.append(TextSpace.rataTengah("CA : "+Wong.getIdmerch()+" bitplus Mobile"));
        sb.append(br);
        return sb.toString();
    }



    private class PrinterTask extends AsyncTask<String, Void, String> {
        private String content;
        private boolean error = false;
        private ProgressDialog dialog = new ProgressDialog(getActivity());

        protected void onPreExecute() {
            dialog.setMessage("Menghubungi printer...");
            dialog.show();
        }

        @Override
        protected String doInBackground(String... urls) {
            try{

                String URL = urls[0];

                content=new PrinterLib(getActivity()).print(URL);
            }catch (Exception e){
                System.out.print(e.toString());
            }


            return content;
        }

        protected void onCancelled() {
            dialog.dismiss();
            //showMessage("Error connecting to Server");
        }

        protected void onPostExecute(String content) {
            dialog.dismiss();
            if(!content.equals("1")){
                Toast toast = Toast.makeText(getActivity(),
                        content, Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP, 25, 400);
                toast.show();
            }

        }

    }

    private void reqSaldo(){

        SaldoTask task = new SaldoTask(OtherFragment.this.getContext(),OtherFragment.this.getActivity(), new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")){
                    showSaldo(content);
                }else{
                    String desc=json.getString(content,"message");
                    Toast.makeText(OtherFragment.this.getContext(),desc,Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Exception e) {
                Toast.makeText(OtherFragment.this.getContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }

        });
        task.execute();
    }

    private void showSaldo(String resul){
        JsonIn json=new JsonIn();

        DecimalFormat df=new DecimalFormat("#,##0");
        String typeMerchant = Wong.getTypeMerchant();
        String scredit = json.getObjectWithString(resul,"data", "balance");
        String sots = json.getObjectWithString(resul,"data", "outstanding");

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(OtherFragment.this.getContext(), R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.show_saldo);
        LinearLayout lyOts=bottomSheetDialog.findViewById(R.id.lyOts);

        TextView tvNamaMerchant=bottomSheetDialog.findViewById(R.id.tvNamaMerchant);
        TextView tvCredit=bottomSheetDialog.findViewById(R.id.tvCredit);
        TextView tvOts=bottomSheetDialog.findViewById(R.id.tvOts);
        tvNamaMerchant.setText(Wong.getIdmerch());
        tvCredit.setText(df.format(Double.parseDouble(scredit)));
        if(!typeMerchant.equals("1")||!typeMerchant.equals("3")){
            tvOts.setText(df.format(Double.parseDouble(sots)));
            lyOts.setVisibility(View.VISIBLE);
        }

        Button btnClose = bottomSheetDialog.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });
        /*LinearLayout copy = bottomSheetDialog.findViewById(R.id.copyLinearLayout);
        LinearLayout share = bottomSheetDialog.findViewById(R.id.shareLinearLayout);
        LinearLayout upload = bottomSheetDialog.findViewById(R.id.uploadLinearLayout);
        LinearLayout download = bottomSheetDialog.findViewById(R.id.download);
        LinearLayout delete = bottomSheetDialog.findViewById(R.id.delete);*/

        bottomSheetDialog.show();
    }


}
