package com.starpoin.pay;

import android.content.Intent;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.erif.contentloader.ContentLoaderFrameLayout;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.adapter.GridMenuAdapter;
import com.starpoin.pay.adapter.SlidePageTransformer;
import com.starpoin.pay.adapter.SlideshowAdapter;
import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.Notifikasi;
import com.starpoin.pay.model.ConnectionQuality;
import com.starpoin.pay.model.LapTrans;
import com.starpoin.pay.task.BannerTask;
import com.starpoin.pay.task.NetworkTask;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OnNetworkListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.SaldoTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;
import com.starpoin.pay.util.Wong;
import com.starpoin.pay.util.XmlIn;
import com.viewpagerindicator.CirclePageIndicator;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link TransFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TransFragment extends Fragment implements View.OnClickListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private OnFragmentInteractionListener mListener;
    private ConstraintLayout rootLayout;
    private ImageView imgShowBalance, imgTiket,imgLapTiket;
    private TextView txtNameMerchant, txtTypeMerchant, txtBalance;
//    private Button btnSaldo;
    private LinearLayout btnTiket, btnLapTiket, layoutRiwayatTopup;
    private RecyclerView rvProduk;
    private CirclePageIndicator indicator;
    private ViewPager viewPager;
    private List<String> imageUrls = new ArrayList<>();
    private int currentPage = 0;
    private int numPages = 0;
    private ImageButton notificationButton, iBConnectionStatus;
    private Handler handler;
    private Runnable runnable;
    private ContentLoaderFrameLayout loader, bannerLoader;


    public TransFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TransFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TransFragment newInstance(String param1, String param2) {
        TransFragment fragment = new TransFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_new_trans, container, false);

        // Membuat status bar transparan
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getActivity().getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor("#AFD5F2"));
        }

        notificationButton = view.findViewById(R.id.notificationButton);

        layoutRiwayatTopup = view.findViewById(R.id.layoutRiwayatTopup);
        layoutRiwayatTopup.setOnClickListener(this);

        imgLapTiket = (ImageView) view.findViewById(R.id.imgLapTiket);
        imgLapTiket.setOnClickListener(this);

        btnLapTiket = (LinearLayout) view.findViewById(R.id.btnLapTiket);
        btnLapTiket.setOnClickListener(this);

        imgTiket = (ImageView) view.findViewById(R.id.imgTiket);
        imgTiket.setOnClickListener(this);

        btnTiket=(LinearLayout) view.findViewById(R.id.btnTiket);
        btnTiket.setOnClickListener(this);

        iBConnectionStatus = view.findViewById(R.id.iBConnectionStatus);

        rvProduk = view.findViewById(R.id.rvProduk);
        rvProduk.setLayoutManager(new GridLayoutManager(TransFragment.this.getContext(), 4));
        ArrayList<LapTrans> products = new LapTrans().listProdukWithImageForDashboard();
        GridMenuAdapter adapter = new GridMenuAdapter(products);
        rvProduk.setAdapter(adapter);

        adapter.setOnItemClickListener(new GridMenuAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(LapTrans product) {
                onClickMenuOnRecycleView(product.getId());
            }
        });

        txtNameMerchant = (TextView) view.findViewById(R.id.txtNameMerchant);
        txtNameMerchant.setText(Wong.getMerchant());
//
//        txtTypeMerchant = (TextView) view.findViewById(R.id.txtTypeMerchant);
//        txtTypeMerchant.setText(Wong.getTypeMerchant());

        imgShowBalance = (ImageView) view.findViewById(R.id.imgShowBalance);
        imgShowBalance.setOnClickListener(this);

        notificationButton = view.findViewById(R.id.notificationButton);
        notificationButton.setOnClickListener(this);

        txtBalance = (TextView) view.findViewById(R.id.txtBalance);
        txtBalance.setOnClickListener(this);

        viewPager = view.findViewById(R.id.viewPager);
        indicator = view.findViewById(R.id.indicator);
        getDataFromApi();

        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                reCheckConnection();
                // Jadwalkan pengecekan berikutnya setelah 10 detik
                handler.postDelayed(this, 3000);
            }
        };

        handler.postDelayed(runnable, 3000);

        view.setFocusableInTouchMode(true);
        view.requestFocus();

        loader = view.findViewById(R.id.saldoLoader);
        bannerLoader = view.findViewById(R.id.bannerLoader);
        bannerLoader.startAndHideContent(viewPager, true);
        NestedScrollView nestedScrollView = view.findViewById(R.id.nsView);
        CardView cardView = view.findViewById(R.id.cardView);

        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                float maxCardHeight = getResources().getDimension(R.dimen.max_card_height);
                float minCardHeight = getResources().getDimension(R.dimen.min_card_height);
                float scrollThreshold = getResources().getDimension(R.dimen.scroll_threshold);

                float scrollPercentage = scrollY / scrollThreshold;
                float newCardHeight = maxCardHeight - (maxCardHeight - minCardHeight) * scrollPercentage;

                // Memastikan tinggi card view tidak kurang dari min_card_height
                if (newCardHeight < minCardHeight) {
                    newCardHeight = minCardHeight;
                }

                cardView.getLayoutParams().height = (int) newCardHeight;

                // Mengubah visibilitas komponen berdasarkan tinggi CardView
                if (newCardHeight < getResources().getDimension(R.dimen.collapse_threshold)) {
                    txtNameMerchant.setVisibility(View.GONE);
                    txtBalance.setVisibility(View.GONE);
                    layoutRiwayatTopup.setVisibility(View.GONE);
                    notificationButton.setVisibility(View.GONE);
                } else {
                    txtNameMerchant.setVisibility(View.VISIBLE);
                    txtBalance.setVisibility(View.VISIBLE);
                    layoutRiwayatTopup.setVisibility(View.VISIBLE);
                    notificationButton.setVisibility(View.VISIBLE);
                }

                cardView.requestLayout();
            }
        });


        // Do your process
        return view;
    }

    private void updateConnectionIndicator(ConnectionQuality quality) {
        switch (quality) {
            case GOOD:
                iBConnectionStatus.setBackgroundResource(R.drawable.circle_green);
                break;
            case MODERATE:
                iBConnectionStatus.setBackgroundResource(R.drawable.circle_yellow);
                break;
            case POOR:
                iBConnectionStatus.setBackgroundResource(R.drawable.circle_red);
                break;
            default:
                // Default case, jika quality tidak sesuai dengan nilai yang diharapkan.
                // Anda dapat mengatur tindakan default yang sesuai.
                break;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        countAllUnreadNotification();
        handler.removeCallbacks(runnable);
        handler.postDelayed(runnable, 5000);
    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(runnable);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private void showShimmer(View viewId) {
        loader.setVisibility(View.VISIBLE);
        loader.startAndHideContent(viewId, true);
    }

    private void hideShimmer(View viewId) {
        loader.setVisibility(View.GONE);
        loader.stopAndShowContent(viewId, true);
    }

    private void reCheckConnection() {
        NetworkTask task = new NetworkTask(TransFragment.this.getContext(), new OnNetworkListener<ConnectionQuality>() {
            @Override
            public void onSuccess(ConnectionQuality quality) {
                updateConnectionIndicator(quality);
            }

            @Override
            public void onFailure(Exception e) {
                updateConnectionIndicator(ConnectionQuality.POOR);
            }
        });

        task.execute();

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnLapTiket:
            case R.id.imgLapTiket:
                Intent intent =new Intent(this.getContext(), LapTiketActivity.class);
                startActivity(intent);
                break;
            case R.id.layoutRiwayatTopup:
                Intent riwayatTopup =new Intent(this.getContext(), RiwayatTopup.class);
                startActivity(riwayatTopup);
                break;
            case R.id.btnSaldo:
                reqSaldo();
                break;
            case R.id.btnTiket:
            case R.id.imgTiket:
                Intent tiket=new Intent(this.getContext(),TiketActivity.class);
                startActivity(tiket);
                break;
//            case R.id.btnTopi:
//                Intent topi=new Intent(this.getContext(),TopiMenuActivity.class);
//                startActivity(topi);
//                break;
            case R.id.notificationButton:
                Intent notifikasiList=new Intent(this.getContext(), NotifikasiActivity.class);
                startActivity(notifikasiList);
                break;
            case R.id.imgShowBalance:
            case R.id.txtBalance:
                if ("Tap untuk lihat".equals(txtBalance.getText().toString())) {
                    txtBalance.setText("");
                    showShimmer(txtBalance);
                    (imgShowBalance).setImageResource(R.drawable.eye_close_white);
                    checkBalance();
                } else {
                    txtBalance.setText("");
                    (imgShowBalance).setImageResource(R.drawable.eye_open_white);
                    txtBalance.setText("Tap untuk lihat");
                }
                break;
        }

    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    private void getDataFromApi() {
        BannerTask task = new BannerTask(TransFragment.this.getContext(), TransFragment.this.getActivity(), new OnEventListener<String>() {
            @Override
            public void onSuccess(String object) {
                try {
                    JSONObject response = new JSONObject(object);
                    JSONArray item = response.getJSONArray("data");
                    for(int i = 0; i < item.length(); i++) {
                        //String Title = (item.getJSONObject(i).getString("title"));
                        String ImageUrl = (item.getJSONObject(i).getString("image_url"));
                        imageUrls.add(ImageUrl);
                    }
                    SlideshowAdapter adapter = new SlideshowAdapter(TransFragment.this.getContext(), imageUrls);
                    float density = getResources().getDisplayMetrics().density;
                    //Set circle indicator radius
                    indicator.setRadius(5 * density);
                    numPages = imageUrls.size();
                    // Auto getData of viewpager
                    Runnable update = new Runnable() {
                        @Override
                        public void run() {
                            if (currentPage == numPages) {
                                currentPage = 0;
                            }
                            viewPager.setCurrentItem(currentPage++, true);
                        }
                    };
                    Timer swipeTimer = new Timer();
                    swipeTimer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            new Handler(Looper.getMainLooper()).post(update);
                        }
                    }, 5000, 5000);
                    // Pager listener over indicator
                    indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                        @Override
                        public void onPageSelected(int position) {
                            currentPage = position;
                        }

                        @Override
                        public void onPageScrolled(int pos, float arg1, int arg2) {}

                        @Override
                        public void onPageScrollStateChanged(int pos) {}
                    });

                    adapter.setOnImageClickListener(new SlideshowAdapter.OnImageClickListener() {
                        @Override
                        public void onImageClick(String imageUrl) {
                            // Lakukan tindakan yang diinginkan saat gambar diklik
                            // Misalnya, buka activity atau tampilkan URL dalam browser
                            if(imageUrl.contains("event")) {
                                startActivity(new Intent(TransFragment.this.getContext(), EventActivity.class));
                            }
                        }
                    });

                    SlidePageTransformer transformer = new SlidePageTransformer();
                    viewPager.setPageTransformer(true, transformer);
                    viewPager.setAdapter(adapter);
                    indicator.setViewPager(viewPager);
                    bannerLoader.stopAndShowContent(viewPager, true);
                }catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Exception e) {
                System.out.println(e.getMessage());
            }
        });

        task.execute("banner");
    }


    private void checkBalance() {
        SaldoTask task = new SaldoTask(TransFragment.this.getContext(),TransFragment.this.getActivity(), new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json=new JsonIn();
                String rc=json.getString(content,"rc");
                String data=json.getString(content, "data");
                if(rc.equals("0000")){
                    showSaldoToTextView(data);
                }else{
                    String desc=json.getString(content,"message");
                    Toast.makeText(TransFragment.this.getContext(),desc,Toast.LENGTH_LONG).show();
                }
                hideShimmer(txtBalance);
            }

            @Override
            public void onFailure(Exception e) {
                Toast.makeText(TransFragment.this.getContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }

        });
        task.execute();
    }

    private void reqSaldo(){
        SaldoTask task = new SaldoTask(TransFragment.this.getContext(),TransFragment.this.getActivity(), new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                XmlIn xml=new XmlIn();
                String rc=xml.getItem(content,"rc");
                if(rc.equals("0000")){
                    showSaldo(content);
                }else{
                    String desc=xml.getItem(content,"desc");
                    Toast.makeText(TransFragment.this.getContext(),desc,Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Exception e) {
                Toast.makeText(TransFragment.this.getContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }

        });
        task.execute();
    }

    private void onClickMenuOnRecycleView(int product) {
        switch (product) {
            case Produk.POSTPAID:
                Intent postpaid=new Intent(TransFragment.this.getContext(),PostpaidActivity.class);
                startActivity(postpaid);
                break;
            case Produk.PREPAID:
                Intent prepaid=new Intent(TransFragment.this.getContext(),PrepaidActivity.class);
                startActivity(prepaid);
                break;
            case Produk.NONTAGLIS:
                Intent nontaglis=new Intent(TransFragment.this.getContext(),NontaglisActivity.class);
                startActivity(nontaglis);
                break;
            case Produk.PULSA:
                Intent pulsa=new Intent(TransFragment.this.getContext(),PulsaActivity.class);
                startActivity(pulsa);
                break;
            case Produk.GAME:
                Intent game=new Intent(TransFragment.this.getContext(),GameActivity.class);
                startActivity(game);
                break;
            case Produk.PAKETDATA:
                Intent paketdata=new Intent(TransFragment.this.getContext(),PaketdataActivity.class);
                startActivity(paketdata);
                break;
            case Produk.TOPUP:
                Intent topup=new Intent(TransFragment.this.getContext(),TopupActivity.class);
                startActivity(topup);
                break;
            case Produk.JASTEL:
                Intent telkom=new Intent(TransFragment.this.getContext(),TelkomActivity.class);
                startActivity(telkom);
                break;
            case Produk.BPJS:
                Intent bpjs=new Intent(TransFragment.this.getContext(),BpjsActivity.class);
                startActivity(bpjs);
                break;
            case Produk.PDAM:
                Intent pdam=new Intent(TransFragment.this.getContext(),PdamActivity.class);
                startActivity(pdam);
                break;
            case Produk.PASCABAYAR:
                Intent paska=new Intent(TransFragment.this.getContext(),PascabayarActivity.class);
                startActivity(paska);
                break;
            case Produk.PBB:
                Intent pbb=new Intent(TransFragment.this.getContext(), PbbActivity.class);
                startActivity(pbb);
                break;
            case Produk.TVCABLE:
                Intent inetv=new Intent(TransFragment.this.getContext(), InternetTvCableActivity.class);
                startActivity(inetv);
                break;
            case Produk.SEMUA:
                showOtherProducts();
                break;
            default:
                Toast.makeText(TransFragment.this.getContext(),"Produk sedang dalam pengembangan",Toast.LENGTH_LONG).show();
                break;
        }
    }

    private void showSaldoToTextView(String data) {
        JsonIn json = new JsonIn();
        String credits = json.getString(data, "balance");
        DecimalFormat df=new DecimalFormat("#,##0");
        txtBalance.setText("Rp "+df.format(Double.parseDouble(credits)));
    }

    private void showOtherProducts() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(TransFragment.this.getContext(), R.style.BottomSheetDialogStyle);

        View bottomSheetView = LayoutInflater.from(TransFragment.this.getContext()).inflate(R.layout.product_layout, null);
        bottomSheetDialog.setContentView(bottomSheetView);

        ArrayList<LapTrans> produkBulanan = new LapTrans().listProdukTagihanBulanan();
        ArrayList<LapTrans> produkVoucher = new LapTrans().listProdukVoucher();
        ArrayList<LapTrans> produkLainnya = new LapTrans().listProdukLainnya();

        RecyclerView rvTagihanBulanan = bottomSheetDialog.findViewById(R.id.rvTagihanBulanan);
        rvTagihanBulanan.setLayoutManager(new GridLayoutManager(TransFragment.this.getContext(), 4));
        GridMenuAdapter adapterTagihan = new GridMenuAdapter(produkBulanan);
        rvTagihanBulanan.setAdapter(adapterTagihan);

        RecyclerView rvVoucher = bottomSheetDialog.findViewById(R.id.rvVoucher);
        rvVoucher.setLayoutManager(new GridLayoutManager(TransFragment.this.getContext(), 4));
        GridMenuAdapter adapterVoucher = new GridMenuAdapter(produkVoucher);
        rvVoucher.setAdapter(adapterVoucher);

        RecyclerView rvLainnya = bottomSheetDialog.findViewById(R.id.rvLainnya);
        rvLainnya.setLayoutManager(new GridLayoutManager(TransFragment.this.getContext(), 4));
        GridMenuAdapter adapterLainnya = new GridMenuAdapter(produkLainnya);
        rvLainnya.setAdapter(adapterLainnya);

        adapterTagihan.setOnItemClickListener(new GridMenuAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(LapTrans product) {
                onClickMenuOnRecycleView(product.getId());
                bottomSheetDialog.dismiss();
            }
        });

        adapterVoucher.setOnItemClickListener(new GridMenuAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(LapTrans product) {
                onClickMenuOnRecycleView(product.getId());
                bottomSheetDialog.dismiss();
            }
        });

        adapterLainnya.setOnItemClickListener(new GridMenuAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(LapTrans product) {
                onClickMenuOnRecycleView(product.getId());
                bottomSheetDialog.dismiss();
            }
        });


        bottomSheetDialog.show();
    }

    private void countAllUnreadNotification() {
        DatabaseHelper dbHelper=new DatabaseHelper(TransFragment.this.getContext());
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        List<Notifikasi> unreadNotification = new Notifikasi().getAllUnreadNotification(db);
        if(unreadNotification.size() > 0) {
            notificationButton.setImageResource(R.drawable.badge);
        }else{
            notificationButton.setImageResource(R.drawable.ic_notif);
        }
    }

    private void showSaldo(String result){
        XmlIn xml=new XmlIn();
        DecimalFormat df=new DecimalFormat("#,##0");
        String typeMerchant=Wong.getTypeMerchant();
        String merch=xml.getItem(result,"name");
        String scredit=xml.getItem(result,"credit");
        String sots=xml.getItem(result,"ots");

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(TransFragment.this.getContext(), R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.show_saldo);
        LinearLayout lyOts=bottomSheetDialog.findViewById(R.id.lyOts);

        TextView tvNamaMerchant=bottomSheetDialog.findViewById(R.id.tvNamaMerchant);
        TextView tvCredit=bottomSheetDialog.findViewById(R.id.tvCredit);
        TextView tvOts=bottomSheetDialog.findViewById(R.id.tvOts);
        tvNamaMerchant.setText(merch);
        tvCredit.setText(df.format(Double.parseDouble(scredit)));
        if(!typeMerchant.equals("1")||!typeMerchant.equals("3")){
            tvOts.setText(df.format(Double.parseDouble(sots)));
            lyOts.setVisibility(View.VISIBLE);
        }
        Button btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });

        bottomSheetDialog.show();
    }

}
