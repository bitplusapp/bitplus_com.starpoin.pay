package com.starpoin.pay;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.ReqPrintulangAdapter;
import com.starpoin.pay.model.ReqPrintItems;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.util.JsonIn;

import org.json.JSONObject;

import java.util.ArrayList;

public class ReprintResultActivity extends AbaseActivity {

    private ConstraintLayout rootLayout;

    private int produk;
    private String MTI;
    private String content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTitle("Cetak Ulang");

        setContentView(R.layout.activity_reprint_result);

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        String strt=this.getIntent().getStringExtra("produk");
        content=this.getIntent().getStringExtra("content");
        MTI=this.getIntent().getStringExtra("MTI");
        produk=Integer.parseInt(strt);
        buildList(content);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void buildList(String content){
        ArrayList<ReqPrintItems> list=new ReqPrintItems().listPrint(content);
        ReqPrintulangAdapter adapter=new ReqPrintulangAdapter(ReprintResultActivity.this,list);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);

        RecyclerView rvContent=this.findViewById(R.id.rvContent);
        rvContent.setLayoutManager(layoutManager);
        rvContent.setAdapter(adapter);

        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();

                ReqPrintItems item=list.get(position);
                reqData(item);
            }
        });
    }

    private void reqData(ReqPrintItems item){
        String params="report/rawprint/"+item.getPan()+"/"+item.getTrxid()+"/"+item.getNoid()+"/"+item.getTanggal();

        //final ProgressBar pbar=new PBar(this,rootLayout);
        OtherTask task = new OtherTask(this,ReprintResultActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                try {


                    JsonIn json = new JsonIn();
                    String rc = json.getString(content, "rc").trim();

                    if (rc.equals("000") || rc.equals("0000")) {
                        JSONObject data = new JSONObject(json.getString(content,"data"));
                        double amount = Double.parseDouble(data.has("amount") ? data.getString("amount") : data.getString("price"));
                        Intent intent = new Intent(ReprintResultActivity.this, ReprintActivity.class);
                        intent.putExtra("produk", produk);
                        intent.putExtra("result", content);
                        intent.putExtra("amount", amount);
                        intent.putExtra("pan", item.getPan());
                        startActivity(intent);
                    } else {
                        showMsg("Tidak ada data ditemukan");
                    }
                }catch(Exception ex){
                    Log.v("err_resp",ex.getMessage());
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }
}