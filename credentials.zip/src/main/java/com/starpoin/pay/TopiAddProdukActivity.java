package com.starpoin.pay;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class TopiAddProdukActivity extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;

    private Button btnTambah,btnScan;

    private EditText etKodeProduk,etNamaProduk,etSatuan,etHargaBeli,etHargaJual,etStok;
    private int REQUEST_CODE=1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topi_add_produk);

        rootLayout=findViewById(R.id.rootLayout);

        setTitle("Tambah Produk");

        etKodeProduk=(EditText) findViewById(R.id.etKodeProduk);
        etNamaProduk=(EditText) findViewById(R.id.etNamaProduk);
        etSatuan=(EditText) findViewById(R.id.etSatuan);
        etHargaBeli=(EditText) findViewById(R.id.etHargaBeli);
        etHargaJual=(EditText) findViewById(R.id.etHargaJual);
        etStok=(EditText) findViewById(R.id.etStok);

        btnScan=(Button) findViewById(R.id.btnScan);
        btnScan.setOnClickListener(this);

        btnTambah=(Button) findViewById(R.id.btnTambah);
        btnTambah.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnTambah:

                tambahProduk();
                break;
            case R.id.btnScan:
                Intent intent = new Intent(this, ScanBarcodeActivity.class);
                startActivityForResult(intent, REQUEST_CODE);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Check that it is the SecondActivity with an OK result
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {

                // Get String data from Intent
                String kode_barcode = data.getStringExtra("barcode");

                etKodeProduk.setText(kode_barcode);
            }
        }
    }

    private void tambahProduk(){
        String kodeProduk=etKodeProduk.getText().toString().trim();
        String namaProduk=etNamaProduk.getText().toString().trim().replaceAll("'","`");
        String satuan=etSatuan.getText().toString().trim();
        String hargaBeli=etHargaBeli.getText().toString().trim();
        String hargaJual=etHargaJual.getText().toString().trim();

        String stok=etStok.getText().toString().trim();

        if(kodeProduk.equals("")){
            showMsg("Kode Produk belum diisi");

        }else if(namaProduk.equals("")){
            showMsg("Nama Produk belum diisi");
        }else if(hargaBeli.equals("")){
            showMsg("Harga Beli/Modal belum diisi");
        }else if(hargaJual.equals("")){
            showMsg("Harga Jual belum diisi");
        }else if(stok.equals("")){
            showMsg("Stok belum diisi");
        }
        else{
            Map<String,Object> mapJson=new HashMap<>();
            mapJson.put("kode_produk",kodeProduk);
            mapJson.put("nama_produk",namaProduk);
            mapJson.put("satuan",satuan);
            mapJson.put("harga_beli",hargaBeli);
            mapJson.put("harga_jual",hargaJual);
            mapJson.put("stok",stok);

            JSONObject job=new JSONObject(mapJson);

            Map<String,Object> map=new HashMap<String, Object>();
            map.put("q","add_produk");
            map.put("idmerc", Wong.getIdmerch());
            map.put("iduser", Wong.getEmail());
            map.put("json",job.toString());
            String params="Topi"+new Params().buildParams(map);
            //new QueryTask().execute(params);
            TransTask task = new TransTask(TopiAddProdukActivity.this,this, new OnEventListener<String>() {
                @Override
                public void onSuccess(String content) {
                    malik.org.json.JSONObject job=new malik.org.json.JSONObject(content);

                    String rc=job.getString("rc");
                    if(rc.equals("0000")){
                        insertProduk();
                        reset();

                    }else{
                        String desc=job.getString("desc");
                        showMsg(desc);
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    showMsg(e.getMessage());
                }

            });
            task.execute(params);
        }

    }

    private void insertProduk(){
        String idmerc=Wong.getIdmerch();
        String kodeProduk=etKodeProduk.getText().toString().trim();
        String namaProduk=etNamaProduk.getText().toString().trim().replaceAll("'","`");
        String satuan=etSatuan.getText().toString().trim();
        String hargaBeli=etHargaBeli.getText().toString().trim();
        String hargaJual=etHargaJual.getText().toString().trim();

        String stok=etStok.getText().toString().trim();
        String time=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        DatabaseHelper dbHelper=new DatabaseHelper(TopiAddProdukActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            //String strSQL = "INSERT INTO topi_produk (id_merchant,kode_produk,nama_produk,satuan,harga_beli,harga_jual1,min_qty1,harga_jual2,min_qty2,harga_jual3,min_qty3,stok,lastupdate) VALUES('"+idmerc+"','"+kodeProduk+"','"+namaProduk+"','"+satuan+"','"+hargaBeli+"','"+hargaJual1+"','"+qty1+"','"+hargaJual2+"','"+qty2+"','"+hargaJual3+"','"+qty3+"','"+stok+"','"+time+"'  )  ";
            String strSQL = "INSERT INTO topi_produk (id_merchant,kode_produk,nama_produk,satuan,harga_beli,harga_jual,stok,lastupdate) VALUES('"+idmerc+"','"+kodeProduk+"','"+namaProduk+"','"+satuan+"','"+hargaBeli+"','"+hargaJual+"','"+stok+"','"+time+"'  )  ";

            db.execSQL(strSQL);
            //Log.i("insert db","Berhasil");
        }catch (Exception e){
            Log.d("error insert db",e.toString());
        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }

        }
    }

    public void reset(){
        etKodeProduk.setText("");
        etNamaProduk.setText("");
        etSatuan.setText("");
        etHargaBeli.setText("");
        etHargaJual.setText("");
        etStok.setText("");

        etKodeProduk.requestFocus();
    }
}