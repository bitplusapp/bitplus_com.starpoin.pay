package com.starpoin.pay.topi;

import java.util.ArrayList;

import malik.org.json.JSONArray;
import malik.org.json.JSONObject;

public class Laporan {

    public ArrayList<Produk> lapJual(JSONObject job){
        ArrayList<Produk> list=new ArrayList<>();
        JSONArray arr=job.getJSONArray("item");
        int size=arr.length();
        int totQty=0;
        int total=0;
        for(int i=0; i<size; i++){
            JSONObject js=arr.getJSONObject(i);

            String nama_produk=js.getString("nama_produk");
            String qty=js.getString("qty");
            String subtotal=js.getString("subtotal");



            Produk e=new Produk();
            e.setNama_produk(nama_produk);
            e.setQty(qty);
            e.setHarga_jual(subtotal);
            list.add(e);

            totQty+=Integer.parseInt(qty);
            total+=Integer.parseInt(subtotal);
        }
        return list;
    }

    public ArrayList<Produk> lapLaba(JSONObject job){
        ArrayList<Produk> list=new ArrayList<>();
        JSONArray arr=job.getJSONArray("item");
        int size=arr.length();
        int totLaba=0;
        for(int i=0; i<size; i++){
            JSONObject js=arr.getJSONObject(i);

            String nama_produk=js.getString("nama_produk");
            String qty=js.getString("qty");
            double laba=Double.parseDouble(qty);
            totLaba+=laba;


            Produk e=new Produk();
            e.setNama_produk(nama_produk);
            e.setQty(qty);
            list.add(e);


        }
        return list;
    }

    public Produk getTotal(JSONObject job){
        Produk e=new Produk();
        JSONArray arr=job.getJSONArray("item");
        int size=arr.length();
        int totQty=0;
        int total=0;
        for(int i=0; i<size; i++){
            JSONObject js=arr.getJSONObject(i);

            String nama_produk=js.getString("nama_produk");
            String qty=js.getString("qty");
            String subtotal=js.getString("subtotal");

            totQty+=Integer.parseInt(qty);
            total+=Integer.parseInt(subtotal);
        }
        e.setQty(String.valueOf(totQty));
        e.setStok(String.valueOf(total));//total
        return e;
    }

    public int getTotalLaba(JSONObject job){

        JSONArray arr=job.getJSONArray("item");
        int size=arr.length();
        int totLaba=0;
        for(int i=0; i<size; i++){
            JSONObject js=arr.getJSONObject(i);

            String nama_produk=js.getString("nama_produk");
            String qty=js.getString("qty");
            double laba=Double.parseDouble(qty);
            totLaba+=laba;


        }
        return totLaba;
    }
}
