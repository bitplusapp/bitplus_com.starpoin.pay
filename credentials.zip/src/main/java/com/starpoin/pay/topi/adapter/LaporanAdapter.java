package com.starpoin.pay.topi.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.starpoin.pay.R;
import com.starpoin.pay.topi.Produk;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class LaporanAdapter extends ArrayAdapter<Produk> {
    private Context context;
    //private ArrayList<Produk> list;
    private ArrayList<Produk> produkList;
    private ArrayList<Produk> originalList;
    private EditText etFilter;
    private ListFilter filter;
    private DecimalFormat df=new DecimalFormat("#,##0");

    public LaporanAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Produk> list,EditText etFilter) {
        super(context, resource, list);
        this.context=context;
        this.etFilter=etFilter;
        this.produkList = new ArrayList<Produk>();
        this.produkList.addAll(list);
        this.originalList = new ArrayList<Produk>();
        this.originalList.addAll(list);
    }

    private class ViewHolder {

        TextView produk;
        TextView qty;
        TextView subtotal;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder = null;
        if (convertView == null) {

            LayoutInflater vi=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = vi.inflate(R.layout.topi_laporan_adapter, null);

            holder = new ViewHolder();
            holder.produk = (TextView) convertView.findViewById(R.id.tvNamaProduk);
            holder.qty = (TextView) convertView.findViewById(R.id.tvQty);
            holder.subtotal = (TextView) convertView.findViewById(R.id.tvHarga);


            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Produk model = produkList.get(position);
        int iqty=Integer.parseInt(model.getQty());
        int ihrg=Integer.parseInt(model.getHarga_jual());//subtotal
        holder.produk.setText(model.getNama_produk());
        holder.qty.setText(df.format(iqty));
        holder.subtotal.setText(df.format(ihrg));


        return convertView;

    }

    @Override
    public Filter getFilter() {
        if (filter == null){
            filter  = new ListFilter();
        }
        return filter;
    }

    private class ListFilter extends Filter {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            constraint = constraint.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if(constraint != null && constraint.toString().length() > 0){
                ArrayList<Produk> filteredItems = new ArrayList<Produk>();

                for(int i = 0, l = originalList.size(); i < l; i++){
                    Produk model = originalList.get(i);
                    if(model.toString().toLowerCase().contains(constraint))
                        filteredItems.add(model);
                }
                result.count = filteredItems.size();
                result.values = filteredItems;
            }else{
                synchronized(this){
                    result.values = originalList;
                    result.count = originalList.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint,FilterResults results) {

            produkList = (ArrayList<Produk>)results.values;
            notifyDataSetChanged();
            clear();
            for(int i = 0, l = produkList.size(); i < l; i++)
                add(produkList.get(i));
            notifyDataSetInvalidated();
        }
    }
}
