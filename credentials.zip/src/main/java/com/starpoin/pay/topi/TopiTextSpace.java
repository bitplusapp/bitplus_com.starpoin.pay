package com.starpoin.pay.topi;

public class TopiTextSpace {

    public static String alignment(String item, String qty,String price,String sub) {
        int width = 42;
        String s = "";

        s += item;

        int x = 0;

        while(x<23 -item.length() - qty.length()){
            s+=" ";
            x++;
        }

        s+=qty;


        while(x < 31 - item.length() - price.length() - qty.length()) {
            s += " ";
            x++;
        }

        s += price;

        while(x < 42 - item.length() - price.length() - qty.length()-sub.length()) {
            s += " ";
            x++;
        }

        s += sub;



        return s;
    }

    public static String rataTengah(String text) {
        //int width = 42;
        String s = "";
        int x = 0;

        while(x < 21 - text.length() /2){
            s+=" ";
            x++;
        }
        s += text;

        return s;
    }
}
