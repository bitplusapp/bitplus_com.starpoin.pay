package com.starpoin.pay.topi.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.starpoin.pay.R;
import com.starpoin.pay.topi.Jual;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class JualAdapter extends ArrayAdapter<Jual> {
    private Context context;
    private ArrayList<Jual> list;
    private DecimalFormat df=new DecimalFormat("#,##0");

    public JualAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Jual> list) {
        super(context, resource, list);
        this.context=context;
        this.list= list;
    }

    private class ViewHolder {

        TextView tvProduk;
        TextView tvQty;
        TextView tvHarga;
        TextView tvSubTotal;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder = null;
        if (convertView == null) {

            //LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            LayoutInflater vi=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = vi.inflate(R.layout.topi_jual_adapter, null);

            holder = new ViewHolder();
            holder.tvProduk = (TextView) convertView.findViewById(R.id.tvProduk);
            holder.tvQty = (TextView) convertView.findViewById(R.id.tvQty);
            holder.tvHarga = (TextView) convertView.findViewById(R.id.tvHarga);
            holder.tvSubTotal = (TextView) convertView.findViewById(R.id.tvSubTotal);


            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Jual model = list.get(position);
        String id=model.getId();
        String nama_produk=model.getNama_produk();
        String qty=model.getQty();
        String hj=model.getHarga_jual();
        double dqty=Double.parseDouble(qty);
        double dhj=Double.parseDouble(hj);
        int isub=(int)dqty*(int)dhj;
        holder.tvProduk.setText(nama_produk);
        holder.tvQty.setText(qty);
        holder.tvHarga.setText(df.format(dhj));
        holder.tvSubTotal.setText(df.format(isub));


        return convertView;

    }
}
