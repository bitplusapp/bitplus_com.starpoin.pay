package com.starpoin.pay.topi;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.starpoin.pay.helper.DatabaseHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Beli {

    private String id,id_merchant,kode_produk,nama_produk,satuan,harga_beli,qty,lastupdate;

    public Beli() {
    }

    public Beli(String id, String kode_produk, String nama_produk, String satuan, String harga_beli,  String qty) {
        this.id = id;
        this.kode_produk = kode_produk;
        this.nama_produk = nama_produk;
        this.satuan = satuan;
        this.harga_beli = harga_beli;
        this.qty = qty;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId_merchant() {
        return id_merchant;
    }

    public void setId_merchant(String id_merchant) {
        this.id_merchant = id_merchant;
    }

    public String getKode_produk() {
        return kode_produk;
    }

    public void setKode_produk(String kode_produk) {
        this.kode_produk = kode_produk;
    }

    public String getNama_produk() {
        return nama_produk;
    }

    public void setNama_produk(String nama_produk) {
        this.nama_produk = nama_produk;
    }

    public String getSatuan() {
        return satuan;
    }

    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }

    public String getHarga_beli() {
        return harga_beli;
    }

    public void setHarga_beli(String harga_beli) {
        this.harga_beli = harga_beli;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getLastupdate() {
        return lastupdate;
    }

    public void setLastupdate(String lastupdate) {
        this.lastupdate = lastupdate;
    }

    public String addItemBeli(Context context, Beli jual){
        String msg=null;
        String time=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        id_merchant=jual.getId_merchant();
        kode_produk=jual.getKode_produk();
        nama_produk=jual.getNama_produk();
        satuan=jual.getSatuan();
        harga_beli=jual.getHarga_beli();
        qty=jual.getQty();

        DatabaseHelper dbHelper=null;
        SQLiteDatabase db=null;
        try{
            dbHelper=new DatabaseHelper(context);
            db=dbHelper.getWritableDatabase();


            String sql = "INSERT INTO topi_beli (id_merchant,kode_produk,nama_produk,satuan,harga_beli,qty,lastupdate) VALUES('"+id_merchant+"','"+kode_produk+"','"+nama_produk+"','"+satuan+"','"+harga_beli+"','"+qty+"','"+time+"'  )  ";

            db.execSQL(sql);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage().toString();
        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }

        return msg;
    }



    public String updateItem(Context context, Beli beli, String newqty){
        String msg=null;
        String sql="update topi_beli set qty='"+newqty+"' where id='"+beli.getId()+"' ";
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            db.execSQL(sql);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage();
        }finally {

            try{

                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return msg;
    }

    public String deleteItem(Context context,String rowid){
        String msg=null;
        String sql="delete from topi_beli where id='"+rowid+"' ";
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            db.execSQL(sql);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage();
        }finally {

            try{

                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return msg;
    }

    public String clearItem(Context context){
        String msg=null;
        String sql="delete from topi_beli ";
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            db.execSQL(sql);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage();
        }finally {

            try{

                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return msg;
    }

    public ArrayList<Beli> listBeli(Context context){
        ArrayList<Beli> list=new ArrayList<>();
        //String id,kode_produk,nama_produk,satuan,harga_beli,harga_jual,qty,laba_rugi,lastupdate;
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        Cursor cursor = null;
        try{
            //String[] args={};
            String sql="select id,kode_produk,nama_produk,satuan,harga_beli,qty FROM topi_beli";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,null);
            while (cursor.moveToNext()){
                id=cursor.getString(0);
                kode_produk=cursor.getString(1);
                nama_produk=cursor.getString(2);
                satuan=cursor.getString(3);
                harga_beli=cursor.getString(4);
                qty=cursor.getString(5);

                Beli jual=new Beli(id,kode_produk,nama_produk,satuan,harga_beli,qty);
                list.add(jual);
            }

        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {

            try{
                if(cursor!=null){
                    cursor.close();
                }

                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return list;
    }


}
