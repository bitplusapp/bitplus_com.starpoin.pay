package com.starpoin.pay.topi;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.util.Wong;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Jual {

    private String id,id_merchant,kode_produk,nama_produk,satuan,harga_beli,harga_jual,qty,laba_rugi,lastupdate;

    public Jual() {
    }

    public Jual(String id, String kode_produk, String nama_produk, String satuan, String harga_beli, String harga_jual, String qty, String laba_rugi) {
        this.id = id;
        this.kode_produk = kode_produk;
        this.nama_produk = nama_produk;
        this.satuan = satuan;
        this.harga_beli = harga_beli;
        this.harga_jual = harga_jual;
        this.qty = qty;
        this.laba_rugi = laba_rugi;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId_merchant() {
        return id_merchant;
    }

    public void setId_merchant(String id_merchant) {
        this.id_merchant = id_merchant;
    }

    public String getKode_produk() {
        return kode_produk;
    }

    public void setKode_produk(String kode_produk) {
        this.kode_produk = kode_produk;
    }

    public String getNama_produk() {
        return nama_produk;
    }

    public void setNama_produk(String nama_produk) {
        this.nama_produk = nama_produk;
    }

    public String getSatuan() {
        return satuan;
    }

    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }

    public String getHarga_beli() {
        return harga_beli;
    }

    public void setHarga_beli(String harga_beli) {
        this.harga_beli = harga_beli;
    }

    public String getHarga_jual() {
        return harga_jual;
    }

    public void setHarga_jual(String harga_jual) {
        this.harga_jual = harga_jual;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getLaba_rugi() {
        return laba_rugi;
    }

    public void setLaba_rugi(String laba_rugi) {
        this.laba_rugi = laba_rugi;
    }

    public String getLastupdate() {
        return lastupdate;
    }

    public void setLastupdate(String lastupdate) {
        this.lastupdate = lastupdate;
    }

    public String addItemJual(Context context,Jual jual){
        String msg=null;
        String time=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        id_merchant=jual.getId_merchant();
        kode_produk=jual.getKode_produk();
        nama_produk=jual.getNama_produk();
        satuan=jual.getSatuan();
        harga_beli=jual.getHarga_beli();
        harga_jual=jual.getHarga_jual();
        qty=jual.getQty();
        int iqty=Integer.parseInt(qty);
        int harga=Integer.parseInt(harga_jual);

        int qtyDb=qtyDb(context,kode_produk);

        DatabaseHelper dbHelper=null;
        SQLiteDatabase db=null;
        try{
            dbHelper=new DatabaseHelper(context);
            db=dbHelper.getWritableDatabase();


            String sql=null;
            if(qtyDb>0){
                //update
                int newqty=qtyDb+iqty;
                int laba_rugi=(harga - Integer.parseInt(harga_beli))*newqty;

                sql="UPDATE topi_jual SET qty='"+newqty+"',harga_jual='"+harga+"',laba_rugi='"+laba_rugi+"' WHERE kode_produk='"+kode_produk+"'";

            }else{
                //insert

                int laba_rugi=(harga - Integer.parseInt(harga_beli))*iqty;
                sql = "INSERT INTO topi_jual (id_merchant,kode_produk,nama_produk,satuan,harga_beli,harga_jual,qty,laba_rugi,lastupdate) VALUES('"+id_merchant+"','"+kode_produk+"','"+nama_produk+"','"+satuan+"','"+harga_beli+"','"+harga_jual+"','"+qty+"','"+laba_rugi+"','"+time+"')";

            }
            db.execSQL(sql);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage().toString();
        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }

        return msg;
    }

    private int qtyDb(Context context,String kdproduk){
        int  qty=0;
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        Cursor cursor = null;
        try{
            String[] args={};
            String sql="SELECT qty from  topi_jual WHERE kode_produk='"+kdproduk+"'";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,args);

            while(cursor.moveToNext()){
                qty=cursor.getInt(0);
            }
        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {

            try{
                if(cursor!=null){
                    cursor.close();
                }
                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return qty;
    }

    public String updateItem(Context context,Jual jual,String newqty){
        String msg=null;
        int harga_beli=Integer.parseInt(jual.getHarga_beli());
        int harga_jual=Integer.parseInt(jual.getHarga_jual());
        int qty=Integer.parseInt(newqty);
        int laba_rugi=(harga_jual - harga_beli)*qty;
        String sql="update topi_jual set qty='"+qty+"',harga_jual='"+harga_jual+"',laba_rugi='"+laba_rugi+"' where id='"+jual.getId()+"' ";
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            db.execSQL(sql);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage();
        }finally {

            try{

                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return msg;
    }

    public String deleteItem(Context context,String rowid){
        String msg=null;
        String sql="delete from topi_jual where id='"+rowid+"' ";
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            db.execSQL(sql);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage();
        }finally {

            try{

                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return msg;
    }

    public String clearItem(Context context){
        String msg=null;
        String sql="delete from topi_jual ";
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            db.execSQL(sql);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage();
        }finally {

            try{

                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return msg;
    }

    public ArrayList<Jual> listJual(Context context){
        ArrayList<Jual> list=new ArrayList<>();
        //String id,kode_produk,nama_produk,satuan,harga_beli,harga_jual,qty,laba_rugi,lastupdate;
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        Cursor cursor = null;
        try{
            //String[] args={};
            String sql="select id,kode_produk,nama_produk,satuan,harga_beli,harga_jual,qty,laba_rugi FROM topi_jual";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,null);
            while (cursor.moveToNext()){
                id=cursor.getString(0);
                kode_produk=cursor.getString(1);
                nama_produk=cursor.getString(2);
                satuan=cursor.getString(3);
                harga_beli=cursor.getString(4);
                harga_jual=cursor.getString(5);
                qty=cursor.getString(6);
                laba_rugi=cursor.getString(7);

                Jual jual=new Jual(id,kode_produk,nama_produk,satuan,harga_beli,harga_jual,qty,laba_rugi);
                list.add(jual);
            }

        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {

            try{
                if(cursor!=null){
                    cursor.close();
                }

                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return list;
    }

    public String buildStruke(Context context,String noNota,ArrayList<Jual> list,int uangTunai){
        String struke=null;
        String[] arr=noNota.split("-");
        String nota=arr[2];

        int total=0;
        DecimalFormat df=new DecimalFormat("#,##0");
        String namatoko=TopiTextSpace.rataTengah(Wong.getMerchant());

        StringBuilder sb=new StringBuilder();
        sb.append("\n");
        sb.append(namatoko);
        sb.append("\n");

        sb.append("==========================================");
        sb.append("\n");

        sb.append("Nota    : ").append(nota);
        sb.append("\n");
        sb.append("Tanggal : ").append(new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
        sb.append("\n");
        sb.append("==========================================");//42 char
        sb.append("\n");
        //ArrayList<Produk> list=new ArrayList<>();
        for(Jual e:list){
            int brgSize=e.getNama_produk().length();
            if(brgSize<20){
                String brg=e.getNama_produk();
                String hrg=e.getHarga_jual();
                String qty=e.getQty();
                int ihrg=Integer.parseInt(hrg);
                int iqty=Integer.parseInt(qty);
                int subtot=ihrg*iqty;
                total+=subtot;

                String s= TopiTextSpace.alignment(brg, df.format(iqty), df.format(ihrg), df.format(subtot));
                sb.append(s);
                sb.append("\n");
            }else{
                String brg=e.getNama_produk();
                String brg1=brg.substring(0,19);
                String brg2=brg.substring(19,brgSize);

                String hrg=e.getHarga_jual();
                String qty=e.getQty();
                int ihrg=Integer.parseInt(hrg);
                int iqty=Integer.parseInt(qty);
                int subtot=ihrg*iqty;
                total+=subtot;

                String s= TopiTextSpace.alignment(brg1, df.format(iqty), df.format(ihrg), df.format(subtot));
                sb.append(s);
                sb.append("\n");

                String s2= TopiTextSpace.alignment(brg2, "", "", "");
                sb.append(s2);
                sb.append("\n");
            }

        }
        sb.append("------------------------------------------");
        sb.append("\n");


        int ikembali=uangTunai-total;
        String tot=TopiTextSpace.alignment("Total", "","",df.format(total));
        String cash=TopiTextSpace.alignment("Cash", "","",df.format(uangTunai));
        String kembali=TopiTextSpace.alignment("Kembali", "","",df.format(ikembali));
        sb.append(tot);
        sb.append("\n");
        sb.append(cash);
        sb.append("\n");
        sb.append(kembali);
        sb.append("\n");

        sb.append("------------------------------------------");
        sb.append("\n");
        String tk=TopiTextSpace.rataTengah("Terimakasih");
        sb.append(tk);
        sb.append("\n");
        sb.append("\n");


        struke=sb.toString();

        String tgl=new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        updateProfil(context,tgl,nota,struke);

        return struke;
    }

    public void updateProfil(Context context,String tglnota,String nomornota,String struk){
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            String strSQL = "UPDATE topi_profil set tgl_nota='"+tglnota+"',nomor_nota='"+nomornota+"',cetak_ulang='"+struk+"' ";
            db.execSQL(strSQL);
        }catch (Exception e){

        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){

            }

        }
    }

    public String getLastStruk(Context context){
        String struk=null;
        DatabaseHelper helper=null;
        Cursor cursor=null;
        try {
            helper=new DatabaseHelper(context);
            String[] args={};
            String sql="SELECT cetak_ulang from topi_profil";
            cursor = helper.getReadableDatabase().rawQuery(sql,null);
            while (cursor.moveToNext()){
                struk=cursor.getString(0);
            }
        }catch (Exception e){
            struk="0";
        }finally {
            try {
                if(cursor != null){
                    cursor.close();
                }
                if(helper != null){
                    helper.close();
                }
            }catch (Exception ex){

            }

        }
        return struk;
    }
}
