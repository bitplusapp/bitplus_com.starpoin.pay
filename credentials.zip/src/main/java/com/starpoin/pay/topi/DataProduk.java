package com.starpoin.pay.topi;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.starpoin.pay.helper.DatabaseHelper;

import java.util.ArrayList;

public class DataProduk {

    public Produk getData(Context context,String nama_produk){
        Produk p=new Produk();
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        Cursor cursor = null;
        try{
            //String[] args={};
            String sql="select kode_produk,nama_produk,satuan,harga_beli,harga_jual,stok FROM topi_produk WHERE nama_produk='"+nama_produk+"' ";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,null);
            if (cursor != null && cursor.getCount() > 0){
                cursor.moveToFirst();

                String kode_produk=cursor.getString(0);
                String nama=cursor.getString(1);
                String satuan=cursor.getString(2);
                String harga_beli=cursor.getString(3);
                String harga_jual=cursor.getString(4);
                String stok=cursor.getString(5);

                p.setKode_produk(kode_produk);
                p.setNama_produk(nama);
                p.setSatuan(satuan);
                p.setHarga_beli(harga_beli);
                p.setHarga_jual(harga_jual);
                p.setStok(stok);

            }
        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {

            try{
                if(cursor!=null){
                    cursor.close();
                }

                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return p;
    }

    public Produk getDataByKode(Context context,String kode_produk){
        Produk p=null;
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        Cursor cursor = null;
        try{
            //String[] args={};
            String sql="select kode_produk,nama_produk,satuan,harga_beli,harga_jual,stok FROM topi_produk WHERE kode_produk='"+kode_produk+"' ";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,null);
            if (cursor != null && cursor.getCount() > 0){
                cursor.moveToFirst();


                String nama=cursor.getString(1);
                String satuan=cursor.getString(2);
                String harga_beli=cursor.getString(3);
                String harga_jual=cursor.getString(4);
                String stok=cursor.getString(5);

                p=new Produk();
                p.setKode_produk(kode_produk);
                p.setNama_produk(nama);
                p.setSatuan(satuan);
                p.setHarga_beli(harga_beli);
                p.setHarga_jual(harga_jual);
                p.setStok(stok);

            }
        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {

            try{
                if(cursor!=null){
                    cursor.close();
                }

                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return p;
    }

    public ArrayList<Produk> getListProduk(Context context){
        ArrayList<Produk> al=new ArrayList<>();
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        Cursor cursor = null;
        try{
            //String[] args={};
            String sql="select kode_produk,nama_produk,satuan,harga_beli,harga_jual,stok FROM topi_produk";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,null);
            while (cursor.moveToNext()){
                String kode_produk=cursor.getString(0);
                String nama=cursor.getString(1);
                String satuan=cursor.getString(2);
                String harga_beli=cursor.getString(3);
                String harga_jual=cursor.getString(4);
                String stok=cursor.getString(5);
                //Log.i("nama_produk",nama);
                Produk p=new Produk();
                p.setKode_produk(kode_produk);
                p.setNama_produk(nama);
                p.setSatuan(satuan);
                p.setHarga_beli(harga_beli);
                p.setHarga_jual(harga_jual);
                p.setStok(stok);
                al.add(p);
            }

        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {

            try{
                if(cursor!=null){
                    cursor.close();
                }

                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return al;
    }

    public String updateStok(Context context,ArrayList<Produk> list){
        String b=null;
        DataProduk dp=new DataProduk();
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            for(Produk e:list){
                String kode_produk=e.getKode_produk();
                int old_stok=Integer.parseInt(dp.getDataByKode(context,kode_produk).getStok());
                int newstok=old_stok+Integer.parseInt(e.getQty());
                String strSQL = "UPDATE topi_produk set stok='"+newstok+"' WHERE kode_produk='"+kode_produk+"' ";
                db.execSQL(strSQL);
            }
            b="0000";
        }catch (Exception e){
            b=e.getMessage();
        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){

            }

        }
        return b;
    }

    public int countProduk(Context context){
        int  qty=0;
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        Cursor cursor = null;
        try{
            String[] args={};
            String sql="SELECT COUNT(kode_produk) FROM topi_produk";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,args);

            while(cursor.moveToNext()){
                qty=cursor.getInt(0);
            }
        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {

            try{
                if(cursor!=null){
                    cursor.close();
                }
                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return qty;
    }

    public void updateLocalStok(Context context,ArrayList<Produk> list){
        ArrayList<Produk> tmpList=new ArrayList<>();
        DataProduk dp=new DataProduk();
        for(Produk e:list){
            String kode=e.getKode_produk();
            int qty=Integer.parseInt(e.getQty());
            int old_stok=Integer.parseInt(dp.getDataByKode(context,kode).getStok());
            int newstok=old_stok-qty;
            Produk tmpProd=new Produk();
            tmpProd.setKode_produk(kode);
            tmpProd.setStok(String.valueOf(newstok));
            tmpList.add(tmpProd);
        }
        dp.updateStok(context,tmpList);
    }


}
