package com.starpoin.pay.topi;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.starpoin.pay.helper.DatabaseHelper;

import java.util.ArrayList;

import malik.org.json.JSONArray;
import malik.org.json.JSONObject;

public class Produk {
    private String id,kode_produk,nama_produk,satuan,harga_beli,harga_jual,stok;
    private String qty,laba_rugi;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getKode_produk() {
        return kode_produk;
    }

    public void setKode_produk(String kode_produk) {
        this.kode_produk = kode_produk;
    }

    public String getNama_produk() {
        return nama_produk;
    }

    public void setNama_produk(String nama_produk) {
        this.nama_produk = nama_produk;
    }

    public String getSatuan() {
        return satuan;
    }

    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }

    public String getHarga_beli() {
        return harga_beli;
    }

    public void setHarga_beli(String harga_beli) {
        this.harga_beli = harga_beli;
    }

    public String getStok() {
        return stok;
    }

    public void setStok(String stok) {
        this.stok = stok;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getHarga_jual() {
        return harga_jual;
    }

    public void setHarga_jual(String harga_jual) {
        this.harga_jual = harga_jual;
    }

    public String getLaba_rugi() {
        return laba_rugi;
    }

    public void setLaba_rugi(String laba_rugi) {
        this.laba_rugi = laba_rugi;
    }

    @Override
    public String toString() {
        return  nama_produk;
    }

    public ArrayList<Produk> listProduk(JSONObject job){
        ArrayList<Produk> list=new ArrayList<>();
        JSONArray arr=job.getJSONArray("item");
        int size=arr.length();
        for(int i=0; i<size; i++){
            JSONObject item=arr.getJSONObject(i);
            id=item.getString("id");
            kode_produk=item.getString("kode_produk");
            nama_produk=item.getString("nama_produk");
            satuan=item.getString("satuan");
            harga_beli=item.getString("harga_beli");
            harga_jual=item.getString("harga_jual");
            stok=item.getString("stok");

            Produk prod=new Produk();
            prod.setId(id);
            prod.setKode_produk(kode_produk);
            prod.setNama_produk(nama_produk);
            prod.setSatuan(satuan);
            prod.setHarga_beli(harga_beli);
            prod.setHarga_jual(harga_jual);
            prod.setStok(stok);
            list.add(prod);
        }
        return list;
    }



    public String updateProduk(Context context,Produk prod){
        String msg=null;
        kode_produk=prod.getKode_produk();
        nama_produk=prod.getNama_produk();
        satuan=prod.getSatuan();
        harga_beli=prod.getHarga_beli();
        harga_jual=prod.getHarga_jual();
        stok=prod.getStok();

        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            String strSQL = "update topi_produk set nama_produk='"+nama_produk+"'," +
                    "satuan='"+satuan+"',harga_beli='"+harga_beli+"'," +
                    "harga_jual='"+harga_jual+"',stok='"+stok+"' where kode_produk='"+kode_produk+"' ";
            db.execSQL(strSQL);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage();
        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }

        }
        return msg;
    }

    public String hapusProduk(Context context,String kode_produk){
        String msg=null;
        DatabaseHelper dbHelper=new DatabaseHelper(context);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            String strSQL = "delete from topi_produk where kode_produk='"+kode_produk+"' ";
            db.execSQL(strSQL);
            msg="00";
        }catch (Exception e){
            msg=e.getMessage();
        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }

        }
        return msg;
    }
}
