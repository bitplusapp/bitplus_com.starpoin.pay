package com.starpoin.pay.topi;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.starpoin.pay.helper.PrinterProfil;
import com.starpoin.pay.util.ImgDecode;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.Set;

public class TopiPrintLib {

    private Context context;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;
    private BluetoothDevice bluetoothDevice;
    private OutputStream outputStream;
    private InputStream inputStream;

    private byte[] readBuffer;
    private int readBufferPosition;

    private String resp="0";
    private PrinterProfil pp;
    private String printerName;
    private int prinLogo;
    private byte[] logo;

    public TopiPrintLib(Context context){
        this.context=context;
        pp=new PrinterProfil().getPrinterProfil(context);
        printerName=pp.getPrinter();
        prinLogo=pp.getLogo_view();
        logo=pp.getLogo();
    }

    public String print(String text){

        IntentPrint(text);

        //return "1";
        return resp;
    }



    public void IntentPrint(String txtvalue){
        byte[] buffer = txtvalue.getBytes();
        InitPrinter();

        byte[] arrayOfByte1 = { 27, 33, 0 };
        byte[] format = { 27, 33, 0 };
            /*
            format[2] = ((byte)(0x8 | arrayOfByte1[2]));//bold
            format[2] = ((byte)(0x10 | arrayOfByte1[2]));//height
            format[2] = ((byte) (0x20 | arrayOfByte1[2]));//width
            format[2] = ((byte)(0x80 | arrayOfByte1[2]));//underline
            */
        format[2] = ((byte)(0x1 | arrayOfByte1[2]));//small


        String br=System.getProperty("line.separator");
        ByteArrayInputStream imageStream=null;
        try{
            if(prinLogo==1){
                imageStream = new ByteArrayInputStream(logo);
                Bitmap theImage= BitmapFactory.decodeStream(imageStream);
                byte[] command = ImgDecode.decodeBitmap(theImage);


                outputStream.write(command);
                outputStream.write(br.getBytes());
                outputStream.write(br.getBytes());
            }
            outputStream.write(format);
            outputStream.write(buffer,0,buffer.length);
            outputStream.write(br.getBytes());
            outputStream.flush();

            try{
                Thread.sleep(400);
            }catch (Exception e){

            }
            outputStream.close();
            inputStream.close();
            socket.close();
            imageStream.close();
            resp="1";
        }catch(Exception ex){
            resp="Printer tidak dapat dihubungi";
            //value+=ex.toString()+ "\n" +"Excep IntentPrint \n";
            //Toast.makeText(context, value, Toast.LENGTH_LONG).show();
        }
    }


    public void InitPrinter(){
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        try{


            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
            //String printerName="Qsprinter";
            //String printerName=userPrinter();
            if(pairedDevices.size() > 0){

                for(BluetoothDevice device : pairedDevices){
                    //Log.i("dev name: ",device.getName());

                    if(device.getName().equals(printerName)){
                        bluetoothDevice = device;
                        break;
                    }
                }

                Method m = bluetoothDevice.getClass().getMethod("createRfcommSocket", new Class[]{int.class});
                socket = (BluetoothSocket) m.invoke(bluetoothDevice, 1);
                bluetoothAdapter.cancelDiscovery();
                socket.connect();
                outputStream = socket.getOutputStream();
                inputStream = socket.getInputStream();
                beginListenForData();
            }/*else{


                return;
            }*/
        }catch(Exception ex){
            resp="Printer tidak dapat dihubungi";
            //value+=ex.toString()+ "\n" +" InitPrinter \n";
            //Toast.makeText(context, value, Toast.LENGTH_LONG).show();
        }
    }
    void beginListenForData() {
        try {


            // this is the ASCII code for a newline character
            final byte delimiter = 10;


            readBufferPosition = 0;
            readBuffer = new byte[1024];

            int bytesAvailable = inputStream.available();

            if (bytesAvailable > 0) {

                byte[] packetBytes = new byte[bytesAvailable];
                inputStream.read(packetBytes);

                for (int i = 0; i < bytesAvailable; i++) {

                    byte b = packetBytes[i];
                    if (b == delimiter) {

                        byte[] encodedBytes = new byte[readBufferPosition];
                        System.arraycopy(
                                readBuffer, 0,
                                encodedBytes, 0,
                                encodedBytes.length
                        );

                        // specify US-ASCII encoding
                        final String data = new String(encodedBytes, "US-ASCII");
                        readBufferPosition = 0;



                    } else {
                        readBuffer[readBufferPosition++] = b;
                    }
                }
            }

        } catch (Exception e) {
            resp="Printer tidak dapat dihubungi";
        }
    }


}
