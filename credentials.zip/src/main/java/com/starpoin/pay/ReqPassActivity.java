package com.starpoin.pay;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.Profil;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.RegistrationTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Wong;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ReqPassActivity extends AbaseActivity implements View.OnClickListener {

    private RelativeLayout rootLayout;
    private EditText req_email;
    private RadioGroup radio_group;
    private Button btnKirim;
    private String typeVer="WhatsApp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_req_pass);

        if(getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        setTitle("Reset Password");
        rootLayout=findViewById(R.id.rootLayout);

        req_email=(EditText) findViewById(R.id.req_email);
        radio_group=(RadioGroup) findViewById(R.id.radio_group);
        radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) group.findViewById(checkedId);
                if (null != rb && checkedId > -1) {

                    typeVer=rb.getText().toString();
                    //Log.i("info ver",typeVer);
                    //Toast.makeText(FormRegistrasi.this, typeVer, Toast.LENGTH_SHORT).show();
                }

            }
        });

        String User_EmailId = userDB();
        req_email.setText(User_EmailId);

        btnKirim=findViewById(R.id.btnKirim);
        btnKirim.setOnClickListener(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnKirim:
                reqPassword();
                break;
        }
    }

    private void reqPassword(){
        String email=req_email.getText().toString().trim();
        Wong.setEmail(email);

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("email",email);
        //map.put("phoneNumber",Wong.getHp());
        map.put("otpVia",typeVer);
        String params= new JSONObject(map).toString();
        RegistrationTask task = new RegistrationTask(getApplicationContext(), this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")){
                    Intent i = new Intent(ReqPassActivity.this, ResetPasswordActivity.class);
                    startActivity(i);
                    finish();
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });

        task.execute("registration/user/forgotpasswd",params);
    }

    private String userDB(){
        String s=null;
        DatabaseHelper dbHelper=new DatabaseHelper(ReqPassActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        Cursor cursor = null;
        try{
            String[] args={};
            String sql="select "+ Profil.PROFIL_USERID+" ,"+Profil.PROFIL_PRINTER+","+Profil.PROFIL_PRINTER_UUID+" from "+Profil.PROFIL_TABLE+" ";
            cursor = dbHelper.getReadableDatabase().rawQuery(sql,args);
            if (cursor != null && cursor.getCount() > 0){
                cursor.moveToFirst();
                s=cursor.getString(0);
                String printer=cursor.getString(1);
                String uuid=cursor.getString(2);
                if(!printer.equals("0")){
                    Wong.setPrinterName(printer);
                }
                if(!uuid.equals("0")){
                    Wong.setPrinterUUID(uuid);
                }

                //Log.i("print dev",printer);
                //Log.i("print uuid",uuid);
            }
        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {

            try{
                if(cursor!=null){
                    cursor.close();
                }
                if(db != null){
                    db.close();
                }
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }
        }
        return s;
    }


}