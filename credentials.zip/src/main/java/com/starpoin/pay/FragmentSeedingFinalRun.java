package com.starpoin.pay;

import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.starpoin.pay.adapter.EventAdapterResult;
import com.starpoin.pay.adapter.ListViewAdapter;
import com.starpoin.pay.helper.LoadingHelper;
import com.starpoin.pay.model.CustomRaceData;
import com.starpoin.pay.model.ListViewModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentSeedingFinalRun#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentSeedingFinalRun extends Fragment {

    private FirebaseAuth mAuth;
    private DatabaseReference databaseRef;
    private ValueEventListener valueEventListener;
    private ListViewModel opsiPilihEvent;
    private ListViewModel opsiPilihHasil;
    private ListViewModel opsiPilihKelas;
    private DatabaseReference racesRef;
    private Button opsiEvent, opsiHasil, opsiKelas;
    private RecyclerView rvHasil;
    private FloatingActionButton floatingactionbutton;

    private ArrayList<ListViewModel> event = null;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private LoadingHelper loading;

    public FragmentSeedingFinalRun() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentKualifikasiRace.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentSeedingFinalRun newInstance(String param1, String param2) {
        FragmentSeedingFinalRun fragment = new FragmentSeedingFinalRun();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        FirebaseApp app = null;

        try{
            app = FirebaseApp.getInstance("secondary");
        }catch (Exception e) {
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApplicationId("1:741341997351:android:2cf9648693f49615032102") // Required for Analytics.
                    .setApiKey("AIzaSyCZTsboUVB1p7mDSd5HeGz4UqZUZygl9io") // Required for Auth.
                    .setDatabaseUrl("https://jtmtimingsystem-dab4a-default-rtdb.firebaseio.com") // Required for RTDB.
                    .build();

            // Inisialisasi FirebaseApp di sini
            FirebaseApp.initializeApp(requireContext() /* Context */, options, "secondary");
            app = FirebaseApp.getInstance("secondary");
        }

        // Inisialisasi DatabaseReference
        FirebaseDatabase database = FirebaseDatabase.getInstance(app);
        databaseRef = database.getReference();
    }

    @Override
    public void onStart() {
        super.onStart();
        // Start listening for data changes
        if (valueEventListener != null) {
            databaseRef.removeEventListener(valueEventListener);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Hapus listener ketika Fragment dihancurkan
        if (valueEventListener != null) {
            databaseRef.removeEventListener(valueEventListener);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        // Stop listening for data changes
        if (valueEventListener != null) {
            databaseRef.removeEventListener(valueEventListener);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_kualifikasi_race, container, false);

        Context context = requireContext();
        loading = new LoadingHelper(FragmentSeedingFinalRun.this.getActivity());
        loading.showLoadingOverlay();

        getAllInfoEvent();

        rvHasil = rootView.findViewById(R.id.rvDenom);

        opsiEvent = rootView.findViewById(R.id.opsiEvent);
        opsiEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(event == null) {
                    Toast.makeText(context, "Gagal Mendapatkan Data Event!", Toast.LENGTH_SHORT).show();
                }else{
                    showBottomSheetDialogEvent();
                }
            }
        });

        opsiHasil = rootView.findViewById(R.id.opsiHasil);
        opsiHasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(opsiPilihEvent == null) {
                    Toast.makeText(context, "Pilih Event Terlebih Dahulu", Toast.LENGTH_SHORT).show();
                }else{
                    showBottomSheetDialogFilterHasil();
                }
            }
        });

        opsiKelas = rootView.findViewById(R.id.opsiKelas);
        opsiKelas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(opsiPilihHasil == null) {
                    Toast.makeText(context, "Pilih Hasil Terlebih Dahulu", Toast.LENGTH_SHORT).show();
                }else{
                    showBottomSheetDialogKelasHobby();
                }
            }
        });

        floatingactionbutton = rootView.findViewById(R.id.floatingactionbutton);
        floatingactionbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(opsiPilihHasil != null && opsiPilihEvent != null && opsiPilihKelas != null) {
                    filterQuery(opsiPilihKelas.getId(), opsiPilihHasil.getId());
                }else{
                    Toast.makeText(context, "Lengkapi filter terlebih dahulu", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return rootView;
    }

    private void getAllInfoEvent() {
        // Inisialisasi DatabaseReference
        event = new ArrayList<>();
        DatabaseReference racesRef = databaseRef.child("races");

        valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot raceSnapshot : dataSnapshot.getChildren()) {
                    if (raceSnapshot.child("nama_race").exists()) {
                        String idRace = raceSnapshot.getKey();
                        String nameRace = raceSnapshot.child("nama_race").getValue(String.class);
                        // Retrieve and process the kelas data
                        DataSnapshot kelasSnapshot = raceSnapshot.child("kelas");
                        ArrayList<ListViewModel.childListViewModel> child = new ArrayList<>();
                        for (DataSnapshot kelasChildSnapshot : kelasSnapshot.getChildren()) {
                            String kelasId = kelasChildSnapshot.getKey();
                            String kelasName = kelasChildSnapshot.getValue(String.class);
                            child.add(new ListViewModel.childListViewModel(kelasId, kelasName));
                        }
                        event.add(new ListViewModel(idRace, nameRace, child));
                    }
                }
                loading.hideLoadingOverlay();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle database error
                System.out.println("ERROR "+databaseError);
            };
        };

        racesRef.addValueEventListener(valueEventListener);
        loading.hideLoadingOverlay();
    }
    private void filterQuery(String kelas, String hasil) {
        loading.showLoadingOverlay();
        racesRef = databaseRef.child("event_races/"+opsiPilihEvent.getId()+"/"+kelas);

        valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<CustomRaceData> raceDataList = new ArrayList<>();

                boolean ready = false;
                if(dataSnapshot.child(hasil + "Hasil").exists()) {
                    ready = dataSnapshot.child(hasil + "Hasil").getValue(Boolean.class);
                }

                if(ready) {
                    for (DataSnapshot raceSnapshot : dataSnapshot.getChildren()) {

                        if(raceSnapshot.child(hasil + "Hasil").exists()) {
                            ready = raceSnapshot.child(hasil + "Hasil").getValue(Boolean.class);
                        }

                        if(!raceSnapshot.getKey().equals("finalHasil") && !raceSnapshot.getKey().equals("seedingHasil")) {
                            if(ready) {
                                if (raceSnapshot.child(hasil+"/status").getValue(String.class).equalsIgnoreCase("finish")) {
                                    String nama = raceSnapshot.child("nama").getValue(String.class);
                                    String noRace = raceSnapshot.child("no_race").getValue(String.class);
                                    String tim = raceSnapshot.child("tim").getValue(String.class);

                                    long startTime = raceSnapshot.child(hasil + "/start_time").getValue(Long.class);
                                    long finishTime = raceSnapshot.child(hasil + "/finish_time").getValue(Long.class);

                                    // Menghitung selisih waktu
                                    long timeDifference = finishTime - startTime;
                                    raceDataList.add(new CustomRaceData(noRace, nama.toUpperCase(), tim.toUpperCase(), timeDifference));
                                }
                            }
                        }
                    }

                    // Mengurutkan raceDataList berdasarkan selisih waktu tercepat
                    if(raceDataList.size() > 0) {
                        Collections.sort(raceDataList, new Comparator<CustomRaceData>() {
                            @Override
                            public int compare(CustomRaceData raceData1, CustomRaceData raceData2) {
                                return Long.compare(raceData1.getTimeDifference(), raceData2.getTimeDifference());
                            }
                        });

                        rvHasil.removeAllViews();
                        EventAdapterResult adapter=new EventAdapterResult(requireContext(), raceDataList);
                        GridLayoutManager layoutManager=new GridLayoutManager(requireContext(),1);

                        rvHasil.setLayoutManager(layoutManager);
                        rvHasil.setAdapter(adapter);
                        loading.hideLoadingOverlay();
                    }else{
                        loading.hideLoadingOverlay();
                        rvHasil.removeAllViews();
                        rvHasil.setAdapter(null);
                        Toast.makeText(requireContext(), "Tidak ada data yang ditampilkan", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    loading.hideLoadingOverlay();
                    rvHasil.removeAllViews();
                    rvHasil.setAdapter(null);
                    Toast.makeText(requireContext(), "Tidak ada data yang ditampilkan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle database error
                System.out.println("ERROR "+databaseError.getMessage());
                loading.hideLoadingOverlay();
            }
        };

        racesRef.addValueEventListener(valueEventListener);
    }

    private void showBottomSheetDialogEvent() {
        final BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.bottom_sheet_dialog_product);

        final ListView lv = dialog.findViewById(R.id.lvProduct);
        final TextView text = dialog.findViewById(R.id.tvTitle);
        text.setText("Pilih Event Race");
        text.setVisibility(View.VISIBLE);
        lv.setAdapter(new ListViewAdapter(FragmentSeedingFinalRun.this.getActivity(), event));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                opsiPilihEvent = event.get(position);
                opsiEvent.setText(opsiPilihEvent.getValue());
                dialog.dismiss();
            }
        });
        // Get the height of the screen
        DisplayMetrics displayMetrics = new DisplayMetrics();
        requireActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenHeight = displayMetrics.heightPixels;
        dialog.getBehavior().setPeekHeight(screenHeight);
        dialog.show();
    }

    private void showBottomSheetDialogKelasHobby() {
        ArrayList<ListViewModel.childListViewModel> dataKelas = opsiPilihEvent.getChildListViewModel();
        ArrayList<ListViewModel> kelas = new ArrayList<>();
        for (int i = 0; i < dataKelas.size(); i++) {
            kelas.add(new ListViewModel(dataKelas.get(i).getId_kelas(), dataKelas.get(i).getNama_kelas()));
        }
        final BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.bottom_sheet_dialog_product);

        final ListView lv = dialog.findViewById(R.id.lvProduct);
        final TextView text = dialog.findViewById(R.id.tvTitle);
        text.setText("Pilih Kelas Race");
        text.setVisibility(View.VISIBLE);
        lv.setAdapter(new ListViewAdapter(FragmentSeedingFinalRun.this.getActivity(), kelas));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                opsiPilihKelas = kelas.get(position);
                if(opsiPilihHasil != null && opsiPilihEvent != null) {
                    filterQuery(opsiPilihKelas.getId(), opsiPilihHasil.getId());
                }
                opsiKelas.setText(opsiPilihKelas.getValue());
                dialog.dismiss();
            }
        });
        // Get the height of the screen
        DisplayMetrics displayMetrics = new DisplayMetrics();
        requireActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenHeight = displayMetrics.heightPixels;
        dialog.getBehavior().setPeekHeight(screenHeight);
        dialog.show();
    }

    private void showBottomSheetDialogFilterHasil() {
        ArrayList<ListViewModel> kelas = new ListViewModel().autoGenerateFilterHasil();

        final BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.bottom_sheet_dialog_product);

        final ListView lv = dialog.findViewById(R.id.lvProduct);
        final TextView text = dialog.findViewById(R.id.tvTitle);
        text.setText("Pilih Hasil Race");
        text.setVisibility(View.VISIBLE);
        lv.setAdapter(new ListViewAdapter(FragmentSeedingFinalRun.this.getActivity(), kelas));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                opsiPilihHasil = kelas.get(position);
                if(opsiPilihKelas != null && opsiPilihEvent != null) {
                    filterQuery(opsiPilihKelas.getId(), opsiPilihHasil.getId());
                }
                opsiHasil.setText(opsiPilihHasil.getValue());
                dialog.dismiss();
                //Toast.makeText(requireContext(), data.getId(), Toast.LENGTH_SHORT).show();
            }
        });
        // Get the height of the screen
        DisplayMetrics displayMetrics = new DisplayMetrics();
        requireActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenHeight = displayMetrics.heightPixels;
        dialog.getBehavior().setPeekHeight(screenHeight);
        dialog.show();
    }

}