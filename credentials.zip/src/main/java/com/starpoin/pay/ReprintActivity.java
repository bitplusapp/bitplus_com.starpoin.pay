package com.starpoin.pay;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.starpoin.pay.adapter.NewResultAdapter;
import com.starpoin.pay.model.Bpjs;
import com.starpoin.pay.model.InternetTvCable;
import com.starpoin.pay.model.NewResultItem;
import com.starpoin.pay.model.Nontaglis;
import com.starpoin.pay.model.PascaBayar;
import com.starpoin.pay.model.Pbb;
import com.starpoin.pay.model.Pdam;
import com.starpoin.pay.model.Postpaid;
import com.starpoin.pay.model.Prepaid;
import com.starpoin.pay.model.Pulsa;
import com.starpoin.pay.model.Response;
import com.starpoin.pay.model.Telkom;
import com.starpoin.pay.task.PBarLinear;
import com.starpoin.pay.util.Produk;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ReprintActivity extends AppCompatActivity implements View.OnClickListener {

    private String result;
    private int produk;
    private double amount;
    private String pan;
    private String admin;
    private String time;
    private ScrollView scrollView;

    private RelativeLayout rootLayout;
    private LinearLayout actionBtn,token_info,layoutMessage,layout_header,layoutFooter;
    private ImageButton btnBack;
    private Button btnCetak;
    private TextView tvAmount;
    private ImageView header;
    private RecyclerView rvResult;

    private TextView adminbank, timestamp, ref_id, rptag, title, token, txtIdmerchant,txtInfo;

    private final Response response=new Response();
    private String struk=null;
    private JSONObject respObject = new JSONObject();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_reprint_new);

        setTitle("Cetak Ulang");

        try {
            produk=response.getExtraInt(this,"produk");
            result=response.getExtraString(this,"result");
            amount=response.getExtraDouble(this,"amount");
            pan=response.getExtraString(this,"pan");

            respObject = new JSONObject(result);
            JSONObject data=respObject.getJSONObject("data");

            txtIdmerchant = (TextView) findViewById(R.id.txtIdmerchant);
            txtIdmerchant.setText(data.getString("merchant"));

            tvAmount=(TextView) findViewById(R.id.tvAmount);
            tvAmount.setText("Rp."+new DecimalFormat("#,##0").format(amount));

            ref_id=(TextView) findViewById(R.id.ref_id);
            ref_id.setText("CU-"+data.getString("ref_id"));

            admin = respObject.getJSONObject("data").has("admin") ? respObject.getJSONObject("data").getString("admin") : "0";
            adminbank=(TextView) findViewById(R.id.admin);
            adminbank.setText("Rp."+new DecimalFormat("#,##0").format(Double.parseDouble(admin)));

            timestamp=(TextView) findViewById(R.id.time);

            title = (TextView) findViewById(R.id.title);
            title.setText("Transaksi Sukses");

            time = respObject.getJSONObject("data").getString("time");
            timestamp.setText(timestampFormattedWIB(time));

            rptag=(TextView) findViewById(R.id.nominal);
            Double Tagihan = amount - Double.parseDouble(admin);
            rptag.setText("Rp."+new DecimalFormat("#,##0").format(Tagihan));

            actionBtn = (LinearLayout) findViewById(R.id.actionBtn);
            header = (ImageView) findViewById(R.id.header);
            token_info = (LinearLayout) findViewById(R.id.token_info);
            token = (TextView) findViewById(R.id.token);
            txtInfo = (TextView) findViewById(R.id.txtInfo);
            rvResult = findViewById(R.id.recyclerView);
            layoutMessage = (LinearLayout) findViewById(R.id.layoutMessage);
            layout_header = findViewById(R.id.layout_header);
            layoutFooter = findViewById(R.id.layoutFooter);

            LinearLayout layoutAdmin = (LinearLayout) findViewById(R.id.layoutAdmin);

            switch (produk) {
                case Produk.PULSA:
                case Produk.GAME:
                case Produk.PAKETDATA:
                case Produk.TOPUP:
                case Produk.VOUCHER:
                    layoutAdmin.setVisibility(View.GONE);
                    break;
            }

            rootLayout=(RelativeLayout) findViewById(R.id.rootLayout) ;

            btnBack=(ImageButton) findViewById(R.id.btnBack);
            btnBack.setOnClickListener(this);

            tvAmount=(TextView) findViewById(R.id.tvAmount);
            tvAmount.setText("Rp."+new DecimalFormat("#,##0").format(amount));

            btnCetak=(Button) findViewById(R.id.btnCetak);
            btnCetak.setOnClickListener(this);
        }catch (Exception e) {
            e.printStackTrace();
        }

        viewContent(result);
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy | HH:mm:ss").format(date) + " WIB";
        return formattedDate;
    }

    public void hideSomeElementToPrint() {
        switch (produk) {
            case Produk.PULSA:
            case Produk.GAME:
            case Produk.PAKETDATA:
            case Produk.TOPUP:
            case Produk.VOUCHER:
                LinearLayout layoutBill = (LinearLayout) findViewById(R.id.bill_merchant);
                layoutBill.setVisibility(View.GONE);
                LinearLayout layoutTotalBayar = (LinearLayout) findViewById(R.id.layout_Bayar);
                layoutTotalBayar.setVisibility(View.GONE);
                break;
        }
        btnBack.setVisibility(View.GONE);
        actionBtn.setVisibility(View.GONE);
        layout_header.setBackgroundResource(R.drawable.watermark_repeat);
        rvResult.setBackgroundResource(R.drawable.watermark_repeat);
        layoutFooter.setBackgroundResource(R.drawable.watermark_repeat);
    }

    public void showUpSomeElementAfterPrint() {
        switch (produk) {
            case Produk.PULSA:
            case Produk.GAME:
            case Produk.PAKETDATA:
            case Produk.TOPUP:
            case Produk.VOUCHER:
                LinearLayout layoutBill = (LinearLayout) findViewById(R.id.bill_merchant);
                layoutBill.setVisibility(View.VISIBLE);
                LinearLayout layoutTotalBayar = (LinearLayout) findViewById(R.id.layout_Bayar);
                layoutTotalBayar.setVisibility(View.VISIBLE);
                break;
        }
        btnBack.setVisibility(View.VISIBLE);
        actionBtn.setVisibility(View.VISIBLE);
        layout_header.setBackgroundResource(0);
        rvResult.setBackgroundResource(0);
        layoutFooter.setBackgroundResource(0);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnBack:
                onBackPressed();
                break;
            case R.id.btnCetak:
                hideSomeElementToPrint();
                final ProgressBar pbar=new PBarLinear(this,rootLayout);
                scrollView = (ScrollView) findViewById(R.id.scrollbar);
                response.rePrint(ReprintActivity.this,pbar,struk, scrollView);
                showUpSomeElementAfterPrint();
                break;
        }
    }

    private void viewContent(String content) {
        System.out.println(content);
        ArrayList<NewResultItem> al=null;
        txtInfo.setText(response.getProductMessage(produk, "Biller"));
        switch (produk){
            case Produk.POSTPAID:
                Postpaid pos=new Postpaid();
                al=pos.rePrint(content);
                struk=pos.getStruk();
                break;
            case Produk.PREPAID:
                Prepaid pre=new Prepaid();
                al=pre.rePrint(content);
                struk=pre.getStruk();
                try {
                    String token_pln  = respObject.getJSONObject("data").getString("token");
                    token_pln = token_pln.replaceAll("....", "$0 ");
                    token_info.setVisibility(View.VISIBLE);
                    token.setText(token_pln);
                }catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case Produk.NONTAGLIS:
                Nontaglis non=new Nontaglis();
                al=non.rePrint(content);
                struk=non.getStruk();
                break;
            case Produk.JASTEL:
                Telkom tel=new Telkom();
                al=tel.rePrint(content);
                struk=tel.getStruk();
                break;
            case Produk.TVCABLE:
                InternetTvCable tv=new InternetTvCable();
                al=tv.rePrint(content);
                struk=tv.getStruk();
                break;
            case Produk.VOUCHER:
                Pulsa pul=new Pulsa();
                al=pul.rePrint(content);
                struk=pul.getStruk();
                try {
                    if(respObject.getJSONObject("data").has("swreff")) {
                        TextView label_token_info = (TextView) findViewById(R.id.label_info_token);
                        label_token_info.setText("SN");
                        token_info.setVisibility(View.VISIBLE);
                        token.setText(respObject.getJSONObject("data").getString("swreff"));
                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case Produk.PASCABAYAR:
                PascaBayar pasca = new PascaBayar();
                al=pasca.rePrint(content);
                struk=pasca.getStruk();
                break;
            case Produk.BPJS:
                Bpjs bpjs=new Bpjs();
                al=bpjs.rePrint(content);
                struk=bpjs.getStruk();
                break;
            case Produk.PDAM:
                Pdam pdam=new Pdam();
//                if(pan.equals("5554")){
//                    al=pdam.rePrintBatang(content);
//                }else{
                    al=pdam.rePrint(content);
                //}
                struk=pdam.getStruk();
                break;
            case Produk.PBB:
                try {
                    Pbb pbb=new Pbb();
                    txtInfo.setText(response.getProductMessage(produk, respObject.getJSONObject("data").getString("kota")));
                    al=pbb.rePrint(content);
                    struk=pbb.getStruk();
                }catch (Exception e) {
                    e.printStackTrace();
                }
                break;
        }
        header.setVisibility(View.VISIBLE);
        layoutMessage.setVisibility(View.VISIBLE);
        NewResultAdapter preAdapter=new NewResultAdapter(this,al);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);
        rvResult=findViewById(R.id.recyclerView);
        rvResult.setLayoutManager(layoutManager);
        rvResult.setAdapter(preAdapter);
    }


}