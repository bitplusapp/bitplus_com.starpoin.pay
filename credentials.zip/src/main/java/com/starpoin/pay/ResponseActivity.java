package com.starpoin.pay;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.adapter.NewResultAdapter;
import com.starpoin.pay.model.NewResultItem;
import com.starpoin.pay.model.Response;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.PBarLinear;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import id.ss564.lib.slidingbutton.SlidingButton;

public class ResponseActivity extends AppCompatActivity implements View.OnClickListener {

    private int produk;
    private String result;
    private double amount;
    private double nominal;
    private String additional;
    private String trxid;
    private String noid;
    private String admin;
    private String time;

    public RelativeLayout rootLayout;
    private LinearLayout actionBtn, token_info, layoutMessage, layout_header, layoutFooter;
    private ImageButton btnBack;
    private Button btnBayar,btnCetak;
    private TextView tvAmount;
    private TextView adminbank, timestamp, ref_id, rptag, title, token, txtIdmerchant, txtInfo;
    private RecyclerView recyclerView;
    private ScrollView scrollView;
    private ImageView header;

    Context context;

    private String payResponse;
    private final Response response=new Response();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_new_response);

        this.setTitle("");

        context = this;

        produk=response.getExtraInt(this,"produk");
        result=response.getExtraString(this,"result");
        amount=response.getExtraDouble(this,"amount");
        trxid=response.getExtraString(this,"trxid");
        noid=response.getExtraString(this,"noid");
        time=response.getExtraString(this, "time");
        admin=response.getExtraString(this, "admin");
        nominal=response.getExtraDouble(this, "nominal");
        additional=response.getExtraString(this, "additional");

        rootLayout=(RelativeLayout) findViewById(R.id.rootLayout) ;

        btnBack=(ImageButton) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);

        tvAmount=(TextView) findViewById(R.id.tvAmount);
        tvAmount.setText("Rp."+new DecimalFormat("#,##0").format(amount));

        ref_id=(TextView) findViewById(R.id.ref_id);
        ref_id.setText(trxid);

        JsonIn jsonIn = new JsonIn();
        txtIdmerchant = (TextView) findViewById(R.id.txtIdmerchant);
        txtIdmerchant.setText(jsonIn.getObjectWithString(result, "data", "merchant"));

        adminbank=(TextView) findViewById(R.id.admin);
        adminbank.setText("Rp."+new DecimalFormat("#,##0").format(Double.parseDouble(admin)));

        timestamp=(TextView) findViewById(R.id.time);

        title = (TextView) findViewById(R.id.title);
        title.setText("Tagihan Pembayaran");

        timestamp.setText(timestampFormattedWIB(time));

        rptag=(TextView) findViewById(R.id.nominal);
        rptag.setText("Rp."+new DecimalFormat("#,##0").format(nominal));

        btnBayar=(Button) findViewById(R.id.btnBayar);
        btnBayar.setOnClickListener(this);

        btnCetak=(Button) findViewById(R.id.btnCetak);
        btnCetak.setOnClickListener(this);
        btnCetak.setEnabled(false);

        layoutMessage = (LinearLayout) findViewById(R.id.layoutMessage);
        txtInfo = (TextView) findViewById(R.id.txtInfo);

        actionBtn = (LinearLayout) findViewById(R.id.actionBtn);
        header = (ImageView) findViewById(R.id.header);
        token_info = (LinearLayout) findViewById(R.id.token_info);
        token = (TextView) findViewById(R.id.token);
        layout_header = findViewById(R.id.layout_header);
        layoutFooter = findViewById(R.id.layoutFooter);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        LinearLayout layoutAdmin = (LinearLayout) findViewById(R.id.layoutAdmin);

        switch (produk) {
            case Produk.PULSA:
            case Produk.GAME:
            case Produk.PAKETDATA:
            case Produk.TOPUP:
                layoutAdmin.setVisibility(View.GONE);
                break;
        }

        switcView();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnBack:
                onBackPressed();
                break;
            case R.id.btnBayar:
                //bayar();
                paymentConfirmSwipe();
                break;
            case R.id.btnCetak:
                hideSomeElementToPrint();
                final ProgressBar pbar= new PBarLinear(context,rootLayout);
                scrollView = (ScrollView) findViewById(R.id.scrollbar);
                response.paySuksesShareList(ResponseActivity.this, pbar, response.buildStruk(produk, payResponse), scrollView);
                showUpSomeElementAfterPrint();
                break;
        }
    }

    public void hideSomeElementToPrint() {
        switch (produk) {
            case Produk.PULSA:
            case Produk.GAME:
            case Produk.PAKETDATA:
            case Produk.TOPUP:
                LinearLayout layoutBill = (LinearLayout) findViewById(R.id.bill_merchant);
                layoutBill.setVisibility(View.GONE);
                LinearLayout layoutTotalBayar = (LinearLayout) findViewById(R.id.layout_Bayar);
                layoutTotalBayar.setVisibility(View.GONE);
                break;
        }
        btnBack.setVisibility(View.GONE);
        actionBtn.setVisibility(View.GONE);
        layout_header.setBackgroundResource(R.drawable.watermark_repeat);
        recyclerView.setBackgroundResource(R.drawable.watermark_repeat);
        layoutFooter.setBackgroundResource(R.drawable.watermark_repeat);
    }

    public void showUpSomeElementAfterPrint() {
        switch (produk) {
            case Produk.PULSA:
            case Produk.GAME:
            case Produk.PAKETDATA:
            case Produk.TOPUP:
                LinearLayout layoutBill = (LinearLayout) findViewById(R.id.bill_merchant);
                layoutBill.setVisibility(View.VISIBLE);
                LinearLayout layoutTotalBayar = (LinearLayout) findViewById(R.id.layout_Bayar);
                layoutTotalBayar.setVisibility(View.VISIBLE);
                break;
        }
        btnBack.setVisibility(View.VISIBLE);
        actionBtn.setVisibility(View.VISIBLE);
        layout_header.setBackgroundResource(0);
        recyclerView.setBackgroundResource(0);
        layoutFooter.setBackgroundResource(0);
    }

    private void switcView(){
        ArrayList<NewResultItem> al = response.NewlistResult(produk,result);
        NewResultAdapter preAdapter=new NewResultAdapter(context,al);
        GridLayoutManager layoutManager=new GridLayoutManager(context,1);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(preAdapter);
        recyclerView.setNestedScrollingEnabled(false);
    }

    private void paymentConfirmSwipe() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.payment_swipe_dialog);

        SlidingButton slidingButton = bottomSheetDialog.findViewById(R.id.slidingButton);
        slidingButton.setOnStateChangeListener(active -> {
            bottomSheetDialog.dismiss();
            bayar();
         });

        bottomSheetDialog.getBehavior().setDraggable(false);
        bottomSheetDialog.show();
    }

    private void paymentSuccessDialog(String paymentResponse) {
        final ProgressBar pbar=new PBarLinear(this, rootLayout);
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.after_payment_dialog);

        LinearLayout cetakLayout = bottomSheetDialog.findViewById(R.id.layoutCetak);
        LinearLayout batalLayout = bottomSheetDialog.findViewById(R.id.layoutBatal);

        cetakLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
                hideSomeElementToPrint();
                String struk = response.buildStruk(produk, paymentResponse);
                response.paySuksesShareList(ResponseActivity.this, pbar, struk, scrollView);
                showUpSomeElementAfterPrint();
            }
        });

        batalLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
                showUpSomeElementAfterPrint();
            }
        });

        bottomSheetDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                bottomSheetDialog.dismiss();
                showUpSomeElementAfterPrint();
            }
        });

        bottomSheetDialog.show();
    }

    private void bayar(){
        //Param param=new Param(trxid,noid,kode);
        Map<String, Object> param = response.paramsPay(produk, noid, trxid, additional, amount);
        String paramsPay = new JSONObject(param).toString();
        TransTask task = new TransTask(context,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                payResponse = "";
                if(rc.equals("0000") || rc.equals("0005")) { //pending or sukses
                        String data=json.getString(content, "data");
                        payResponse=content;
                        switcViewPay(content);
                        ref_id.setText("CA-"+trxid);
                        btnCetak.setEnabled(true);
                        btnBayar.setEnabled(false);

                        switch (produk) {
                            case Produk.PREPAID:
                                String token_pln  = json.getString(data, "token");
                                token_pln = token_pln.replaceAll("....", "$0 ");
                                token_info.setVisibility(View.VISIBLE);
                                token.setText(token_pln);
                                break;
                            case Produk.PULSA:
                            case Produk.GAME:
                            case Produk.PAKETDATA:
                                String code_sn = json.hasNameObj(data, "swreff");
                                if(code_sn != null) {
                                    TextView label_token_info = (TextView) findViewById(R.id.label_info_token);
                                    label_token_info.setText("SN");
                                    token_info.setVisibility(View.VISIBLE);
                                    token.setText(code_sn);
                                }
                                break;
                        }

                        scrollView = (ScrollView) findViewById(R.id.scrollbar);
                        System.out.println(content);
                        paymentSuccessDialog(content);
                }else{
                    String desc=json.getString(content,"message");
                    //showMsg(desc);
                    response.showMsg(ResponseActivity.this,desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                response.showMsg(ResponseActivity.this,e.getMessage());
            }

        });
        task.execute(paramsPay);
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy | HH:mm:ss").format(date) + " WIB";
        return formattedDate;
    }

    private void switcViewPay(String content) {
        JsonIn jsonIn = new JsonIn();
        ArrayList<NewResultItem> al = response.NewlistResult(produk, content);
        switch (produk) {
            case Produk.PULSA:
            case Produk.GAME:
            case Produk.PAKETDATA:
                title.setText("Transaksi Diproses");
                break;
            default:
                title.setText("Transaksi Sukses");
                break;
        }
        header.setVisibility(View.VISIBLE);
        layoutMessage.setVisibility(View.VISIBLE);
        txtInfo.setText(response.getProductMessage(produk, "Biller"));
        String times = jsonIn.getObjectWithString(content, "data", "time");
        timestamp.setText(timestampFormattedWIB(times));
        NewResultAdapter preAdapter=new NewResultAdapter(context, al);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(preAdapter);
        recyclerView.setNestedScrollingEnabled(false);
    }
}