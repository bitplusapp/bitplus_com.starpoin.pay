package com.starpoin.pay.model;

public enum ConnectionQuality {
    GOOD,
    MODERATE,
    POOR
}
