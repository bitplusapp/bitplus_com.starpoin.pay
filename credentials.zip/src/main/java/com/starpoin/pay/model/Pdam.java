package com.starpoin.pay.model;

import android.util.Log;

import com.starpoin.pay.util.DateParse;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class Pdam {

    private String idArea,idBiller,area,idsw;

    public Pdam(){

    }

    public Pdam(String idArea, String idBiller, String area, String idsw) {
        this.idArea = idArea;
        this.idBiller = idBiller;
        this.area = area;
        this.idsw = idsw;
    }

    public String getIdArea() {
        return idArea;
    }

    public void setIdArea(String idArea) {
        this.idArea = idArea;
    }

    public String getIdBiller() {
        return idBiller;
    }

    public void setIdBiller(String idBiller) {
        this.idBiller = idBiller;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getIdsw() {
        return idsw;
    }

    public void setIdsw(String idsw) {
        this.idsw = idsw;
    }

    public String paramsArea(){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","list_pdam");
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        String params="Trans"+new Params().buildParams(map);
        return params;
    }

    public ArrayList<Pdam> listAreaPdam(String content){
        ArrayList<Pdam> al=new ArrayList<>();
        try {
            JSONArray arr_data = new JSONArray(content);
            if(arr_data != null) {
                for (int i = 0; i < arr_data.length(); i++) {
                    JSONObject response = new JSONObject(arr_data.get(i).toString());
                    String idArea = "-";
                    String idBiller = response.getString("code");
                    String area = response.getString("name");
                    String idsw = "";
                    Pdam pdam = new Pdam(idArea, idBiller, area, idsw);
                    al.add(pdam);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return al;
    }

    public Map<String, Object> paramsInq(String noid,String biller,String sw){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","inquiry");
        map.put("productCategory","pdam");
        map.put("productCode", biller);
        map.put("customer_no", noid);
        return map;
    }

    public Map<String,Object> paramsPay(String trxid, String noid, String idBiller, Double amount){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","payment");
        map.put("productCategory", "pdam");
        map.put("productCode", idBiller);
        map.put("customer_no", noid);
        map.put("ref_id", trxid);
        map.put("amount", amount);
        return map;
    }

    public ArrayList<NewResultItem> listResultJson(String response){
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            //Log.d("rcode",rcode);
            if(rcode.equals("000")||rcode.equals("0000")){
                DecimalFormat df=new DecimalFormat("#,##0");
                JSONObject data = jsonResp.getJSONObject("data");
                JSONArray tagihanArray = data.getJSONArray("tagihan");
                String produk = data.getString("type_trans");
                String idpel = data.getString("nomor_pelanggan");
                String nama = data.getString("nama");
                String alamat = data.getString("alamat");
                String golongan = data.getString("golongan");
                String tagihan = data.getString("jumlah_tagihan");

                al.add(new NewResultItem("Produk", ":", produk));
                al.add(new NewResultItem("No Pelanggan", ":", idpel));
                al.add(new NewResultItem("Nama", ":", nama));
                al.add(new NewResultItem("Alamat", ":", alamat));
                al.add(new NewResultItem("Golongan", ":", golongan));
                al.add(new NewResultItem("Bulan Tagihan", ":", tagihan + " bln"));

                int NoDetail = 1;
                for(int i =0; i < tagihanArray.length(); i++) {
                    al.add(new NewResultItem("","",""));
                    al.add(new NewResultItem("-","Tagihan "+(NoDetail),"-"));

                    String periode = tagihanArray.getJSONObject(i).getString("periode");
                    String rptag = tagihanArray.getJSONObject(i).getString("rptag");
                    String denda = tagihanArray.getJSONObject(i).getString("denda");

                    al.add(new NewResultItem("Periode", ":", periode));
                    al.add(new NewResultItem("Tagihan", ":", df.format(Long.parseLong(rptag))));
                    al.add(new NewResultItem("Denda", ":", df.format(Long.parseLong(denda))));

                    if(data.has("swreff")) {
                        String met_awal = tagihanArray.getJSONObject(i).getString("meter_awal");
                        String met_akhir = tagihanArray.getJSONObject(i).getString("meter_akhir");
                        String met_pakai = tagihanArray.getJSONObject(i).getString("meter_pakai");

                        al.add(new NewResultItem("Stand Meter", ":", met_awal+"-"+met_akhir));
                        al.add(new NewResultItem("Kubikasi", ":", met_pakai +" m3"));
                    }

                    if(data.has("swreff")) {
                        al.add(new NewResultItem("PDAM Reff", ":", data.getString("swreff")));
                    }

                    NoDetail++;

                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            //
        }
        return al;
    }

    public String buildStruk(String response) {
        String out=null;
        String line ="------------------------------";
        String br=System.getProperty("line.separator");
        StringBuilder sb=new StringBuilder();
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            JSONObject in = new JSONObject(response);
            JSONObject data = in.getJSONObject("data");
            JSONArray tagihanArray = data.getJSONArray("tagihan");

            String time = data.getString("time");
            String idpel = data.getString("nomor_pelanggan");
            String nama = data.getString("nama");
            String alamat = data.getString("alamat");
            String golongan = data.getString("golongan");
            String tagihan = data.getString("jumlah_tagihan");
            String info = data.has("info") ? data.getString("info") : "";

            sb.append(TextSpace.rataTengah("PEMBAYARAN PDAM"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);

            sb.append("Tgl Trans    : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Pelanggan : " + idpel);
            sb.append("\n");
            sb.append("Nama         : " + nama);
            sb.append("\n");
            sb.append("Alamat       : " + alamat);
            sb.append("\n");
            sb.append("Golongan     : " + golongan);
            sb.append("\n");
            sb.append("Reff No      : " + data.getString("swreff"));
            sb.append("\n");
            sb.append("Tagihan      : " + "Rp. " + df.format(Integer.parseInt(tagihan)));
            sb.append("\n");
            sb.append("Admin Bank   : " + "Rp. " + df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar  : " + "Rp. " + df.format(data.getInt("amount")));
            sb.append("\n");
            sb.append("Rincian      :");
            sb.append("\n");
            sb.append("\n");

            for(int i =0; i < tagihanArray.length(); i++) {
                String periode = tagihanArray.getJSONObject(i).getString("periode");
                String rptag = tagihanArray.getJSONObject(i).getString("rptag");
                String denda = tagihanArray.getJSONObject(i).getString("denda");
                String met_awal = tagihanArray.getJSONObject(i).getString("meter_awal");
                String met_akhir = tagihanArray.getJSONObject(i).getString("meter_akhir");
                String met_pakai = tagihanArray.getJSONObject(i).getString("meter_pakai");

                sb.append("Bulan Tag     : " + periode);
                sb.append("\n");
                sb.append("Tagihan       : " + "Rp. " + df.format(Integer.parseInt(rptag)));
                sb.append("\n");
                sb.append("Denda         : " + "Rp. " + df.format(Integer.parseInt(denda)));
                sb.append("\n");
                sb.append("Meter Lama    : " + met_awal);
                sb.append("\n");
                sb.append("Meter Baru    : " + met_akhir);
                sb.append("\n");
                sb.append("Kubikasi      : " + met_pakai+ " m3");
                sb.append("\n");
                sb.append("\n");
            }

            sb.append(line);
            sb.append(br);

            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);
            if(!info.equals("")){
                sb.append(br);
                sb.append(TextSpace.rataTengah(info));
                sb.append(br);
                sb.append(br);
            }
            sb.append(TextSpace.rataTengah("CA : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            out=sb.toString();

        }catch (Exception e) {
            e.printStackTrace();
        }
        return out;
    }

    public String buildStrukPdamBatang(String response) {
        String out=null;

        String line ="------------------------------";
        String br=System.getProperty("line.separator");

        StringBuilder sb=new StringBuilder();
        sb.append(TextSpace.rataTengah("PEMBAYARAN PDAM"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("Simple & Mudah"));
        sb.append("\n");
        sb.append(line);
        sb.append(br);
        StringReader reader=null;
        reader=new StringReader(response);

        InputSource source = new InputSource(reader);
        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document doc = documentBuilder.parse(source);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("trx_response");
            Node nNode = nList.item(0);
            Element eElement = (Element) nNode;
            String trxid = eElement.getElementsByTagName("trxid").item(0).getTextContent();
            String noid =eElement.getElementsByTagName("noid").item(0).getTextContent();
            String nama = eElement.getElementsByTagName("nama").item(0).getTextContent();
            String alamat = eElement.getElementsByTagName("alamat").item(0).getTextContent();
            String golongan = eElement.getElementsByTagName("golongan").item(0).getTextContent();
            String refno = eElement.getElementsByTagName("refno").item(0).getTextContent();
            String adm = eElement.getElementsByTagName("adminfee").item(0).getTextContent();
            String rptag = eElement.getElementsByTagName("rptag").item(0).getTextContent();
            String amount = eElement.getElementsByTagName("amount").item(0).getTextContent();
            String time = eElement.getElementsByTagName("time").item(0).getTextContent();
            String ftime=new DateParse().parse(time);
            String pesan="";
            try {
                pesan = eElement.getElementsByTagName("pesan").item(0).getTextContent();
            }catch (Exception ex){
                Log.e("pesan",ex.getMessage());
                pesan="";
            }

            sb.append("Tgl Trans    : " + ftime);
            sb.append("\n");
            sb.append("No Trx       : " + trxid);
            sb.append("\n");
            sb.append("No Pelanggan : " + noid);
            sb.append("\n");
            sb.append("Nama         : " + nama);
            sb.append("\n");
            sb.append("Alamat       : " + alamat);
            sb.append("\n");
            sb.append("Golongan     : " + golongan);
            sb.append("\n");
            sb.append("Reff No      : " + refno);
            sb.append("\n");
            sb.append("Tagihan      : " +"Rp. "+ df.format(Integer.parseInt(rptag)));
            sb.append("\n");
            sb.append("Admin Bank   : " + "Rp. "+df.format(Integer.parseInt(adm)));
            sb.append("\n");
            sb.append("Total        : " + "Rp. "+df.format(Integer.parseInt(amount)));
            sb.append("\n");
            sb.append("Rincian      :");
            sb.append("\n");
            sb.append("\n");
            NodeList itemList = doc.getElementsByTagName("item");
            for (int i = 0; i < itemList.getLength(); i++){
                Node itemNode = itemList.item(i);
                if (itemNode.getNodeType() == Node.ELEMENT_NODE){

                    String billdate = eElement.getElementsByTagName("billdate").item(i).getTextContent();
                    String harga_air = eElement.getElementsByTagName("harga_air").item(i).getTextContent();
                    String billamount = eElement.getElementsByTagName("billamount").item(i).getTextContent();
                    String penalty = eElement.getElementsByTagName("penalty").item(i).getTextContent();
                    String kubikasi = eElement.getElementsByTagName("kubikasi").item(i).getTextContent();
                    String stan_lama = eElement.getElementsByTagName("stan_lama").item(i).getTextContent();
                    String stan_baru = eElement.getElementsByTagName("stan_baru").item(i).getTextContent();
                    String materai = eElement.getElementsByTagName("materai").item(i).getTextContent();
                    String subsidi = eElement.getElementsByTagName("subsidi").item(i).getTextContent();
                    //String subsidi_persen = eElement.getElementsByTagName("subsidi_persen").item(i).getTextContent();
                    String no_materai = eElement.getElementsByTagName("no_materai").item(i).getTextContent();

                    sb.append("Bulan Tag     : " + billdate);
                    sb.append("\n");
                    sb.append("Harga Air     : " + "Rp. "+df.format(Integer.parseInt(harga_air)));
                    sb.append("\n");
                    sb.append("Tagihan       : " + "Rp. "+df.format(Integer.parseInt(billamount)));
                    sb.append("\n");
                    sb.append("Denda         : " + "Rp. "+df.format(Integer.parseInt(penalty)));
                    sb.append("\n");
                    sb.append("Materai       : " + "Rp. "+df.format(Integer.parseInt(materai)));
                    sb.append("\n");
                    sb.append("No Materai    : " + no_materai);
                    sb.append("\n");
                    sb.append("Subsidi       : " + "Rp. "+df.format(Integer.parseInt(subsidi)) );
                    sb.append("\n");
                    sb.append("Meter Lama    : " + stan_lama);
                    sb.append("\n");
                    sb.append("Meter Baru    : " + stan_baru);
                    sb.append("\n");
                    sb.append("Kubikasi      : " + kubikasi);
                    sb.append("\n");
                    sb.append("\n");
                }
            }

            sb.append(line);
            sb.append(br);

            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);
            if(!pesan.equals("")){
                sb.append(br);
                sb.append(TextSpace.rataTengah(pesan));
                sb.append(br);
                sb.append(br);
            }
            sb.append(TextSpace.rataTengah("CA : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            out=sb.toString();
        }catch (Exception e){
            //Log.d("buildFormat",e.toString());
        }finally {
            if(reader != null){
                reader.close();
            }
        }
        return out;
    }

    public ArrayList<ResultItem> lapTrans(String response){
        ArrayList<ResultItem> al=new ArrayList<>();
        String line ="------------------------------";
        String br=System.getProperty("line.separator");

        StringBuilder sb=new StringBuilder();

        sb.append(TextSpace.rataTengah("PEMBAYARAN PDAM"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("Simple & Mudah"));
        sb.append("\n");
        sb.append(line);
        sb.append(br);

        StringReader reader=null;
        reader=new StringReader(response);

        InputSource source = new InputSource(reader);
        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document doc = documentBuilder.parse(source);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("trx_response");
            Node nNode = nList.item(0);
            Element eElement = (Element) nNode;
            String noid =eElement.getElementsByTagName("noid").item(0).getTextContent();
            String nama = eElement.getElementsByTagName("nama").item(0).getTextContent();
            String alamat = eElement.getElementsByTagName("alamat").item(0).getTextContent();
            String golongan = eElement.getElementsByTagName("golongan").item(0).getTextContent();
            String refno = eElement.getElementsByTagName("refno").item(0).getTextContent();
            String adm = eElement.getElementsByTagName("adminfee").item(0).getTextContent();
            String jum_lembar = eElement.getElementsByTagName("billcount").item(0).getTextContent();
            String rptag = eElement.getElementsByTagName("rptag").item(0).getTextContent();
            String blth = eElement.getElementsByTagName("blth").item(0).getTextContent();
            String cashback = eElement.getElementsByTagName("cashback").item(0).getTextContent();
            String bill_merchant = eElement.getElementsByTagName("bill_merchant").item(0).getTextContent();
            String amount = eElement.getElementsByTagName("amount").item(0).getTextContent();
            String time = eElement.getElementsByTagName("time").item(0).getTextContent();
            String ftime=new DateParse().parseCetakUlang(time);


            al.add(new ResultItem("No Pelanggan",noid));
            al.add(new ResultItem("Nama",nama));
            al.add(new ResultItem("Alamat",alamat));
            al.add(new ResultItem("Golongan",golongan));
            al.add(new ResultItem("Reff No",refno));
            al.add(new ResultItem("Jumlah Tag",df.format(Integer.parseInt(jum_lembar))));
            al.add(new ResultItem("Bulan Tag",blth));
            al.add(new ResultItem("Tagihan",df.format(Integer.parseInt(rptag))));
            al.add(new ResultItem("Admin Bank",df.format(Integer.parseInt(adm))));
            al.add(new ResultItem("Komisi",df.format(Integer.parseInt(cashback))));
            al.add(new ResultItem("Bill Merchant",df.format(Integer.parseInt(bill_merchant))));
            al.add(new ResultItem("Amount",df.format(Integer.parseInt(amount))));
            al.add(new ResultItem("Waktu Transaksi",ftime));
            al.add(new ResultItem("",""));
            al.add(new ResultItem("Detail","Transaksi"));

            sb.append("Tgl Trans    : " + ftime);
            sb.append("\n");
            sb.append("No Pelanggan : " + noid);
            sb.append("\n");
            sb.append("Nama         : " + nama);
            sb.append("\n");
            sb.append("Alamat       : " + alamat);
            sb.append("\n");
            sb.append("Golongan     : " + golongan);
            sb.append("\n");
            sb.append("Reff No      : " + refno);
            sb.append("\n");
            sb.append("Tagihan      : " +"Rp. "+ df.format(Integer.parseInt(rptag)));
            sb.append("\n");
            sb.append("Admin Bank   : " + "Rp. "+df.format(Integer.parseInt(adm)));
            sb.append("\n");
            sb.append("Total Bayar  : " + "Rp. "+df.format(Integer.parseInt(amount)));
            sb.append("\n");
            sb.append("Rincian      :");
            sb.append("\n");
            sb.append("\n");

            NodeList itemList = doc.getElementsByTagName("item");
            for (int i = 0; i < itemList.getLength(); i++){
                Node itemNode = itemList.item(i);
                if (itemNode.getNodeType() == Node.ELEMENT_NODE){

                    String billdate = eElement.getElementsByTagName("billdate").item(i).getTextContent();
                    String billamount = eElement.getElementsByTagName("billamount").item(i).getTextContent();
                    String penalty = eElement.getElementsByTagName("penalty").item(i).getTextContent();
                    String kubikasi = eElement.getElementsByTagName("kubikasi").item(i).getTextContent();
                    String stan_lama = eElement.getElementsByTagName("stan_lama").item(i).getTextContent();
                    String stan_baru = eElement.getElementsByTagName("stan_baru").item(i).getTextContent();
                    String materai = eElement.getElementsByTagName("materai").item(i).getTextContent();
                    int mat=Integer.parseInt(materai);

                    al.add(new ResultItem("",""));
                    al.add(new ResultItem("Bill Date",billdate));
                    al.add(new ResultItem("Bill Amount",df.format(Integer.parseInt(billamount))));
                    al.add(new ResultItem("Denda",df.format(Integer.parseInt(penalty))));
                    al.add(new ResultItem("Meter Lama",stan_lama));
                    al.add(new ResultItem("Meter Baru",stan_baru));
                    al.add(new ResultItem("Kubikasi",kubikasi));

                    sb.append("Bulan Tag     : " + billdate);
                    sb.append("\n");
                    sb.append("Tagihan       : " + "Rp. "+df.format(Integer.parseInt(billamount)));
                    sb.append("\n");
                    sb.append("Denda         : " + "Rp. "+df.format(Integer.parseInt(penalty)));
                    sb.append("\n");
                    sb.append("Meter Lama    : " + stan_lama);
                    sb.append("\n");
                    sb.append("Meter Baru    : " + stan_baru);
                    sb.append("\n");
                    sb.append("Kubikasi      : " + kubikasi);
                    sb.append("\n");
                    sb.append("\n");
                }
            }

            sb.append(line);
            sb.append(br);

            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);
            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);

        }catch (Exception e){
            //Log.d("buildFormat",e.toString());
        }finally {
            if(reader != null){
                reader.close();
            }
        }
        return al;
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d-m-yyyy HH:mm:ss").format(date);
        return formattedDate;
    }

    private String timestampFormattedStruk(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMdd").parse(timestamp.substring(0, 8));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy").format(date);
        return formattedDate;
    }

    public ArrayList<NewResultItem> rePrint(String response){
        String line ="------------------------------";
        String br=System.getProperty("line.separator");
        ArrayList<NewResultItem> al=new ArrayList<>();
        StringBuilder sb=new StringBuilder();
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            JSONObject in = new JSONObject(response);
            JSONObject data = in.getJSONObject("data");
            JSONArray tagihanArray = data.getJSONArray("tagihan");

            String time = data.getString("time");
            String ref_id = data.getString("ref_id");
            String produk = data.getString("type_trans");
            String idpel = data.getString("nomor_pelanggan");
            String nama = data.getString("nama");
            String alamat = data.getString("alamat");
            String golongan = data.getString("golongan");
            String tagihan = data.getString("jumlah_tagihan");
            String info = data.has("info") ? data.getString("info") : "";

            al.add(new NewResultItem("Produk", ":", produk));
            al.add(new NewResultItem("No Pelanggan", ":", idpel));
            al.add(new NewResultItem("Nama", ":", nama));
            al.add(new NewResultItem("Alamat", ":", alamat));
            al.add(new NewResultItem("Golongan", ":", golongan));
            al.add(new NewResultItem("Bulan Tagihan", ":", tagihan + " bln"));

            int NoDetail = 1;
            for(int i =0; i < tagihanArray.length(); i++) {
                al.add(new NewResultItem("","",""));
                al.add(new NewResultItem("-","Tagihan "+(NoDetail),"-"));

                String periode = tagihanArray.getJSONObject(i).getString("periode");
                String rptag = tagihanArray.getJSONObject(i).getString("rptag");
                String denda = tagihanArray.getJSONObject(i).getString("denda");

                al.add(new NewResultItem("Periode", ":", periode));
                al.add(new NewResultItem("Tagihan", ":", df.format(Long.parseLong(rptag))));
                al.add(new NewResultItem("Denda", ":", df.format(Long.parseLong(denda))));

                if(data.has("swreff")) {
                    String met_awal = tagihanArray.getJSONObject(i).getString("meter_awal");
                    String met_akhir = tagihanArray.getJSONObject(i).getString("meter_akhir");
                    String met_pakai = tagihanArray.getJSONObject(i).getString("meter_pakai");

                    al.add(new NewResultItem("Stand Meter", ":", met_awal+"-"+met_akhir));
                    al.add(new NewResultItem("Kubikasi", ":", met_pakai +" m3"));
                }

                if(data.has("swreff")) {
                    al.add(new NewResultItem("PDAM Reff", ":", data.getString("swreff")));
                }

            }

            sb.append(TextSpace.rataTengah("PEMBAYARAN PDAM"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);

            sb.append("Tgl Trans    : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Pelanggan : " + idpel);
            sb.append("\n");
            sb.append("Nama         : " + nama);
            sb.append("\n");
            sb.append("Alamat       : " + alamat);
            sb.append("\n");
            sb.append("Golongan     : " + golongan);
            sb.append("\n");
            sb.append("Reff No      : " + data.getString("swreff"));
            sb.append("\n");
            sb.append("Tagihan      : " + "Rp. " + df.format(Integer.parseInt(tagihan)));
            sb.append("\n");
            sb.append("Admin Bank   : " + "Rp. " + df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar  : " + "Rp. " + df.format(data.getInt("amount")));
            sb.append("\n");
            sb.append("Rincian      :");
            sb.append("\n");
            sb.append("\n");

            for(int i =0; i < tagihanArray.length(); i++) {
                    String periode = tagihanArray.getJSONObject(i).getString("periode");
                    String rptag = tagihanArray.getJSONObject(i).getString("rptag");
                    String denda = tagihanArray.getJSONObject(i).getString("denda");
                    String met_awal = tagihanArray.getJSONObject(i).getString("meter_awal");
                    String met_akhir = tagihanArray.getJSONObject(i).getString("meter_akhir");
                    String met_pakai = tagihanArray.getJSONObject(i).getString("meter_pakai");

                    sb.append("Bulan Tag     : " + periode);
                    sb.append("\n");
                    sb.append("Tagihan       : " + "Rp. " + df.format(Integer.parseInt(rptag)));
                    sb.append("\n");
                    sb.append("Denda         : " + "Rp. " + df.format(Integer.parseInt(denda)));
                    sb.append("\n");
                    sb.append("Meter Lama    : " + met_awal);
                    sb.append("\n");
                    sb.append("Meter Baru    : " + met_akhir);
                    sb.append("\n");
                    sb.append("Kubikasi      : " + met_pakai + " m3");
                    sb.append("\n");
                    sb.append("\n");
            }

            sb.append(line);
            sb.append(br);

            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);
            if(!info.equals("")){
                sb.append(br);
                sb.append(TextSpace.rataTengah(info));
                sb.append(br);
                sb.append(br);
            }
            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            this.setStruk(sb.toString());

        }catch (Exception e) {
            e.printStackTrace();
        }

        return al;
    }

    public ArrayList<ResultItem> rePrintBatang(String response){
        String line ="------------------------------";
        String br=System.getProperty("line.separator");
        ArrayList<ResultItem> al=new ArrayList<>();
        StringBuilder sb=new StringBuilder();

        sb.append(TextSpace.rataTengah("PEMBAYARAN PDAM"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("Simple & Mudah"));
        sb.append("\n");
        sb.append(line);
        sb.append(br);

        StringReader reader=null;
        reader=new StringReader(response);

        InputSource source = new InputSource(reader);
        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document doc = documentBuilder.parse(source);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("trx_response");
            Node nNode = nList.item(0);
            Element eElement = (Element) nNode;
            String noid =eElement.getElementsByTagName("noid").item(0).getTextContent();
            String nama = eElement.getElementsByTagName("nama").item(0).getTextContent();
            String alamat = eElement.getElementsByTagName("alamat").item(0).getTextContent();
            String golongan = eElement.getElementsByTagName("golongan").item(0).getTextContent();
            String refno = eElement.getElementsByTagName("refno").item(0).getTextContent();
            String adm = eElement.getElementsByTagName("adminfee").item(0).getTextContent();
            String jum_lembar = eElement.getElementsByTagName("billcount").item(0).getTextContent();
            String rptag = eElement.getElementsByTagName("rptag").item(0).getTextContent();
            String blth = eElement.getElementsByTagName("blth").item(0).getTextContent();
            String cashback = eElement.getElementsByTagName("cashback").item(0).getTextContent();
            String bill_merchant = eElement.getElementsByTagName("bill_merchant").item(0).getTextContent();
            String amount = eElement.getElementsByTagName("amount").item(0).getTextContent();
            String time = eElement.getElementsByTagName("time").item(0).getTextContent();
            String ftime=new DateParse().parseCetakUlang(time);
            String pesan="";
            try {
                pesan = eElement.getElementsByTagName("pesan").item(0).getTextContent();
            }catch (Exception ex){
                Log.e("pesan",ex.getMessage());
                pesan="";
            }

            al.add(new ResultItem("No Pelanggan",noid));
            al.add(new ResultItem("Nama",nama));
            al.add(new ResultItem("Alamat",alamat));
            al.add(new ResultItem("Golongan",golongan));
            al.add(new ResultItem("Reff No",refno));
            al.add(new ResultItem("Jumlah Tag",df.format(Integer.parseInt(jum_lembar))));
            al.add(new ResultItem("Bulan Tag",blth));
            al.add(new ResultItem("Tagihan",df.format(Integer.parseInt(rptag))));
            al.add(new ResultItem("Admin Bank",df.format(Integer.parseInt(adm))));
            al.add(new ResultItem("Komisi",df.format(Integer.parseInt(cashback))));
            al.add(new ResultItem("Bill Merchant",df.format(Integer.parseInt(bill_merchant))));
            al.add(new ResultItem("Amount",df.format(Integer.parseInt(amount))));
            al.add(new ResultItem("Waktu Transaksi",ftime));
            al.add(new ResultItem("",""));
            al.add(new ResultItem("Detail","Transaksi"));

            sb.append("Tgl Trans    : " + ftime);
            sb.append("\n");
            sb.append("No Pelanggan : " + noid);
            sb.append("\n");
            sb.append("Nama         : " + nama);
            sb.append("\n");
            sb.append("Alamat       : " + alamat);
            sb.append("\n");
            sb.append("Golongan     : " + golongan);
            sb.append("\n");
            sb.append("Reff No      : " + refno);
            sb.append("\n");
            sb.append("Tagihan      : " +"Rp. "+ df.format(Integer.parseInt(rptag)));
            sb.append("\n");
            sb.append("Admin Bank   : " + "Rp. "+df.format(Integer.parseInt(adm)));
            sb.append("\n");
            sb.append("Total Bayar  : " + "Rp. "+df.format(Integer.parseInt(amount)));
            sb.append("\n");
            sb.append("Rincian      :");
            sb.append("\n");
            sb.append("\n");

            NodeList itemList = doc.getElementsByTagName("item");
            for (int i = 0; i < itemList.getLength(); i++){
                Node itemNode = itemList.item(i);
                if (itemNode.getNodeType() == Node.ELEMENT_NODE){

                    String billdate = eElement.getElementsByTagName("billdate").item(i).getTextContent();
                    String harga_air = eElement.getElementsByTagName("harga_air").item(i).getTextContent();
                    String billamount = eElement.getElementsByTagName("billamount").item(i).getTextContent();
                    String penalty = eElement.getElementsByTagName("penalty").item(i).getTextContent();
                    String kubikasi = eElement.getElementsByTagName("kubikasi").item(i).getTextContent();
                    String stan_lama = eElement.getElementsByTagName("stan_lama").item(i).getTextContent();
                    String stan_baru = eElement.getElementsByTagName("stan_baru").item(i).getTextContent();
                    String materai = eElement.getElementsByTagName("materai").item(i).getTextContent();
                    String subsidi = eElement.getElementsByTagName("subsidi").item(i).getTextContent();
                    //String subsidi_persen = eElement.getElementsByTagName("subsidi_persen").item(i).getTextContent();
                    String no_materai = eElement.getElementsByTagName("no_materai").item(i).getTextContent();
                    int mat=Integer.parseInt(materai);

                    al.add(new ResultItem("",""));
                    al.add(new ResultItem("Bill Date",billdate));
                    al.add(new ResultItem("Bill Amount",df.format(Integer.parseInt(billamount))));
                    al.add(new ResultItem("Denda",df.format(Integer.parseInt(penalty))));
                    al.add(new ResultItem("Meter Lama",stan_lama));
                    al.add(new ResultItem("Meter Baru",stan_baru));
                    al.add(new ResultItem("Kubikasi",kubikasi));

                    sb.append("Bulan Tag     : " + billdate);
                    sb.append("\n");
                    sb.append("Harga Air     : " + "Rp. "+df.format(Integer.parseInt(harga_air)));
                    sb.append("\n");
                    sb.append("Tagihan       : " + "Rp. "+df.format(Integer.parseInt(billamount)));
                    sb.append("\n");
                    sb.append("Denda         : " + "Rp. "+df.format(Integer.parseInt(penalty)));
                    sb.append("\n");
                    sb.append("Materai       : " + "Rp. "+df.format(Integer.parseInt(materai)));
                    sb.append("\n");
                    sb.append("No Materai    : " + no_materai);
                    sb.append("\n");
                    sb.append("Subsidi       : " + "Rp. "+df.format(Integer.parseInt(subsidi)) );
                    sb.append("\n");
                    sb.append("Meter Lama    : " + stan_lama);
                    sb.append("\n");
                    sb.append("Meter Baru    : " + stan_baru);
                    sb.append("\n");
                    sb.append("Kubikasi      : " + kubikasi);
                    sb.append("\n");
                    sb.append("\n");
                }
            }

            sb.append(line);
            sb.append(br);

            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);
            if(!pesan.equals("")){
                sb.append(br);
                sb.append(TextSpace.rataTengah(pesan));
                sb.append(br);
                sb.append(br);
            }
            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            //al.add(new ResultItem("struk",sb.toString()));
            this.setStruk(sb.toString());
        }catch (Exception e){
            //Log.d("buildFormat",e.toString());
        }finally {
            if(reader != null){
                reader.close();
            }
        }
        return al;
    }

    private String struk;

    public String getStruk() {
        return struk;
    }

    public void setStruk(String struk) {
        this.struk = struk;
    }
}
