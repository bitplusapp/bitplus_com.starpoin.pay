package com.starpoin.pay.model;

import com.starpoin.pay.util.DateParse;
import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class Pbb {

    private String idproduk,area;

    public Pbb(){

    }

    public Pbb(String idproduk, String area) {
        this.idproduk = idproduk;
        this.area = area;
    }

    public String getIdproduk() {
        return idproduk;
    }

    public void setIdproduk(String idproduk) {
        this.idproduk = idproduk;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public ArrayList<Pbb> listArea(String content){
        ArrayList<Pbb> al=new ArrayList<>();
        try {
            JSONArray arr_data = new JSONArray(content);
            if(arr_data != null) {
                for (int i = 0; i < arr_data.length(); i++) {
                    JSONObject response = new JSONObject(arr_data.get(i).toString());
                    String idBiller = response.getString("additional_code");
                    String area = response.getString("name").toUpperCase();
                    Pbb pbb = new Pbb(idBiller, area);
                    al.add(pbb);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return al;
    }

    public String paramsInq(String noid,String kode){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action", "inquiry");
        map.put("productCategory", "tax");
        map.put("productCode", "pbb");
        map.put("customer_no", noid);
        map.put("additional", kode);
        String params= new JSONObject(map).toString();
        return params;
    }

    public Map<String,Object> paramsPay(String trxid,String noid,String kode, Double amount){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action", "payment");
        map.put("productCategory", "tax");
        map.put("productCode", "pbb");
        map.put("customer_no", noid);
        map.put("ref_id", trxid);
        map.put("amount", amount);
        map.put("additional", kode);
        return map;
    }

    public ArrayList<NewResultItem> listResult(String response){
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            //Log.d("rcode",rcode);
            if(rcode.equals("000")||rcode.equals("0000")){
                DecimalFormat df=new DecimalFormat("#,##0");
                JSONObject data = jsonResp.getJSONObject("data");

                String produk = data.getString("type_trans");
                String noid = data.getString("customer_no");
                String nama = data.getString("customer_name");
                String alamat = data.getString("alamat");
                String kelurahan = data.getString("keluarhan");
                String kecamatan = data.getString("kecamatan");
                String kab_kota = data.getString("kota");
                String tanah = data.getString("luas_tanah");
                String bangunan = data.getString("luas_bangunan");
                String periode = data.getString("periode");

                al.add(new NewResultItem("Produk",":",produk));
                al.add(new NewResultItem("No Objek Pajak",":",noid));
                al.add(new NewResultItem("Nama",":",nama));
                al.add(new NewResultItem("Alamat",":",alamat));
                al.add(new NewResultItem("Kelurahan",":",kelurahan));
                al.add(new NewResultItem("Kecamatan",":",kecamatan));
                al.add(new NewResultItem("Kob/Kota",":",kab_kota));
                al.add(new NewResultItem("Luas Tanah",":",tanah));
                al.add(new NewResultItem("Luas Bangunan",":",bangunan));
                al.add(new NewResultItem("Periode",":",periode));
                if(data.has("swreff")) {
                    al.add(new NewResultItem("Swreff", ":", data.getString("swreff")));
                }
                al.add(new NewResultItem("Lembar tagihan",":",df.format(Integer.parseInt(data.getString("jumlah_lembar")))));
            }
        }catch (Exception e){
            //System.out.print(e.toString());
        }finally {
        }
        return al;
    }

    private String timestampFormattedStruk(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMdd").parse(timestamp.substring(0, 8));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy").format(date);
        return formattedDate;
    }

    public String buildStruk(String response) {
        String out=null;
        String line ="------------------------------";
        String br=System.getProperty("line.separator");
        StringBuilder sb=new StringBuilder();
        DecimalFormat df=new DecimalFormat("#,##0");

        try {

            JSONObject in = new JSONObject(response);
            JSONObject data = in.getJSONObject("data");

            String time = data.getString("time");
            String noid = data.getString("customer_no");
            String nama = data.getString("customer_name");
            String alamat = data.getString("alamat");
            String kelurahan = data.getString("keluarhan");
            String kecamatan = data.getString("kecamatan");
            String kab_kota = data.getString("kota");
            String tanah = data.getString("luas_tanah");
            String bangunan = data.getString("luas_bangunan");
            String periode = data.getString("periode");

            sb.append(TextSpace.rataTengah("PEMBAYARAN PBB"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);

            sb.append("Tgl Trans    : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("NOP          : " + noid);
            sb.append("\n");
            sb.append("Nama         : " + nama);
            sb.append("\n");
            sb.append("Alamat       : " + alamat);
            sb.append("\n");
            sb.append("Kelurahan    : " + kelurahan);
            sb.append("\n");
            sb.append("Kecamatan    : " + kecamatan);
            sb.append("\n");
            sb.append("Kab/Kota     : " + kab_kota);
            sb.append("\n");
            sb.append("Luas Tanah   : " + tanah);
            sb.append("\n");
            sb.append("Luas Bangunan: " + bangunan);
            sb.append("\n");
            sb.append("Periode      : " + periode);
            sb.append("\n");
            sb.append("Reff No      : " + data.getString("swreff"));
            sb.append("\n");
            sb.append("Tagihan      : " +"Rp. "+ df.format(data.getInt("tagihan")));
            sb.append("\n");
            sb.append("Admin Bank   : " + "Rp. "+df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total        : " + "Rp. "+df.format(data.getInt("amount")));
            sb.append("\n");

            sb.append(line);
            sb.append(br);

            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);
            sb.append(TextSpace.rataTengah("CA : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            out=sb.toString();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return out;
    }

    public ArrayList<ResultItem> lapTrans(String response){
        ArrayList<ResultItem> al=new ArrayList<>();
        String line ="------------------------------";
        String br=System.getProperty("line.separator");
        StringBuilder sb=new StringBuilder();

        sb.append(TextSpace.rataTengah("PEMBAYARAN PBB"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("Simple & Mudah"));
        sb.append("\n");
        sb.append(line);
        sb.append(br);

        StringReader reader=null;
        reader=new StringReader(response);

        InputSource source = new InputSource(reader);
        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document doc = documentBuilder.parse(source);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("trx_response");
            Node nNode = nList.item(0);
            Element eElement = (Element) nNode;

            //String trxid = eElement.getElementsByTagName("trxid").item(0).getTextContent();
            String noid = eElement.getElementsByTagName("noid").item(0).getTextContent();
            String nama = eElement.getElementsByTagName("nama").item(0).getTextContent();
            String alamat = eElement.getElementsByTagName("alamat").item(0).getTextContent();
            String kelurahan = eElement.getElementsByTagName("kelurahan").item(0).getTextContent();
            String kecamatan = eElement.getElementsByTagName("kecamatan").item(0).getTextContent();
            String kab_kota = eElement.getElementsByTagName("kota").item(0).getTextContent();
            String tanah = eElement.getElementsByTagName("luas_tanah").item(0).getTextContent();
            String bangunan = eElement.getElementsByTagName("luas_bangunan").item(0).getTextContent();
            String periode = eElement.getElementsByTagName("periode").item(0).getTextContent();
            String refno = eElement.getElementsByTagName("refno").item(0).getTextContent();
            String adm = eElement.getElementsByTagName("admin").item(0).getTextContent();
            String rptag = eElement.getElementsByTagName("tagihan").item(0).getTextContent();
            String jum_lembar = eElement.getElementsByTagName("billcount").item(0).getTextContent();
            String cashback = eElement.getElementsByTagName("cashback").item(0).getTextContent();
            String bill_merchant = eElement.getElementsByTagName("bill_merchant").item(0).getTextContent();
            String amount = eElement.getElementsByTagName("amount").item(0).getTextContent();
            String time = eElement.getElementsByTagName("time").item(0).getTextContent();
            String ftime=new DateParse().parse(time);


//            al.add(new NewResultItem("No Objek Pajak",noid));
//            al.add(new NewResultItem("Nama",nama));
//            al.add(new NewResultItem("Alamat",alamat));
//            al.add(new NewResultItem("Kelurahan",kelurahan));
//            al.add(new NewResultItem("Kecamatan",kecamatan));
//            al.add(new NewResultItem("Kob/Kota",kab_kota));
//            al.add(new NewResultItem("Luas Tanah",tanah));
//            al.add(new NewResultItem("Luas Bangunan",bangunan));
//            al.add(new NewResultItem("Periode",periode));
//            al.add(new NewResultItem("Reff No",refno));
//            al.add(new NewResultItem("Jumlah Tag",df.format(Integer.parseInt(jum_lembar))));
//            al.add(new NewResultItem("Tagihan",df.format(Integer.parseInt(rptag))));
//            al.add(new NewResultItem("Admin Bank",df.format(Integer.parseInt(adm))));
//            al.add(new NewResultItem("Total",df.format(Integer.parseInt(amount))));
//            al.add(new NewResultItem("Komisi",df.format(Integer.parseInt(cashback))));
//            al.add(new NewResultItem("Pemotongan Saldo",df.format(Integer.parseInt(bill_merchant))));
//            al.add(new NewResultItem("Waktu Transaksi",ftime));
//
//            sb.append("Tgl Trans    : " + ftime);
//            sb.append("\n");
//            sb.append("NOP          : " + noid);
//            sb.append("\n");
//            sb.append("Nama         : " + nama);
//            sb.append("\n");
//            sb.append("Alamat       : " + alamat);
//            sb.append("\n");
//            sb.append("Kelurahan    : " + kelurahan);
//            sb.append("\n");
//            sb.append("Kecamatan    : " + kecamatan);
//            sb.append("\n");
//            sb.append("Kab/Kota     : " + kab_kota);
//            sb.append("\n");
//            sb.append("Luas Tanah   : " + tanah);
//            sb.append("\n");
//            sb.append("Luas Bangunan: " + bangunan);
//            sb.append("\n");
//            sb.append("Periode      : " + periode);
//            sb.append("\n");
//            sb.append("Reff No      : " + refno);
//            sb.append("\n");
//            sb.append("Tagihan      : " +"Rp. "+ df.format(Integer.parseInt(rptag)));
//            sb.append("\n");
//            sb.append("Admin Bank   : " + "Rp. "+df.format(Integer.parseInt(adm)));
//            sb.append("\n");
//            sb.append("Total        : " + "Rp. "+df.format(Integer.parseInt(amount)));
//            sb.append("\n");
//
//
//
//            sb.append(line);
//            sb.append(br);
//
//            sb.append(TextSpace.rataTengah("Terima Kasih"));
//            sb.append(br);
//            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
//            sb.append(br);

        }catch (Exception e){
            //Log.d("buildFormat",e.toString());
        }finally {
            if(reader != null){
                reader.close();
            }
        }
        return al;
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d-m-yyyy HH:mm:ss").format(date);
        return formattedDate;
    }

    public ArrayList<NewResultItem> rePrint(String response){
        String line ="------------------------------";
        String br=System.getProperty("line.separator");
        ArrayList<NewResultItem> al=new ArrayList<>();
        StringBuilder sb=new StringBuilder();
        DecimalFormat df=new DecimalFormat("#,##0");

        try {

            JSONObject in = new JSONObject(response);
            JSONObject data = in.getJSONObject("data");

            String time = data.getString("time");
            String produk = data.getString("type_trans");
            String noid = data.getString("customer_no");
            String nama = data.getString("customer_name");
            String alamat = data.getString("alamat");
            String kelurahan = data.getString("keluarhan");
            String kecamatan = data.getString("kecamatan");
            String kab_kota = data.getString("kota");
            String tanah = data.getString("luas_tanah");
            String bangunan = data.getString("luas_bangunan");
            String periode = data.getString("periode");

            al.add(new NewResultItem("Produk",":",produk));
            al.add(new NewResultItem("No Objek Pajak",":",noid));
            al.add(new NewResultItem("Nama",":",nama));
            al.add(new NewResultItem("Alamat",":",alamat));
            al.add(new NewResultItem("Kelurahan",":",kelurahan));
            al.add(new NewResultItem("Kecamatan",":",kecamatan));
            al.add(new NewResultItem("Kob/Kota",":",kab_kota));
            al.add(new NewResultItem("Luas Tanah",":",tanah));
            al.add(new NewResultItem("Luas Bangunan",":",bangunan));
            al.add(new NewResultItem("Periode",":",periode));

            if(data.has("swreff")) {
                al.add(new NewResultItem("Swreff", ":", data.getString("swreff")));
            }
            al.add(new NewResultItem("Lembar tagihan",":",df.format(data.getInt("lembar_tagihan"))));

            sb.append(TextSpace.rataTengah("PEMBAYARAN PBB"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);

            sb.append("Tgl Trans    : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("NOP          : " + noid);
            sb.append("\n");
            sb.append("Nama         : " + nama);
            sb.append("\n");
            sb.append("Alamat       : " + alamat);
            sb.append("\n");
            sb.append("Kelurahan    : " + kelurahan);
            sb.append("\n");
            sb.append("Kecamatan    : " + kecamatan);
            sb.append("\n");
            sb.append("Kab/Kota     : " + kab_kota);
            sb.append("\n");
            sb.append("Luas Tanah   : " + tanah);
            sb.append("\n");
            sb.append("Luas Bangunan: " + bangunan);
            sb.append("\n");
            sb.append("Periode      : " + periode);
            sb.append("\n");
            sb.append("Reff No      : " + data.getString("swreff"));
            sb.append("\n");
            sb.append("Tagihan      : " +"Rp. "+ df.format(data.getInt("tagihan")));
            sb.append("\n");
            sb.append("Admin Bank   : " + "Rp. "+df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total        : " + "Rp. "+df.format(data.getInt("amount")));
            sb.append("\n");

            sb.append(line);
            sb.append(br);

            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);
            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            //al.add(new NewResultItem("struk",sb.toString()));
            this.setStruk(sb.toString());
        }catch (Exception e) {
            e.printStackTrace();
        }

        return al;
    }

    private String struk;

    public String getStruk() {
        return struk;
    }

    public void setStruk(String struk) {
        this.struk = struk;
    }
}
