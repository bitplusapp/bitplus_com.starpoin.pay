package com.starpoin.pay.model;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class LapTiket {

    public LapTiket(){

    }

    public LapTiket(String tanggal, String tiket, String bank, String status) {
        this.tanggal = tanggal;
        this.tiket = tiket;
        this.bank = bank;
        this.status = status;
    }

    private String tanggal,tiket,bank,status;

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getTiket() {
        return tiket;
    }

    public void setTiket(String tiket) {
        this.tiket = tiket;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ArrayList<LapTiket> listContent(String response){
        ArrayList<LapTiket> al=new ArrayList<>();
        DecimalFormat df=new DecimalFormat("#,##0");
            try {
                JSONObject data = new JSONObject(response);
                JSONArray arr_data = data.getJSONArray("data");

                for (int temp = 0; temp < arr_data.length(); temp++){
                        String tgl = arr_data.getJSONObject(temp).getString("tglTiket");
                        String amount = arr_data.getJSONObject(temp).getString("amountTiket");
                        String bank = arr_data.getJSONObject(temp).getString("bankName");
                        String status = arr_data.getJSONObject(temp).getString("statusTiket");

                        LapTiket e=new LapTiket();
                        e.setTanggal(tgl);
                        e.setTiket(df.format(Integer.parseInt(amount)));
                        e.setBank(bank);
                        e.setStatus(status);
                        al.add(e);
                }

            }catch (Exception e){
                e.printStackTrace();
            }finally {

            }

        return al;
    }
}
