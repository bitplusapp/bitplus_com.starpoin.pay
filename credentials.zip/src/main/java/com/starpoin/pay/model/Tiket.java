package com.starpoin.pay.model;

import com.starpoin.pay.util.JsonIn;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Tiket {

    private String tiket, bankName,accNumber,accName;

    public Tiket() {
    }

    public Tiket(String tiket,String bankName, String accNumber, String accName) {
        this.tiket = tiket;
        this.bankName = bankName;
        this.accNumber = accNumber;
        this.accName = accName;
    }

    public String getTiket() {
        return tiket;
    }

    public void setTiket(String tiket) {
        this.tiket = tiket;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getAccNumber() {
        return accNumber;
    }

    public void setAccNumber(String accNumber) {
        this.accNumber = accNumber;
    }

    public String getAccName() {
        return accName;
    }

    public void setAccName(String accName) {
        this.accName = accName;
    }

    public ArrayList<Tiket> listTiket(String response){
        ArrayList<Tiket> list=new ArrayList<>();
        String rc=new JsonIn().getString(response,"rc");

        if(rc.equals("000")||rc.equals("0000")) {
            String data = new JsonIn().getString(response, "data");
            String amount=new JsonIn().getString(data,"amount");
            bankName=new JsonIn().getString(data,"bank_name");
            accNumber=new JsonIn().getString(data,"account_number");
            accName=new JsonIn().getString(data,"account_name");
            int i=Integer.parseInt(amount);
            DecimalFormat df=new DecimalFormat("#,##0");
            tiket=df.format(i);

            Tiket tik=new Tiket(tiket,bankName,accNumber,accName);
            list.add(tik);
        }
        return list;
    }
}
