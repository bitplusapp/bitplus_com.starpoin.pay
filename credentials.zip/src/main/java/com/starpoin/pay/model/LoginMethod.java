package com.starpoin.pay.model;

public class LoginMethod {
    public final static int EMAIL_PASSWORD=1;
    public final static int GOOGLE=2;
    public final static int BIOMETRIC=3;
    public final static int PIN_APP=4;
}
