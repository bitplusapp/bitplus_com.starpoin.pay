package com.starpoin.pay.model;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class LapCashback {

    private String produk;
    private String noid ;
    private String nama ;
    private String blth ;
    private String cashback;
    private String amount ;

    private double totalAmount;
    private double totalCashback;

    public LapCashback() {
    }

    public LapCashback(String produk, String noid, String nama, String blth, String cashback, String amount) {
        this.produk = produk;
        this.noid = noid;
        this.nama = nama;
        this.blth = blth;
        this.cashback = cashback;
        this.amount = amount;
    }

    public String getProduk() {
        return produk;
    }

    public void setProduk(String produk) {
        this.produk = produk;
    }

    public String getNoid() {
        return noid;
    }

    public void setNoid(String noid) {
        this.noid = noid;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getBlth() {
        return blth;
    }

    public void setBlth(String blth) {
        this.blth = blth;
    }

    public String getCashback() {
        return cashback;
    }

    public void setCashback(String cashback) {
        this.cashback = cashback;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getTotalCashback() {
        return totalCashback;
    }

    public void setTotalCashback(double totalCashback) {
        this.totalCashback = totalCashback;
    }

    public ArrayList<LapCashback> listCashback(String response){
        ArrayList<LapCashback> al=new ArrayList<>();
        DecimalFormat df=new DecimalFormat("#,##0");
        double tot=0;
        double totCashback=0;
        try {
            JSONObject resp = new JSONObject(response);
            JSONArray reportArray = resp.getJSONArray("data");
            for (int temp = 0; temp < reportArray.length(); temp++) {
                    String produk = reportArray.getJSONObject(temp).getString("produk");
                    String noid = reportArray.getJSONObject(temp).getString("noid");
                    String nama = reportArray.getJSONObject(temp).getString("nama");
                    String blth = reportArray.getJSONObject(temp).getString("blth");
                    String cash = reportArray.getJSONObject(temp).getString("cashback");
                    String amount = reportArray.getJSONObject(temp).getString("amount");

                    int iamount=Integer.parseInt(amount);
                    double icash=Integer.parseInt(cash);

                    totCashback=totCashback+icash;
                    tot=tot+icash;
                    LapCashback e=new LapCashback();
                    e.setProduk(produk);
                    e.setNoid(noid);
                    e.setNama(nama);
                    e.setBlth(blth);
                    e.setCashback(df.format(icash));
                    e.setAmount(df.format(iamount));
                    al.add(e);
            }

            setTotalCashback(totCashback);

        }catch (Exception e){
            //Log.e("lapcash",e.toString());
        }finally {
        }
        return al;

    }
}
