package com.starpoin.pay.model;

import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Topup {
    private String idsw,kode,provider,desc;

    public Topup(){

    }

    public Topup(String provider, String idsw) {
        this.idsw = idsw;
        this.provider = provider;
    }

    public Topup(String idsw, String kode, String provider, String desc) {
        this.idsw = idsw;
        this.kode = kode;
        this.provider = provider;
        this.desc = desc;
    }

    public String getIdsw() {
        return idsw;
    }

    public void setIdsw(String idsw) {
        this.idsw = idsw;
    }

    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public ArrayList<Topup> buildProviderJson(String response) {
        ArrayList<Topup> al = new ArrayList<>();
        try {
            JSONArray arr_products = new JSONArray(response);

            if(arr_products != null) {
                for (int i = 0; i < arr_products.length(); i++) {
                    JSONObject resp = new JSONObject(arr_products.get(i).toString());
                    String namaProvider = resp.getString("provider");
                    String sw = "";
                    Topup topup =new Topup(namaProvider,sw);
                    al.add(topup);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return al;
    }

    public ArrayList<Topup> topupDenomList(String content){
        ArrayList<Topup> al=new ArrayList<>();
        try {
            JSONArray arr_data = new JSONArray(content);
            if(arr_data != null) {
                for (int i = 0; i < arr_data.length(); i++) {
                    JSONObject response = new JSONObject(arr_data.get(i).toString());
                    String namaProvider = response.getString("name");
                    String kode = response.getString("additional_code");
                    String keterangan = response.getString("description");
                    Topup topup = new Topup("", kode, namaProvider, keterangan);
                    al.add(topup);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return al;
    }

    public String paramsInq(String noid,String idProduk){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","inq");
        map.put("mti","topup");
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("noid", noid);
        map.put("idproduk", idProduk);
        String params="Trans"+new Params().buildParams(map);
        return params;
    }

    public Map<String,Object> paramsPay(String trxid,String noid,String idProduk){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","pay");
        map.put("mti","topup");
        map.put("trxid",trxid);
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("noid", noid);
        map.put("idproduk", idProduk);
        String params="Trans"+new Params().buildParams(map);
        return map;
    }
}
