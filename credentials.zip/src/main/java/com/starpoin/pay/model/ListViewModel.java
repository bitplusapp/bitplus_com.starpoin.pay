package com.starpoin.pay.model;

import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class ListViewModel {
    private String id;
    private String value;
    private ArrayList<childListViewModel> childListViewModel;

    public ListViewModel() {
    }

    public ListViewModel(String id, String value) {
        this.id = id;
        this.value = value;
    }

    public ListViewModel(String id, String value, ArrayList<childListViewModel> child) {
        this.id = id;
        this.value = value;
        this.childListViewModel = child;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public ArrayList<ListViewModel.childListViewModel> getChildListViewModel() {
        return childListViewModel;
    }

    public void setChildListViewModel(ArrayList<ListViewModel.childListViewModel> childListViewModel) {
        this.childListViewModel = childListViewModel;
    }

    public ArrayList<ListViewModel> autoGenerateKelas() {
        ArrayList<ListViewModel> result = new ArrayList<>();
        result.add(new ListViewModel("id_kelasA", "Hobi A"));
        result.add(new ListViewModel("id_kelasB", "Hobi B"));
        result.add(new ListViewModel("id_kelasC", "Hobi C"));
        return result;
    }

    public ArrayList<ListViewModel> autoGenerateFilterHasil() {
        ArrayList<ListViewModel> result = new ArrayList<>();
        result.add(new ListViewModel("seeding", "Seeding / Kualifikasi"));
        result.add(new ListViewModel("final", "Final Run"));
        return result;
    }

    public static class childListViewModel {
        private String id_kelas;
        private String nama_kelas;

        public childListViewModel(String id_kelas, String nama_kelas) {
            this.id_kelas = id_kelas;
            this.nama_kelas = nama_kelas;
        }

        public String getId_kelas() {
            return id_kelas;
        }

        public void setId_kelas(String id_kelas) {
            this.id_kelas = id_kelas;
        }

        public String getNama_kelas() {
            return nama_kelas;
        }

        public void setNama_kelas(String nama_kelas) {
            this.nama_kelas = nama_kelas;
        }
    }

}
