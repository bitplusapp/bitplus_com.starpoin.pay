package com.starpoin.pay.model;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class Bank {

    private String bankCode,bankName;

    public Bank() {
    }

    public Bank(String bankCode, String bankName) {
        this.bankCode = bankCode;
        this.bankName = bankName;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    @NonNull
    @Override
    public String toString() {
        String str=bankName;
        return str;
    }

    public List<Bank> bankList(){
        List<Bank> list=new ArrayList<>();
        list.add(new Bank("0","PILIH BANK"));
        list.add(new Bank("002","BRI"));
        list.add(new Bank("008","MANDIRI"));
        list.add(new Bank("009","BNI"));
        list.add(new Bank("014","BCA"));
        return list;
    }

    public ArrayList<Bank> listBank(){
        ArrayList<Bank> list=new ArrayList<>();
        list.add(new Bank("002","BRI"));
        list.add(new Bank("008","MANDIRI"));
        list.add(new Bank("009","BNI"));
        list.add(new Bank("014","BCA"));
        return list;
    }
}
