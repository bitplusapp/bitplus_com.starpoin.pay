package com.starpoin.pay.model;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class LapTransaksi {

    private String produk,noid,nama,lbl_blth,blth,cash,amount,datetime;
    private double totalAmount;

    public LapTransaksi() {

    }

    public LapTransaksi(String produk, String noid, String nama, String lbl_blth, String blth, String cash, String amount, String datetime) {
        this.produk = produk;
        this.noid = noid;
        this.nama = nama;
        this.lbl_blth = lbl_blth;
        this.blth = blth;
        this.cash = cash;
        this.amount = amount;
        this.datetime = datetime;
    }

    public String getProduk() {
        return produk;
    }

    public void setProduk(String produk) {
        this.produk = produk;
    }

    public String getNoid() {
        return noid;
    }

    public void setNoid(String noid) {
        this.noid = noid;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getLbl_blth() {
        return lbl_blth;
    }

    public void setLbl_blth(String lbl_blth) {
        this.lbl_blth = lbl_blth;
    }

    public String getBlth() {
        return blth;
    }

    public void setBlth(String blth) {
        this.blth = blth;
    }

    public String getCash() {
        return cash;
    }

    public void setCash(String cash) {
        this.cash = cash;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
    

    public ArrayList<LapTransaksi> getListJson(String response){
        ArrayList<LapTransaksi> al=new ArrayList<>();
        DecimalFormat df=new DecimalFormat("#,##0");
        int tot=0;
        double totAmount=0;
        try {
            JSONObject resp = new JSONObject(response);
            JSONArray reportArray = resp.getJSONArray("data");
            for (int temp = 0; temp < reportArray.length(); temp++) {
                    String produk = reportArray.getJSONObject(temp).getString("produk");
                    String noid = reportArray.getJSONObject(temp).getString("noid");
                    String nama = reportArray.getJSONObject(temp).getString("nama");
                    String lbl_blth = reportArray.getJSONObject(temp).getString("labelBlth");
                    String blth = reportArray.getJSONObject(temp).getString("blth");
                    String cash = reportArray.getJSONObject(temp).getString("cashback");
                    String amount = reportArray.getJSONObject(temp).getString("amount");
                    String datetime = reportArray.getJSONObject(temp).getString("datetime");
                    double iamount=Double.parseDouble(amount);
                    //private String produk,noid,nama,lbl_blth,blth,cash,amount,datetime;
                    LapTransaksi e=new LapTransaksi(produk,noid,nama,lbl_blth,blth,cash,amount,datetime);

                    al.add(e);
                    tot++;
                    totAmount+=iamount;
                }
            this.setTotalAmount(totAmount);
        }catch (Exception e){
            Log.e("lapcash",e.toString());
        }finally {
        }
        return al;
    }
}
