package com.starpoin.pay.model;

import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;
import com.starpoin.pay.util.XmlIn;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Bpjs {

    private String periodeLabel,periodeValue;

    public Bpjs(){

    }

    public Bpjs(String periodeLabel, String periodeValue) {
        this.periodeLabel = periodeLabel;
        this.periodeValue = periodeValue;
    }

    public String getPeriodeLabel() {
        return periodeLabel;
    }

    public void setPeriodeLabel(String periodeLabel) {
        this.periodeLabel = periodeLabel;
    }

    public String getPeriodeValue() {
        return periodeValue;
    }

    public void setPeriodeValue(String periodeValue) {
        this.periodeValue = periodeValue;
    }

    public ArrayList<Bpjs> periodeList(){
        ArrayList<Bpjs> list=new ArrayList<>();
        list.add(new Bpjs("1 Bulan","01"));
        list.add(new Bpjs("2 Bulan","02"));
        list.add(new Bpjs("3 Bulan","03"));
        list.add(new Bpjs("4 Bulan","04"));
        list.add(new Bpjs("5 Bulan","05"));
        list.add(new Bpjs("6 Bulan","06"));
        list.add(new Bpjs("7 Bulan","07"));
        list.add(new Bpjs("8 Bulan","08"));
        list.add(new Bpjs("9 Bulan","09"));
        list.add(new Bpjs("10 Bulan","10"));
        list.add(new Bpjs("11 Bulan","11"));
        list.add(new Bpjs("12 Bulan","12"));
        return list;
    }

    public Map<String, Object> paramsInq(String noid,String idProduk,String type) {
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","inquiry");
        map.put("productCategory", "bpjs");
        map.put("productCode", type);
        map.put("customer_no", noid);
        map.put("additional", idProduk);
        return map;
    }

//    public String paramsInq(String noid,String periode){
//        Map<String,Object> map=new HashMap<String, Object>();
//        map.put("q","inq");
//        map.put("mti","bpjs");
//        map.put("idmerc", Wong.getIdmerch());
//        map.put("iduser", Wong.getEmail());
//        map.put("noid", noid);
//        map.put("periode", periode);
//        String params="Trans"+new Params().buildParams(map);
//        return params;
//    }

    public Map<String,Object> paramsPay(String trxid, String noid, String code_voucher, Double amount){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","payment");
        map.put("productCategory", "bpjs");
        map.put("productCode", "kesehatan");
        map.put("customer_no", noid);
        map.put("additional", code_voucher);
        map.put("ref_id", trxid);
        map.put("amount", amount);
        return map;
    }

    public ArrayList<NewResultItem> listResultJson(String response){
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            //Log.d("rcode",rcode);
            if(rcode.equals("000")||rcode.equals("0000")){
                //DecimalFormat df=new DecimalFormat("#,##0");
                JSONObject data = jsonResp.getJSONObject("data");
                //JSONArray detail_peserta = data.getJSONArray("detail_peserta");
                String produk = data.getString("type_trans");
                String no_va = data.getString("no_va");
                String name = data.getString("nama");
                String nama_cabang = data.getString("nama_cabang");
                String total_peserta = data.getString("total_peserta");
                String periode = data.getString("periode");

                al.add(new NewResultItem("Produk",":", produk));
                al.add(new NewResultItem("No Peserta",":",no_va));
                al.add(new NewResultItem("Nama",":",name));
                al.add(new NewResultItem("Total Peserta",":",total_peserta));
                al.add(new NewResultItem("Cabang",":",nama_cabang));
                al.add(new NewResultItem("Periode",":", periode));

                if(data.has("swreff")) {
                    al.add(new NewResultItem("BPJS Ref", ":", data.getString("swreff")));
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            //
        }
        return al;
    }

    private String timestampFormattedStruk(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMdd").parse(timestamp.substring(0, 8));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy").format(date);
        return formattedDate;
    }

    public String buildStruk(String response) {
        String out = null;
        String line ="------------------------------";
        String br=System.getProperty("line.separator");
        String content=response;
        DecimalFormat df=new DecimalFormat("#,##0");
        StringBuilder sb=new StringBuilder();

        try {

            JSONObject in = new JSONObject(content);
            System.out.println(content);
            JSONObject data = in.getJSONObject("data");

            String time = data.getString("time");
            String ref_id = data.getString("ref_id");
            String produk = data.getString("type_trans");
            String no_va = data.getString("no_va");
            String name = data.getString("nama");
            String nama_cabang = data.getString("nama_cabang");
            String total_peserta = data.getString("total_peserta");
            String periode = data.getString("periode");

            sb.append(TextSpace.rataTengah("PEMBAYARAN BPJS"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Peserta : " + no_va);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Periode    : " + periode);
            sb.append("\n");
            sb.append("SW Reff    : " + data.getString("swreff"));
            sb.append("\n");
            sb.append("Cabang     : " + nama_cabang);
            sb.append("\n");
            sb.append("Premi      : " + df.format(data.getLong("amount")-data.getLong("admin")));
            sb.append("\n");

            sb.append("Admin Bank : " + df.format(data.getLong("admin")));
            sb.append("\n");
            sb.append("Total Bayar: " + df.format(data.getLong("amount")));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            //sb.append("Terima Kasih");
            sb.append("\n");
            //sb.append("CU : "+ Wong.getIdmerch()+" bitplus Mobile");
            sb.append(TextSpace.rataTengah("CA : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            out = sb.toString();
        }catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(out);
        return out;
    }

    public ArrayList<ResultItem> lapTrans(String resp){
        String content=resp;
        ArrayList<ResultItem> al=new ArrayList<>();
        XmlIn in=new XmlIn();
        String rc=in.getItem(content,"rc");
        if(rc.equals("0000")||rc.equals("000")){
            DecimalFormat df=new DecimalFormat("#,##0");

            String trxid=in.getItem(content,"trxid");
            String type_trans=in.getItem(content,"type_trans");

            String desc=in.getItem(content,"desc");
            String merchant=in.getItem(content,"merchant");
            String subscriber_id=in.getItem(content,"noid");
            String name=in.getItem(content,"nama");
            String periode=in.getItem(content,"periode");
            //String sisa_periode=in.getItem(content,"sisa");
            String kode_cabang=in.getItem(content,"kode_cabang");
            String nama_cabang=in.getItem(content,"nama_cabang");
            String adminfee=in.getItem(content,"adminfee");
            String premi=in.getItem(content,"premi");
            String sw_reff=in.getItem(content,"sw_reff");
            String amount=in.getItem(content,"amount");
            String cashback=in.getItem(content,"cashback");
            String bill_merchant=in.getItem(content,"bill_merchant");



            //al.add(new ResultItem("Merchant",merchant));
            al.add(new ResultItem("ID Peserta",subscriber_id));
            al.add(new ResultItem("Nama",name));
            al.add(new ResultItem("Kode Cabang",kode_cabang));
            al.add(new ResultItem("Nama Cabang",nama_cabang));
            al.add(new ResultItem("Premi",df.format(Integer.parseInt(premi))));

            al.add(new ResultItem("Sw Reff",sw_reff));
            al.add(new ResultItem("Periode",periode));
            //al.add(new ResultItem("Sisa Periode",sisa_periode));
            al.add(new ResultItem("Admin Bank",df.format(Integer.parseInt(adminfee))));
            al.add(new ResultItem("Total",df.format(Integer.parseInt(amount))));
            //al.add(new ResultItem("Cashback",df.format(Integer.parseInt(cashback))));
            //al.add(new ResultItem("Bill Merchant",df.format(Integer.parseInt(bill_merchant))));
        }else{
            al.add(new ResultItem("Data tidak ditemukan",""));
        }
        return al;
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d-m-yyyy HH:mm:ss").format(date);
        return formattedDate;
    }

    public ArrayList<NewResultItem> rePrint(String resp){
        String line ="------------------------------";
        String br=System.getProperty("line.separator");
        String content=resp;
        DecimalFormat df=new DecimalFormat("#,##0");
        ArrayList<NewResultItem> al=new ArrayList<>();
        StringBuilder sb=new StringBuilder();

        try {

            JSONObject in = new JSONObject(content);
            JSONObject data = in.getJSONObject("data");

            String time = data.getString("time");
            String ref_id = data.getString("ref_id");
            String produk = data.getString("type_trans");
            String no_va = data.getString("no_va");
            String name = data.getString("nama");
            String nama_cabang = data.getString("nama_cabang");
            String total_peserta = data.getString("total_peserta");
            String periode = data.getString("periode");

            al.add(new NewResultItem("Produk",":", produk));
            al.add(new NewResultItem("No Peserta",":",no_va));
            al.add(new NewResultItem("Nama",":",name));
            al.add(new NewResultItem("Total Peserta",":",total_peserta));
            al.add(new NewResultItem("Cabang",":",nama_cabang));
            al.add(new NewResultItem("Periode",":", periode));

            if(data.has("swreff")) {
                al.add(new NewResultItem("BPJS Ref", ":", data.getString("swreff")));
            }

            sb.append(TextSpace.rataTengah("PEMBAYARAN BPJS"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Peserta : " + no_va);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Periode    : " + periode);
            sb.append("\n");
            sb.append("SW Reff    : " + data.getString("swreff"));
            sb.append("\n");
            sb.append("Cabang     : " + nama_cabang);
            sb.append("\n");
            sb.append("Premi      : " + df.format(data.getLong("amount")-data.getLong("admin")));
            sb.append("\n");

            sb.append("Admin Bank : " + df.format(data.getLong("admin")));
            sb.append("\n");
            sb.append("Total Bayar: " + df.format(data.getLong("amount")));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            //sb.append("Terima Kasih");
            sb.append("\n");
            //sb.append("CU : "+ Wong.getIdmerch()+" bitplus Mobile");
            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
        }catch (Exception e) {
            e.printStackTrace();
        }

        this.setStruk(sb.toString());
        return al;
    }

    private String struk;

    public String getStruk() {
        return struk;
    }

    public void setStruk(String struk) {
        this.struk = struk;
    }
}
