package com.starpoin.pay.model;



import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Game {

    private String provider;

    public Game(){

    }

    public Game(String provider) {
        this.provider = provider;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String paramsProvider(){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","list_provider");
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("type_produk", "game");
        String params="Trans"+new Params().buildParams(map);
        return params;
    }

    public Map<String,Object> paramsPay(String trxid,String noid,String idProduk){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","pay");
        map.put("mti","game");
        map.put("trxid",Wong.getTrxid());
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("noid", noid);
        map.put("idproduk", idProduk);
        map.put("type_produk", "game");
        return map;
    }

    public ArrayList<Game> buildProviderJson(String response) {
        ArrayList<Game> al = new ArrayList<>();
        try {
            JSONArray arr_products = new JSONArray(response);

            if(arr_products != null) {
                for (int i = 0; i < arr_products.length(); i++) {
                    JSONObject resp = new JSONObject(arr_products.get(i).toString());
                    Game game = new Game(resp.getString("provider"));
                    al.add(game);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return al;
    }
}
