package com.starpoin.pay.model;

import android.util.Log;

import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;
import com.starpoin.pay.util.XmlIn;

import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class Prepaid {

    private String title,value;

    public Prepaid() {}

    public Map<String,Object> paramsInq(String noid, String denom){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","inquiry");
        map.put("productCategory", "pln");
        map.put("productCode", "prepaid");
        map.put("customer_no", noid);
        map.put("additional", denom);
        return map;
    }

    public Map<String,Object> paramsPay(String trxid, String noid, String denom, Double amount){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","payment");
        map.put("productCategory", "pln");
        map.put("productCode", "prepaid");
        map.put("customer_no", noid);
        map.put("additional", denom);
        map.put("ref_id", trxid);
        map.put("amount", amount);
        return map;
    }


    public Prepaid(String title, String value) {
        this.title = title;
        this.value = value;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public ArrayList<Prepaid> listDenom(){
        ArrayList<Prepaid> list=new ArrayList<>();
        list.add(new Prepaid("20.000","20000"));
        list.add(new Prepaid("50.000","50000"));
        list.add(new Prepaid("100.000","100000"));
        list.add(new Prepaid("200.000","200000"));
        list.add(new Prepaid("500.000","500000"));
        list.add(new Prepaid("1.000.000","1000000"));
        return list;
    }

    public ArrayList<NewResultItem> listResultJson(String response){
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            if(rcode.equals("000")||rcode.equals("0000")) {
                JSONObject data = jsonResp.getJSONObject("data");
                String ref_id = data.getString("ref_id");
                String produk = data.getString("type_trans");
                String serial_meter = data.getString("serial_meter");
                //subscriber_id = data.getString("subscriber_id");
                String name = data.getString("name");
                String segment = data.getString("segment");
                String power = data.getString("power");
                String denom = data.getString("denom");

                al.add(new NewResultItem("Produk",":", produk));
                al.add(new NewResultItem("Serial Meter",":", serial_meter));
                al.add(new NewResultItem("Nama Pelanggan",":",name));
                al.add(new NewResultItem("Tarif/Daya",":",segment));
                al.add(new NewResultItem("Daya",":",power));
                if(data.has("kwh")){
                    al.add(new NewResultItem("Kwh",":", data.getString("kwh")));
                }
                al.add(new NewResultItem("Denom",":",df.format(Integer.parseInt(denom))));
                if(data.has("swreff")) {
                    al.add(new NewResultItem("PLN Ref", ":", data.getString("swreff")));
                }
                Wong.setTrxid(ref_id);
            }
        }catch (Exception e){
            al.add(new NewResultItem("Waktu",":",e.getMessage()));
        }finally {
        }
        return al;
    }

    public Map<String,Object> params(String trxid,String noid,String denom){

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","pay");
        map.put("mti","pln_pre");
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        map.put("noid", noid);
        map.put("denom", denom);
        map.put("trxid", trxid);
        return map;
    }

    public String buildStruk(String response){
        String out=null;
        DecimalFormat df=new DecimalFormat("#,##0");
        StringBuilder sb=new StringBuilder();
        try{
            String line ="------------------------------";
            String br=System.getProperty("line.separator");

            JSONObject in = new JSONObject(response);
            JSONObject data = in.getJSONObject("data");

            String ref_id = data.getString("ref_id");
            String time = data.getString("time");
            String serial_meter = data.getString("serial_meter");
            String subscriber_id = data.getString("subscriber_id");
            String name = data.getString("name");
            String segment = data.getString("segment");
            String power = data.getString("power");
            String denom = data.getString("denom");
            String kwh = data.getString("kwh");

            sb.append(TextSpace.rataTengah("PEMBELIAN TOKEN PLN"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Ref     : " + ref_id);
            sb.append("\n");
            sb.append("No Meter   : " + serial_meter);
            sb.append("\n");
            sb.append("ID Pel     : " + subscriber_id);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Tarif/Daya : " + segment + "/" + power);
            sb.append("\n");
            sb.append("Denom      : " + df.format(Integer.parseInt(denom)));
            sb.append("\n");
            sb.append("Biaya Adm  : " +"Rp. "+ df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar: " +"Rp. "+ df.format(data.getInt("amount")));
            sb.append("\n");
            sb.append("kWh        : " + kwh);
            sb.append("\n");
            sb.append(line);
            sb.append(TextSpace.rataTengah("TOKEN"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah(data.getString("token").replaceAll("....", "$0 ")));
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            String msg = "";
            if(data.has("msg")) {
                msg = data.getString("msg");
            }else{
                msg = "PLN menyatakan struk ini sebagai bukti pembayaran yang sah";
            }

            sb.append(TextSpace.rataTengah(msg));//token bonus
            sb.append(br);
            sb.append(TextSpace.rataTengah("CA : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            out = sb.toString();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return out;
    }

    private static String putChar(String text, String insert, int period){
        StringBuilder builder = new StringBuilder(text.length() + insert.length() * (text.length()/period)+1);

        int index = 0;
        String prefix = "";
        while (index < text.length()){
            // Don't put the insert in the very first iteration.
            // This is easier than appending it *after* each substring
            builder.append(prefix);
            prefix = insert;
            builder.append(text.substring(index,
                    Math.min(index + period, text.length())));
            index += period;
        }
        return builder.toString();
    }

    public ArrayList<ResultItem> lapTrans(String resp){
        ArrayList<ResultItem> al=new ArrayList<>();
        String[] arr=resp.split("!");
        String content=arr[1];
        DecimalFormat df=new DecimalFormat("#,##0");

        XmlIn in=new XmlIn();

        String rc=in.getItem(content,"rc");
        if(rc.equals("0000")||rc.equals("000")){
            String trxid=in.getItem(content,"trxid");
            String type_trans=in.getItem(content,"type_trans");
            String desc=in.getItem(content,"desc");
            String merchant=in.getItem(content,"merchant");
            String subscriber_id=in.getItem(content,"subscriber_id");
            String name=in.getItem(content,"name");
            String segment=in.getItem(content,"segment");
            String power=in.getItem(content,"power");



            al.add(new ResultItem("Merchant",merchant));
            al.add(new ResultItem("ID Pel",subscriber_id));
            al.add(new ResultItem("Nama",name));
            al.add(new ResultItem("Tarif",segment));
            al.add(new ResultItem("Daya",power));
            al.add(new ResultItem("",""));

            StringReader reader=null;
            reader=new StringReader(content);

            InputSource source = new InputSource(reader);
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();

            try {
                DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
                Document doc = documentBuilder.parse(source);
                doc.getDocumentElement().normalize();
                NodeList nList = doc.getElementsByTagName("item");

                for (int temp = 0; temp < nList.getLength(); temp++){
                    Node nNode = nList.item(temp);
                    if (nNode.getNodeType() == Node.ELEMENT_NODE){



                        Element eElement = (Element) nNode;
                        String plnreff = eElement.getElementsByTagName("plnreff").item(0).getTextContent();
                        String swreff = eElement.getElementsByTagName("swreff").item(0).getTextContent();
                        String admin = eElement.getElementsByTagName("admin").item(0).getTextContent();
                        String denom = eElement.getElementsByTagName("denom").item(0).getTextContent();
                        String stampduty = eElement.getElementsByTagName("stampduty").item(0).getTextContent();
                        String valueaddedtax = eElement.getElementsByTagName("valueaddedtax").item(0).getTextContent();
                        String lightingtax = eElement.getElementsByTagName("lightingtax").item(0).getTextContent();
                        String installment = eElement.getElementsByTagName("installment").item(0).getTextContent();
                        String power_purchase = eElement.getElementsByTagName("power_purchase").item(0).getTextContent();
                        String kwh = eElement.getElementsByTagName("kwh").item(0).getTextContent();
                        String token = eElement.getElementsByTagName("token").item(0).getTextContent();
                        //token.replaceAll("....", "$0 ");
                        String msg = eElement.getElementsByTagName("msg").item(0).getTextContent();

                        al.add(new ResultItem("","--------------------"));
                        al.add(new ResultItem("Pln Reff",plnreff));
                        al.add(new ResultItem("SW Ref",swreff));
                        al.add(new ResultItem("Admin",df.format(Integer.parseInt(admin))));
                        al.add(new ResultItem("Denom",df.format(Integer.parseInt(denom))));
                        al.add(new ResultItem("Total",df.format(Integer.parseInt(denom)+Integer.parseInt(admin))));
                        al.add(new ResultItem("Stampduty",df.format(Double.parseDouble(stampduty))));
                        al.add(new ResultItem("Tax",df.format(Double.parseDouble(valueaddedtax))));
                        al.add(new ResultItem("Lighting Tax",df.format(Double.parseDouble(lightingtax))));

                        al.add(new ResultItem("Installment",df.format(Double.parseDouble(installment))));
                        al.add(new ResultItem("Power Purchase",df.format(Double.parseDouble(power_purchase))));
                        al.add(new ResultItem("Kwh",kwh));

                        al.add(new ResultItem("Token",token));
                        al.add(new ResultItem("Pesan",msg));

                    }
                }
            }catch (Exception e){
                Log.e("lapcash",e.toString());
            }finally {
                if(reader != null){
                    reader.close();
                }
            }
        }else{
            al.add(new ResultItem("Data tidak ditemukan",""));
        }
        return al;
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d-m-yyyy HH:mm:ss").format(date);
        return formattedDate;
    }

    private String timestampFormattedStruk(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMdd").parse(timestamp.substring(0, 8));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy").format(date);
        return formattedDate;
    }

    public ArrayList<NewResultItem> rePrint(String content) {
        DecimalFormat df=new DecimalFormat("#,##0");
        ArrayList<NewResultItem> al=new ArrayList<>();
        StringBuilder sb=new StringBuilder();
        try{
            String line ="------------------------------";
            String br=System.getProperty("line.separator");

            JSONObject in = new JSONObject(content);
            JSONObject data = in.getJSONObject("data");

            String ref_id = data.getString("ref_id");
            String time = data.getString("time");
            String produk = data.getString("type_trans");
            String serial_meter = data.getString("serial_meter");
            String subscriber_id = data.getString("subscriber_id");
            String name = data.getString("name");
            String segment = data.getString("segment");
            String power = data.getString("power");
            String denom = data.getString("denom");

            al.add(new NewResultItem("Produk",":", produk));
            al.add(new NewResultItem("Serial Meter",":", serial_meter));
            al.add(new NewResultItem("Nama Pelanggan",":",name));
            al.add(new NewResultItem("Tarif/Daya",":",segment));
            al.add(new NewResultItem("Daya",":",power));
            if(data.has("kwh")){
                al.add(new NewResultItem("Kwh",":", data.getString("kwh")));
            }
            al.add(new NewResultItem("Denom",":",df.format(Integer.parseInt(denom))));
            if(data.has("swreff")) {
                al.add(new NewResultItem("PLN Ref", ":", data.getString("swreff")));
            }

            //sb.append("bitplus");
            //sb.append("PEMBELIAN TOKEN PLN");
            sb.append(TextSpace.rataTengah("PEMBELIAN TOKEN PLN"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Ref     : " + ref_id);
            sb.append("\n");
            sb.append("No Meter   : " + serial_meter);
            sb.append("\n");
            sb.append("ID Pel     : " + subscriber_id);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Tarif/Daya : " + segment + "/" + power);
            sb.append("\n");
            sb.append("Denom      : " + df.format(Integer.parseInt(denom)));
            sb.append("\n");
            sb.append("Biaya Adm  : " +"Rp. "+ df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar: " +"Rp. "+ df.format(data.getInt("amount")));
            sb.append("\n");
            sb.append("kWh        : " + data.getString("kwh"));
            sb.append("\n");
            sb.append(line);
            //sb.append("Strm/Token : " + token);
            sb.append(TextSpace.rataTengah("TOKEN"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah(data.getString("token").replaceAll("....", "$0 ")));
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            //sb.append("Terima Kasih");
            //sb.append(TextSpace.rataTengah("Terima Kasih"));
            String msg = "";
            if(data.has("msg")) {
                msg = data.getString("msg");
            }else{
                msg = "PLN menyatakan struk ini sebagai bukti pembayaran yang sah";
            }

            sb.append(TextSpace.rataTengah(msg));//token bonus
            sb.append(br);
            //sb.append("CU : "+ Wong.getIdmerch()+" bitplus Mobile");
            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
        }catch (Exception e) {

        }
        //al.add(new ResultItem("struk",sb.toString()));
        this.setStruk(sb.toString());
        return al;
    }

    private String struk;

    public String getStruk() {
        return struk;
    }

    public void setStruk(String struk) {
        this.struk = struk;
    }
}
