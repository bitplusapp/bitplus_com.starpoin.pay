package com.starpoin.pay.model;

import android.annotation.SuppressLint;

import java.util.concurrent.TimeUnit;

public class CustomRaceData {
    private String noRace;
    private String nama;
    private String tim;
    private long timeDifference;

    public CustomRaceData(String noRace, String nama, String tim, long timeDifference) {
        this.noRace = noRace;
        this.nama = nama;
        this.tim = tim;
        this.timeDifference = timeDifference;
    }

    public String getNoRace() {
        return noRace;
    }

    public void setNoRace(String noRace) {
        this.noRace = noRace;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTim() {
        return tim;
    }

    public void setTim(String tim) {
        this.tim = tim;
    }

    public long getTimeDifference() {
        return timeDifference;
    }

    public void setTimeDifference(long timeDifference) {
        this.timeDifference = timeDifference;
    }
    public String getFormattedTimeDifference() {
        long minutes = TimeUnit.MILLISECONDS.toMinutes(timeDifference);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(timeDifference) - TimeUnit.MINUTES.toSeconds(minutes);
        long milliseconds = timeDifference % 1000;
        return String.format("%02d:%02d:%03d", minutes, seconds, milliseconds);
    }

}
