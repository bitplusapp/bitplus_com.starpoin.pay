package com.starpoin.pay.model;

public class NewResultItem {

    private String title,value,sparator;

    public NewResultItem(){

    }

    public NewResultItem(String title,String separator, String value){
        this.title=title;
        this.sparator=separator;
        this.value=value;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getSparator() {
        return sparator;
    }

    public void setSparator(String sparator) {
        this.sparator = sparator;
    }

}
