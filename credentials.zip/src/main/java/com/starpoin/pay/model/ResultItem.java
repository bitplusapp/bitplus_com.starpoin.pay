package com.starpoin.pay.model;

public class ResultItem {

    private String title,value;

    public ResultItem(){

    }

    public ResultItem(String title,String value){
        this.title=title;
        this.value=value;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
