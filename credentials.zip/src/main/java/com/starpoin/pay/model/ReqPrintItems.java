package com.starpoin.pay.model;

import com.starpoin.pay.util.JsonIn;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class ReqPrintItems {

    private String labelid,noid,nama,tanggal,trxid,pan;

    public String getLabelid() {
        return labelid;
    }

    public void setLabelid(String labelid) {
        this.labelid = labelid;
    }

    public String getNoid() {
        return noid;
    }

    public void setNoid(String noid) {
        this.noid = noid;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }



    public String getTrxid() {
        return trxid;
    }

    public void setTrxid(String trxid) {
        this.trxid = trxid;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }



    public ArrayList<ReqPrintItems> listPrint(String response){
        ArrayList<ReqPrintItems> al=new ArrayList<>();
        String rc=new JsonIn().getString(response,"rc");

        if(rc.equals("0000")||rc.equals("000")){
            try {
                JSONObject res = new JSONObject(response);
                JSONArray data_arr = res.getJSONArray("data");

                for (int temp = 0; temp < data_arr.length(); temp++){
                        String noid = data_arr.getJSONObject(temp).getString("noid");
                        String nama = data_arr.getJSONObject(temp).getString("nama");
                        String tanggal = data_arr.getJSONObject(temp).getString("tanggal");
                        String trxid = data_arr.getJSONObject(temp).getString("trxid");

                        ReqPrintItems e=new ReqPrintItems();
                        e.setLabelid("Nomor ID ");
                        e.setNoid(noid);
                        e.setNama(nama);
                        e.setTanggal(tanggal);
                        e.setTrxid(trxid);
                        String pan=null;
                        try{
                            pan = data_arr.getJSONObject(temp).getString("pan");
                            if(pan==null){
                                pan="0";
                            }
                        }catch (Exception ex){
                            pan="0";
                        }
                        e.setPan(pan);
                        al.add(e);

                    }
            }catch (Exception e){
                e.printStackTrace();
            }finally {
            }
        }
        return al;
    }
}
