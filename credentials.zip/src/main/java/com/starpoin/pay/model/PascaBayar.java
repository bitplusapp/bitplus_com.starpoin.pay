package com.starpoin.pay.model;

import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class PascaBayar {

    private String kode,provider;

    public PascaBayar(){

    }

    public PascaBayar(String kode, String provider) {
        this.kode = kode;
        this.provider = provider;
    }

    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public ArrayList<PascaBayar> listProvider(){
        ArrayList<PascaBayar> list=new ArrayList<>();

        list.add(new PascaBayar("halo","KARTU HALO"));
        list.add(new PascaBayar("xplore","XL PRIORITAS"));
        list.add(new PascaBayar("matrix","I MATRIX"));
        return list;
    }

    public String paramsInq(String noid,String idProduk){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action", "inquiry");
        map.put("productCategory", "telcopasca");
        map.put("productCode", idProduk);
        map.put("customer_no", noid);
        String params= new JSONObject(map).toString();
        return params;
    }

    public Map<String,Object> paramsPay(String trxid, String noid, String additional, Double amount){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","payment");
        map.put("productCategory", "telcopasca");
        map.put("productCode", additional);
        map.put("customer_no", noid);
        map.put("ref_id", trxid);
        map.put("amount", amount);
        return map;
    }

    public ArrayList<NewResultItem> listResultJson(String response){
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            if (rcode.equals("000") || rcode.equals("0000")) {
                JSONObject data = jsonResp.getJSONObject("data");
                String produk = data.getString("type_trans");
                String deskripsi = data.getString("desc");
                String msisdn = data.getString("subscriber_id");
                String name = data.getString("name");
                String periode = data.getString("periode");

                al.add(new NewResultItem("Produk",":", produk));
                al.add(new NewResultItem("Provider",":", deskripsi));
                al.add(new NewResultItem("No Tujuan", ":", msisdn));
                al.add(new NewResultItem("Nama", ":", name));
                al.add(new NewResultItem("Periode", ":", periode));
                if(data.has("swreff")) {
                    al.add(new NewResultItem("BillerRef", ":", data.getString("swreff")));
                }
            }else{
                String desc = jsonResp.getString("message");
                al.add(new NewResultItem("Info", ":", desc));
            }
        }catch (Exception e){
            al.add(new NewResultItem("Waktu",":",e.getMessage()));
        }finally {
        }
        return al;
    }

    public String buildStruk(String content){
        String out=null;
        DecimalFormat df=new DecimalFormat("#,##0");
        StringBuilder sb=new StringBuilder();
        try {
            String line = "------------------------------";
            String br = System.getProperty("line.separator");

            JSONObject in = new JSONObject(content);
            JSONObject data = in.getJSONObject("data");

            String deskripsi = data.getString("desc");
            String msisdn = data.getString("subscriber_id");

            sb.append(TextSpace.rataTengah("PEMBAYARAN PASKABAYAR"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append("Tgl Trans  : " + timestampFormattedStruk(data.getString("time")));
            sb.append("\n");
            sb.append("No Ref     : " + data.getString("ref_id"));
            sb.append("\n");
            sb.append("Nomor HP   : " + msisdn);
            sb.append("\n");
            //sb.append("Produk     : " + product);
            sb.append("Produk     : PASKABAYAR" );
            sb.append("\n");
            sb.append("Admin      : "+ df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar: "+ df.format(data.getInt("amount")));
            sb.append("\n");
            sb.append("Keterangan : " +deskripsi);
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);

            sb.append(TextSpace.rataTengah("CA : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            out = sb.toString();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return out;
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d-m-yyyy HH:mm:ss").format(date);
        return formattedDate;
    }

    private String timestampFormattedStruk(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMdd").parse(timestamp.substring(0, 8));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy").format(date);
        return formattedDate;
    }

    public ArrayList<NewResultItem> rePrint(String content) {
        DecimalFormat df=new DecimalFormat("#,##0");
        ArrayList<NewResultItem> al=new ArrayList<>();
        StringBuilder sb=new StringBuilder();
        try {
            String line = "------------------------------";
            String br = System.getProperty("line.separator");

            JSONObject in = new JSONObject(content);
            JSONObject data = in.getJSONObject("data");

            String produk = data.getString("type_trans");
            String deskripsi = data.getString("desc");
            String msisdn = data.getString("subscriber_id");
            String name = data.getString("name");
            String periode = data.getString("periode");

            al.add(new NewResultItem("Produk",":", produk));
            al.add(new NewResultItem("Provider",":", deskripsi));
            al.add(new NewResultItem("No Tujuan", ":", msisdn));
            al.add(new NewResultItem("Nama", ":", name));
            al.add(new NewResultItem("Periode", ":", periode));
            if(data.has("swreff")) {
                al.add(new NewResultItem("BillerRef", ":", data.getString("swreff")));
            }


            sb.append(TextSpace.rataTengah("PEMBAYARAN PASKABAYAR"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append("Tgl Trans  : " + timestampFormattedStruk(data.getString("time")));
            sb.append("\n");
            sb.append("No Ref     : " + data.getString("ref_id"));
            sb.append("\n");
            sb.append("Nomor HP   : " + msisdn);
            sb.append("\n");
            //sb.append("Produk     : " + product);
            sb.append("Produk     : PASKABAYAR" );
            sb.append("\n");
            sb.append("Admin      : "+ df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar: "+ df.format(data.getInt("amount")));
            sb.append("\n");
            sb.append("Keterangan : " +deskripsi);
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);

            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
        }catch (Exception e) {
            e.printStackTrace();
        }

        this.setStruk(sb.toString());
        return al;
    }

    private String struk;

    public String getStruk() {
        return struk;
    }

    public void setStruk(String struk) {
        this.struk = struk;
    }
}
