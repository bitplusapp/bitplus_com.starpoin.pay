package com.starpoin.pay.model;

import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;
import com.starpoin.pay.util.XmlIn;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Nontaglis {

    public Map<String,Object> paramsInq(String noid){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","inquiry");
        map.put("productCategory", "pln");
        map.put("productCode", "nontaglis");
        map.put("customer_no", noid);
        return map;
    }

    public Map<String,Object> paramsPay(String trxid, String noid, Double amount){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","payment");
        map.put("productCategory", "pln");
        map.put("productCode", "nontaglis");
        map.put("customer_no", noid);
        map.put("ref_id", trxid);
        map.put("amount", amount);
        return map;
    }

    public ArrayList<NewResultItem> listResultJson(String response){
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            if(rcode.equals("000")||rcode.equals("0000")){
                DecimalFormat df=new DecimalFormat("#,##0");
                JSONObject data = jsonResp.getJSONObject("data");

                String reg_no = data.getString("reg_no");
                String subscriber_id = data.getString("subscriber_id");
                String name = data.getString("name");
                String transaction = data.getString("transaction");
                String reg_date = data.getString("reg_date");
                String rptag = data.getString("bill");

                al.add(new NewResultItem("No Registrasi",":", reg_no));
                al.add(new NewResultItem("ID Pelanggan",":",subscriber_id));
                al.add(new NewResultItem("Nama Pelanggan",":",name));
                al.add(new NewResultItem("Transaksi",":",transaction));
                al.add(new NewResultItem("Tgl Registrasi",":",reg_date));
                al.add(new NewResultItem("Tagihan PLN",":",df.format(Integer.parseInt(rptag))));
                if(data.has("swreff")) {
                    al.add(new NewResultItem("PLN Ref", ":", data.getString("swreff")));
                }
            }
        }catch (Exception e){
            al.add(new NewResultItem("Waktu",":",e.getMessage()));
        }finally {
        }
        return al;
    }

    private String timestampFormattedStruk(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMdd").parse(timestamp.substring(0, 8));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy").format(date);
        return formattedDate;
    }

    public String buildStruk(String response)  {
        String out=null;
        DecimalFormat df=new DecimalFormat("#,##0");
        StringBuilder sb=new StringBuilder();
        try {
            String line = "------------------------------";
            String br = System.getProperty("line.separator");

            JSONObject in = new JSONObject(response);
            JSONObject data = in.getJSONObject("data");

            String reg_no = data.getString("reg_no");
            String time = data.getString("time");
            String subscriber_id = data.getString("subscriber_id");
            String name = data.getString("name");
            String transaction = data.getString("transaction");
            String reg_date = data.getString("reg_date");

            sb.append(TextSpace.rataTengah("PEMBAYARAN PLN"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Reg     : " + reg_no);
            sb.append("\n");
            sb.append("Tgl Reg    : " + reg_date);
            sb.append("\n");
            sb.append("ID Pel     : " + subscriber_id);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Keterangan : " + transaction);
            sb.append("\n");
            sb.append("PLN        : " + df.format(data.getInt("bill")));
            sb.append("\n");
            sb.append("Biaya Adm  : " + df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar: " + df.format(data.getInt("amount")));
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("CA : " + Wong.getIdmerch() + " bitplus Mobile"));
            sb.append(br);
            out = sb.toString();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return out;
    }

    public ArrayList<ResultItem> lapTrans(String resp){
        String[] arr=resp.split("!");
        String content=arr[1];
        DecimalFormat df=new DecimalFormat("#,##0");
        ArrayList<ResultItem> al=new ArrayList<>();

        XmlIn in=new XmlIn();

        String rc=in.getItem(content,"rc");
        if(rc.equals("0000")||rc.equals("000")){
            String trxid=in.getItem(content,"trxid");
            String type_trans=in.getItem(content,"type_trans");
            String desc=in.getItem(content,"desc");
            String merchant=in.getItem(content,"merchant");
            String reg_no=in.getItem(content,"reg_no");
            String subscriber_id=in.getItem(content,"subscriber_id");
            String name=in.getItem(content,"name");
            String transaction=in.getItem(content,"transaction");
            String reg_date=in.getItem(content,"reg_date");
            String admin=in.getItem(content,"admin");
            String amount_bill=in.getItem(content,"amount_bill");

            al.add(new ResultItem("Merchant",merchant));
            al.add(new ResultItem("Reg No",reg_no));
            al.add(new ResultItem("ID Pel",subscriber_id));
            al.add(new ResultItem("Nama",name));
            al.add(new ResultItem("Transaction",transaction));
            al.add(new ResultItem("Reg Date",reg_date));
            al.add(new ResultItem("Admin",df.format(Integer.parseInt(admin))));
            al.add(new ResultItem("Total",df.format(Integer.parseInt(amount_bill))));
        }else{
            al.add(new ResultItem("Data tidak ditemukan",""));
        }
        return al;
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d-m-yyyy HH:mm:ss").format(date);
        return formattedDate;
    }

    public ArrayList<NewResultItem> rePrint(String content){
        DecimalFormat df=new DecimalFormat("#,##0");
        ArrayList<NewResultItem> al=new ArrayList<>();
        StringBuilder sb=new StringBuilder();
        try {
            String line = "------------------------------";
            String br = System.getProperty("line.separator");

            JSONObject in = new JSONObject(content);
            JSONObject data = in.getJSONObject("data");

            String reg_no = data.getString("reg_no");
            String time = data.getString("time");
            String subscriber_id = data.getString("subscriber_id");
            String name = data.getString("name");
            String transaction = data.getString("transaction");
            String reg_date = data.getString("reg_date");
            String rptag = data.getString("bill");

            al.add(new NewResultItem("No Registrasi",":", reg_no));
            al.add(new NewResultItem("ID Pelanggan",":",subscriber_id));
            al.add(new NewResultItem("Nama Pelanggan",":",name));
            al.add(new NewResultItem("Transaksi",":",transaction));
            al.add(new NewResultItem("Tgl Registrasi",":",reg_date));
            al.add(new NewResultItem("Tagihan PLN",":",df.format(Integer.parseInt(rptag))));
            if(data.has("swreff")) {
                al.add(new NewResultItem("PLN Ref", ":", data.getString("swreff")));
            }

            sb.append(TextSpace.rataTengah("PEMBAYARAN PLN"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Reg     : " + reg_no);
            sb.append("\n");
            sb.append("Tgl Reg    : " + reg_date);
            sb.append("\n");
            sb.append("ID Pel     : " + subscriber_id);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Keterangan : " + transaction);
            sb.append("\n");
            sb.append("PLN        : " + df.format(data.getInt("bill")));
            sb.append("\n");
            sb.append("Biaya Adm  : " + df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar: " + df.format(data.getInt("amount")));
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            //sb.append("Terima Kasih");
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append("\n");
            //sb.append("CU : "+ Wong.getIdmerch()+" bitplus Mobile");
            sb.append(TextSpace.rataTengah("CU : " + Wong.getIdmerch() + " bitplus Mobile"));
            sb.append(br);
        }catch (Exception e) {
            e.printStackTrace();
        }
        this.setStruk(sb.toString());
        return al;
    }

    private String struk;

    public String getStruk() {
        return struk;
    }

    public void setStruk(String struk) {
        this.struk = struk;
    }
}
