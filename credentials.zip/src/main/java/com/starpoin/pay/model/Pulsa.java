package com.starpoin.pay.model;

import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;
import com.starpoin.pay.util.XmlIn;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Pulsa {

    private String provider,desc,kode,idsw;

    public Pulsa(){

    }

    public Pulsa(String provider, String desc, String kode,String idsw) {
        this.provider = provider;
        this.desc = desc;
        this.kode = kode;
        this.idsw=idsw;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getIdsw() {
        return idsw;
    }

    public void setIdsw(String idsw) {
        this.idsw = idsw;
    }

    public String paramsProvider(String noid,String type){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","list_produk_provider");
        map.put("noid",noid);
        map.put("provider","0");
        map.put("type_produk",type);
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        String params="Trans"+new Params().buildParams(map);
        return params;
    }

    public ArrayList<Pulsa> pulsaDenom(String content) {
        ArrayList<Pulsa> al=new ArrayList<>();
            try {
                JSONArray arr_data = new JSONArray(content);
                if(arr_data != null) {
                    for (int i = 0; i < arr_data.length(); i++) {
                        JSONObject response = new JSONObject(arr_data.get(i).toString());
                        String namaProvider = response.getString("name");
                        String kode = response.getString("additional_code");
                        String keterangan = response.getString("description");
                        String sw = response.getString("request_format");
                        Pulsa pulsa = new Pulsa(namaProvider, keterangan, kode, sw);
                        al.add(pulsa);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        return al;
    }

    public Map<String,Object> paramsInq(String noid,String idProduk,String type) {
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","inquiry");
        map.put("productCategory", "voucher");
        map.put("productCode", type);
        map.put("customer_no", noid);
        map.put("additional", idProduk);
        return map;
    }

    public Map<String,Object> paramsPay(String trxid, String noid, String code_voucher, Double amount, String type){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","payment");
        map.put("productCategory", "voucher");
        map.put("productCode", type);
        map.put("customer_no", noid);
        map.put("additional", code_voucher);
        map.put("ref_id", trxid);
        map.put("amount", amount);
        return map;
    }

    public ArrayList<NewResultItem> listResultJson(String response) {
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            if (rcode.equals("0000") || rcode.equals("0005")) {
                JSONObject data = jsonResp.getJSONObject("data");
                String ref_id = data.getString("ref_id");
                String produk = data.getString("type_trans");
                String msisdn = data.getString("subscriber_id");
                String provider = data.getString("voucher_name");
                String provider_code = data.getString("voucher_code");
                String provider_type = data.getString("voucher_category");
                String provider_desc = data.getString("desc");

                al.add(new NewResultItem("Produk",":", produk));
                al.add(new NewResultItem("Tipe Voucher",":",provider_type));
                al.add(new NewResultItem("Provider",":", provider));
                al.add(new NewResultItem("No Tujuan", ":", msisdn));
                al.add(new NewResultItem("Keterangan",":",provider_code.toUpperCase() +" - "+provider_desc));
            }else{
                String desc = jsonResp.getString("message");
                al.add(new NewResultItem("Info", ":", desc));
            }
        }catch (Exception e){
            al.add(new NewResultItem("Waktu",":",e.getMessage()));
        }finally {
        }
        return al;
    }

    private String timestampFormattedStruk(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMdd").parse(timestamp.substring(0, 8));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy").format(date);
        return formattedDate;
    }

    public String buildStruk(String response) {
        String out=null;
        StringBuilder sb=new StringBuilder();
        try {
            String line = "------------------------------";
            String br = System.getProperty("line.separator");

            JSONObject in = new JSONObject(response);
            JSONObject data = in.getJSONObject("data");

            String noref = data.getString("ref_id");
            String time = data.getString("time");
            String produk = data.getString("type_trans");
            String msisdn = data.getString("subscriber_id");
            String provider = data.getString("voucher_name");
            String provider_code = data.getString("voucher_code");
            String provider_type = data.getString("voucher_category");
            String provider_desc = data.getString("desc");

            sb.append(TextSpace.rataTengah("PEMBELIAN VOUCHER"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append("Tgl Trans    : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Ref       : " + noref);
            sb.append("\n");
            sb.append("Nomor Tujuan : " + msisdn);
            sb.append("\n");
            sb.append("Produk       : " + provider_type );
            sb.append("\n");

            sb.append("Keterangan : " +provider_code.toUpperCase() +" - "+provider_desc);
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);

            sb.append(TextSpace.rataTengah("CA : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            out = sb.toString();
        }catch (Exception e) {
            e.printStackTrace();
        }

        return out;
    }

    public ArrayList<Pulsa> listDenomPulsa(ArrayList<ProdukProvider> list,String subno,String type_produk){
        ArrayList<Pulsa> denomList=new ArrayList<>();
        String providerTmp="",typeTmp="";

        for(ProdukProvider prod:list){
            provider=prod.getProvider();
            kode=prod.getKode();
            desc=prod.getDesc_produk();
            idsw=prod.getIdsw();
            String prefix=prod.getPrefix().trim();
            String type=prod.getType_produk();
            String[] arr=prefix.split(",");
            int arrSize=arr.length;
            if(arrSize>0){
                for(int i=0; i<arrSize; i++){
                    String nopref=arr[i].trim();
                    if(subno.equals(nopref) ){
                        Pulsa pul=new Pulsa(provider,desc,kode,idsw);
                        denomList.add(pul);
                        providerTmp=provider;
                        typeTmp=type;
                    }
                }
            }


        }
        return denomList;
    }

    public ArrayList<ResultItem> lapTrans(String resp){

        String content=resp;
        ArrayList<ResultItem> al=new ArrayList<>();
        XmlIn in=new XmlIn();
        String rc=in.getItem(content,"rc");
        if(rc.equals("0000")||rc.equals("000")){
            DecimalFormat df=new DecimalFormat("#,##0");

            String trxid=in.getItem(content,"trxid");
            String type_trans=in.getItem(content,"type_trans");

            String desc=in.getItem(content,"desc");
            String merchant=in.getItem(content,"merchant");
            String subscriber_id=in.getItem(content,"noid");
            String codeproduct=in.getItem(content,"codeproduct");
            String product=in.getItem(content,"product");
            String descproduct=in.getItem(content,"descproduct");
            String reffno=in.getItem(content,"reffno");
            String adminfee=in.getItem(content,"adminfee");

            String amount=in.getItem(content,"amount");
            String cashback=in.getItem(content,"cashback");
            String bill_merchant=in.getItem(content,"bill_merchant");



            al.add(new ResultItem("Merchant",merchant));
            al.add(new ResultItem("No Msisdn",subscriber_id));
            al.add(new ResultItem("Product",product));
            al.add(new ResultItem("Desc",descproduct));
            al.add(new ResultItem("VCode",reffno));
            al.add(new ResultItem("Admin",df.format(Integer.parseInt(adminfee))));
            al.add(new ResultItem("Total",df.format(Integer.parseInt(amount))));
            //al.add(new ResultItem("Cashback",df.format(Integer.parseInt(cashback))));
            //al.add(new ResultItem("Bill Merchant",df.format(Integer.parseInt(bill_merchant))));
        }else{
            al.add(new ResultItem("Data tidak ditemukan",""));
        }

        return al;
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d-m-yyyy HH:mm:ss").format(date);
        return formattedDate;
    }

    public ArrayList<NewResultItem> rePrint(String resp){
        ArrayList<NewResultItem> al=new ArrayList<>();
        StringBuilder sb=new StringBuilder();
        try {
            String line = "------------------------------";
            String br = System.getProperty("line.separator");

            JSONObject in = new JSONObject(resp);
            JSONObject data = in.getJSONObject("data");

            String noref = data.getString("ref_id");
            String time = data.getString("time");
            String produk = data.getString("type_trans");
            String msisdn = data.getString("subscriber_id");
            String provider = data.getString("voucher_name");
            String provider_code = data.getString("voucher_code");
            String provider_type = data.getString("voucher_category");
            String provider_desc = data.getString("desc");

            al.add(new NewResultItem("Produk",":", produk));
            al.add(new NewResultItem("Tipe Voucher",":",provider_type));
            al.add(new NewResultItem("Provider",":", provider));
            al.add(new NewResultItem("No Tujuan", ":", msisdn));
            al.add(new NewResultItem("Keterangan",":",provider_code.toUpperCase() +" - "+provider_desc));


            sb.append(TextSpace.rataTengah("PEMBELIAN VOUCHER"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Ref     : " + noref);
            sb.append("\n");
            sb.append("Nomor HP   : " + msisdn);
            sb.append("\n");
            //sb.append("Produk     : " + product);
            sb.append("Produk     : Pulsa" );
            sb.append("\n");

            sb.append("Keterangan : " +provider_code.toUpperCase() +" - "+provider_desc);
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);

            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
        }catch (Exception e) {
            e.printStackTrace();
        }

        this.setStruk(sb.toString());

        return al;
    }

    private String struk;

    public String getStruk() {
        return struk;
    }

    public void setStruk(String struk) {
        this.struk = struk;
    }
}
