package com.starpoin.pay.model;

public class Param {

    private String trxid,noid,kode;
    //private String denom;
    private String idsw;

    public Param(){

    }

    //non pdam
    public Param(String trxid, String noid, String kode) {
        this.trxid = trxid;
        this.noid = noid;
        this.kode=kode;
    }



    public String getTrxid() {
        return trxid;
    }

    public void setTrxid(String trxid) {
        this.trxid = trxid;
    }

    public String getNoid() {
        return noid;
    }

    public void setNoid(String noid) {
        this.noid = noid;
    }

    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getIdsw() {
        return idsw;
    }

    public void setIdsw(String idsw) {
        this.idsw = idsw;
    }


}
