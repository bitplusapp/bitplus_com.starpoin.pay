package com.starpoin.pay.model;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.R;
import com.starpoin.pay.ReprintActivity;
import com.starpoin.pay.ResponseActivity;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.PrinterTask;
import com.starpoin.pay.util.Produk;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;

public class Response {

    public String getProductMessage(int produk, String customBiller) {
        String msg = "";
        switch (produk) {
            case Produk.POSTPAID:
            case Produk.PREPAID:
            case Produk.NONTAGLIS:
                msg = "PLN menyatakan struk ini sebagai bukti pembayaran yang sah";
                break;
            case Produk.VOUCHER:
            case Produk.PASCABAYAR:
            case Produk.TOPUP:
            case Produk.GAME:
                msg = "Struk ini hanya sebagai bukti pembelian, mohon disimpan";
                break;
            case Produk.PDAM:
            case Produk.PDAMBATANG:
                msg = "PDAM menyatakan struk ini sebagai bukti pembayaran yang sah";
                break;
            case Produk.BPJS:
                msg = "BPJS menyatakan struk ini sebagai bukti pembayaran yang sah";
                break;
            case Produk.JASTEL:
                msg = "Telkom menyatakan struk ini sebagai bukti pembayaran yang sah";
                break;
            case Produk.PBB:
                msg = "BPD "+customBiller+" menyatakan struk ini sebagai bukti pembayaran yang sah";
                break;
            default:
                msg = "Struk ini sebagai bukti pembelian, mohon disimpan";
                break;
        }
        return msg;
    }

    public String getExtraString(Activity activity,String key){
        String out=null;
        try {
            out=activity.getIntent().getExtras().getString(key);
        }catch (Exception e){
            out="0";
        }
        return out;
    }

    public int getExtraInt(Activity activity,String key){
        int out=0;
        try {
            out=activity.getIntent().getExtras().getInt(key);
        }catch (Exception e){
            out=0;
        }
        return out;
    }

    public double getExtraDouble(Activity activity,String key){
        double out=0;
        try {
            out=activity.getIntent().getExtras().getDouble(key);
        }catch (Exception e){
            out=0;
        }
        return out;
    }

    public ArrayList<ResultItem> listResult(int produk,String result){
        ArrayList<ResultItem> al = null;
        return al;
    }

    public ArrayList<NewResultItem> NewlistResult(int produk,String result){
        ArrayList<NewResultItem> al = null;
        switch (produk) {
            case Produk.POSTPAID:
                al=new Postpaid().listResultJson(result); //json
                break;
            case Produk.PREPAID:
                al=new Prepaid().listResultJson(result); //json
                break;
            case Produk.NONTAGLIS:
                al=new Nontaglis().listResultJson(result);
                break;
            case Produk.PULSA:
            case Produk.GAME:
            case Produk.PAKETDATA:
            case Produk.TOPUP:
                al=new Pulsa().listResultJson(result);
                break;
            case Produk.JASTEL:
                al=new Telkom().listResultJson(result);
                break;
            case Produk.BPJS:
                al=new Bpjs().listResultJson(result);
                break;
            case Produk.PDAM:
            case Produk.PDAMBATANG:
                al=new Pdam().listResultJson(result);
                break;
            case Produk.PASCABAYAR:
                al=new PascaBayar().listResultJson(result);
                break;
            case Produk.PBB:
                al=new Pbb().listResult(result);
                break;
            case Produk.TVCABLE:
                al=new InternetTvCable().listResultJson(result);
                break;
        }
        return al;
    }

    public Map<String, Object> paramsPay(int produk, String noid, String ref_id, String additional, Double amount) {
        Map<String, Object> map = null;
        switch (produk){
            case Produk.POSTPAID:
                map=new Postpaid().paramsPay(ref_id, noid, amount);
                break;
            case Produk.PREPAID:
                map=new Prepaid().paramsPay(ref_id, noid, additional, amount);
                break;
            case Produk.NONTAGLIS:
                map=new Nontaglis().paramsPay(ref_id, noid, amount);
                break;
            case Produk.PULSA:
                map=new Pulsa().paramsPay(ref_id, noid, additional, amount, "pulsa");
                break;
            case Produk.GAME:
                map=new Pulsa().paramsPay(ref_id, noid, additional, amount, "game");
                break;
            case Produk.PAKETDATA:
                map=new Pulsa().paramsPay(ref_id, noid, additional, amount, "data");
                break;
            case Produk.TOPUP:
                map=new Pulsa().paramsPay(ref_id, noid, additional, amount, "topup");
                break;
            case Produk.JASTEL:
                map=new Telkom().paramsPay(ref_id, noid, amount);
                break;
            case Produk.TVCABLE:
                map= new InternetTvCable().paramsPay(ref_id, noid, additional, amount);
                break;
            case Produk.BPJS:
                map=new Bpjs().paramsPay(ref_id, noid, additional, amount);
                break;
            case Produk.PDAM:
            case Produk.PDAMBATANG:
                map=new Pdam().paramsPay(ref_id, noid, additional, amount);
                break;
            case Produk.PASCABAYAR:
                map=new PascaBayar().paramsPay(ref_id, noid, additional, amount);
                break;
            case Produk.PBB:
                map=new Pbb().paramsPay(ref_id, noid, additional, amount);
                break;
        }
        return map;
    }

    public String buildStruk(int produk, String content){
        String out=null;
        switch (produk){
            case Produk.POSTPAID:
                out=new Postpaid().buildStruk(content);
                break;
            case Produk.PREPAID:
                out=new Prepaid().buildStruk(content);
                break;
            case Produk.NONTAGLIS:
                out=new Nontaglis().buildStruk(content);
                break;
            case Produk.PULSA:
            case Produk.PAKETDATA:
            case Produk.GAME:
            case Produk.TOPUP:
                out=new Pulsa().buildStruk(content);
                break;
            case Produk.PASCABAYAR:
                out=new PascaBayar().buildStruk(content);
                break;
            case Produk.PDAM:
                out=new Pdam().buildStruk(content);
                break;
            case Produk.PDAMBATANG:
                out=new Pdam().buildStruk(content);
                break;
            case Produk.JASTEL:
                out=new Telkom().buildStruk(content);
                break;
            case Produk.BPJS:
                out=new Bpjs().buildStruk(content);
                break;
            case Produk.PBB:
                out=new Pbb().buildStruk(content);
                break;
            case Produk.TVCABLE:
                out=new InternetTvCable().buildStruk(content);
                break;
        }
        return out;
    }

    private Bitmap screenShot(View view, int width, int height) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null)
            bgDrawable.draw(canvas);
        else
            canvas.drawColor(Color.parseColor("#DFE7EE"));
        view.draw(canvas);
        return bitmap;
    }

    public void paySuksesShareList(ResponseActivity activity, ProgressBar pbar, String struk, ScrollView scrollView) {
        Bitmap strukBitmap = screenShot(scrollView, scrollView.getWidth(), scrollView.getChildAt(0).getHeight());
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(activity, R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.share_layout);

        LinearLayout printLayout = bottomSheetDialog.findViewById(R.id.layoutPrint);
        LinearLayout whatsappLayout = bottomSheetDialog.findViewById(R.id.layoutWhatsapp);
        LinearLayout shareLayout = bottomSheetDialog.findViewById(R.id.layoutShare);

        printLayout.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View v) {

                BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ECLAIR) {
                    if (!btAdapter.isEnabled()) {
                        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        activity.startActivityForResult(enableBtIntent,2);
                    }else{
                        cetakStruk(activity,pbar, struk);
                    }
                }
                bottomSheetDialog.dismiss();
            }
        });



        whatsappLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendViaWhatsAppAsImage(activity,strukBitmap);
                bottomSheetDialog.dismiss();
            }
        });

        shareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendViaAsBitmap(activity, strukBitmap);
                bottomSheetDialog.dismiss();
            }
        });

        bottomSheetDialog.show();
    }

    public void rePrint(ReprintActivity activity, ProgressBar pbar,  String struk, ScrollView scrollView) {
        Bitmap strukBitmap = screenShot(scrollView, scrollView.getWidth(), scrollView.getChildAt(0).getHeight());
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(activity, R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.share_layout);

        LinearLayout printLayout = bottomSheetDialog.findViewById(R.id.layoutPrint);
        LinearLayout whatsappLayout = bottomSheetDialog.findViewById(R.id.layoutWhatsapp);
        LinearLayout shareLayout = bottomSheetDialog.findViewById(R.id.layoutShare);

        printLayout.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View v) {

                BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ECLAIR) {
                    if (!btAdapter.isEnabled()) {
                        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        activity.startActivityForResult(enableBtIntent,2);


                    }else{

                        //cetakStruk(struk);
                        //final ProgressBar pbar=new PBar(activity,activity.findViewById(R.id.rootLayout));
                        cetakStruk(activity,pbar,struk);
                    }
                }
                bottomSheetDialog.dismiss();
            }
        });

        whatsappLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //sendViaWhatsApp(struk);
                sendViaWhatsAppAsImage(activity,strukBitmap);
                bottomSheetDialog.dismiss();
            }
        });

        shareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendViaAsBitmap(activity, strukBitmap);
                bottomSheetDialog.dismiss();
            }
        });

        bottomSheetDialog.show();
    }

    public void cetakStruk(Activity activity,ProgressBar pbar,String struk){

        PrinterTask task = new PrinterTask(activity,activity, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                if(!content.equals("1")){
                    Response.this.showMsg(activity,content);
                }
            }

            @Override
            public void onFailure(Exception e) {
                Response.this.showMsg(activity,e.getMessage());
            }

        });
        task.execute(struk);
    }

    public void sendViaWhatsApp(Activity activity,String messages) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.setPackage("com.whatsapp");
        sendIntent.putExtra(Intent.EXTRA_TEXT, messages);
        sendIntent.setType("text/plain");

        try {
            activity.startActivity(sendIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            //Toast.makeText(PrintActivity.this, "WhatsApp belum di install.", Toast.LENGTH_SHORT).show();
        }
    }

    public void sendViaWhatsAppAsImage(Activity activity, Bitmap bitmap) {
        String pathofBmp= MediaStore.Images.Media.insertImage(activity.getContentResolver(),
                        bitmap,"IMG_" + Calendar.getInstance().getTime(), null);
        Uri uri = Uri.parse(pathofBmp);
        System.out.println(uri.toString());
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.setPackage("com.whatsapp");
        sendIntent.putExtra(Intent.EXTRA_STREAM, uri);
        sendIntent.setType("image/*");

        try {
            activity.startActivity(sendIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            //Toast.makeText(PrintActivity.this, "WhatsApp belum di install.", Toast.LENGTH_SHORT).show();
        }
    }

    public void sendViaAsBitmap(Activity activity, Bitmap bitmap){
        String pathofBmp= MediaStore.Images.Media.insertImage(activity.getContentResolver(),
                bitmap,"IMG_" + Calendar.getInstance().getTime(), null);
        Uri uri = Uri.parse(pathofBmp);
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_STREAM, uri);
        sendIntent.setType("image/*");
        activity.startActivity(sendIntent);
    }

    public void sendVia(Activity activity,String message){
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, message);
        sendIntent.setType("text/plain");
        activity.startActivity(sendIntent);
    }

    public void showMsg(Activity activity,String msg){

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(activity, R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.msg_dialog);
        Button btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });

        TextView tvError=bottomSheetDialog.findViewById(R.id.tvError);
        tvError.setText(msg);

        bottomSheetDialog.show();

    }
}
