package com.starpoin.pay.model;

import com.starpoin.pay.util.DateParse;
import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;
import com.starpoin.pay.util.XmlIn;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class Telkom {

    public Map<String,Object> paramsInq(String noid){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","inquiry");
        map.put("productCategory","inetv");
        map.put("productCode","telkom");
        map.put("customer_no",noid);
        return map;
    }

    public Map<String,Object> paramsPay(String trxid,String noid, Double amount){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","payment");
        map.put("productCategory", "inetv");
        map.put("productCode", "telkom");
        map.put("customer_no", noid);
        map.put("ref_id", trxid);
        map.put("amount", amount);
        return map;
    }

    public ArrayList<ResultItem> listResult(String response){
        ArrayList<ResultItem> al=new ArrayList<>();
        StringReader reader=null;
        reader=new StringReader(response);
        //InputSource source = new InputSource(new StringReader(response));
        InputSource source = new InputSource(reader);
        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DecimalFormat df=new DecimalFormat("#,##0");
        try {
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document doc = documentBuilder.parse(source);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("trx_response");
            Node nNode = nList.item(0);
            Element eElement = (Element) nNode;
            String rcode = eElement.getElementsByTagName("rc").item(0).getTextContent();

            if(rcode.equals("000")||rcode.equals("0000")){
                String trxid = eElement.getElementsByTagName("trxid").item(0).getTextContent();
                String produk = eElement.getElementsByTagName("produk").item(0).getTextContent();
                String noid = eElement.getElementsByTagName("noid").item(0).getTextContent();
                String nama = eElement.getElementsByTagName("nama").item(0).getTextContent();
                String stan = eElement.getElementsByTagName("stan").item(0).getTextContent();
                String noref = eElement.getElementsByTagName("noref").item(0).getTextContent();
                String blth = eElement.getElementsByTagName("blth").item(0).getTextContent();
                String bill = eElement.getElementsByTagName("bill").item(0).getTextContent();
                String rptag = eElement.getElementsByTagName("tagihan").item(0).getTextContent();
                String adm = eElement.getElementsByTagName("adminfee").item(0).getTextContent();
                String cashback = eElement.getElementsByTagName("cashback").item(0).getTextContent();
                String bill_merchant = eElement.getElementsByTagName("bill_merchant").item(0).getTextContent();
                String amount = eElement.getElementsByTagName("amount").item(0).getTextContent();
                String time = eElement.getElementsByTagName("time").item(0).getTextContent();
                String ftime=new DateParse().parse(time);

                al.add(new ResultItem("No ID",noid));
                al.add(new ResultItem("Nama",nama));
                al.add(new ResultItem("Stan",stan));
                al.add(new ResultItem("Produk",produk));
                al.add(new ResultItem("No Ref",noref));
                al.add(new ResultItem("Jumlah Bulan",bill));
                al.add(new ResultItem("Bulan",blth));
                al.add(new ResultItem("Tagihan",df.format(Integer.parseInt(rptag))));
                al.add(new ResultItem("Admin Bank",df.format(Integer.parseInt(adm))));
                al.add(new ResultItem("Total",df.format(Integer.parseInt(amount))));
                al.add(new ResultItem("Komisi",df.format(Integer.parseInt(cashback))));
                al.add(new ResultItem("Pemotongan Saldo",df.format(Integer.parseInt(bill_merchant))));
                al.add(new ResultItem("Waktu Transaksi",ftime));



            }

        }catch (Exception e){
            //System.out.print(e.toString());
        }finally {
            if(reader != null){
                reader.close();
            }
        }
        return al;
    }

    public ArrayList<NewResultItem> listResultJson(String response){
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            //Log.d("rcode",rcode);
            if(rcode.equals("000")||rcode.equals("0000")){
                DecimalFormat df=new DecimalFormat("#,##0");
                JSONObject data = jsonResp.getJSONObject("data");
                JSONArray listTagihan = data.getJSONArray("detail");
                String produk = data.getString("type_trans");
                String subscriber_id = data.getString("subscriber_id");
                String name = data.getString("name");
                String periode = data.getString("periode");
                String bill = data.getString("bill");

                al.add(new NewResultItem("Produk",":", produk));
                al.add(new NewResultItem("ID Pelanggan",":",subscriber_id));
                al.add(new NewResultItem("Nama Pelanggan",":",name));
                al.add(new NewResultItem("Periode",":", periode));

                if(data.has("swreff")) {
                    al.add(new NewResultItem("Biller Ref", ":", data.getString("swreff")));
                }

                int NoDetail = 1;
                for (int i = 0; i < listTagihan.length(); i++) {
                    al.add(new NewResultItem("","",""));
                    al.add(new NewResultItem("-","Tagihan "+(NoDetail),"-"));;
                    String periode_bill = listTagihan.getJSONObject(i).getString("periode");
                    String rptag = listTagihan.getJSONObject(i).getString("tagihan");
                    al.add(new NewResultItem("Periode", ":", periode_bill));
                    al.add(new NewResultItem("Rptag", ":", df.format(Integer.parseInt(rptag))));
                    NoDetail++;
                }
            }
        }catch (Exception e){
            al.add(new NewResultItem("Waktu",":",e.getMessage()));
        }finally {
        }
        return al;
    }

    private String timestampFormattedStruk(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMdd").parse(timestamp.substring(0, 8));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy").format(date);
        return formattedDate;
    }

    public String buildStruk(String response)  {
        String out = null;
        DecimalFormat df=new DecimalFormat("#,##0");
        StringBuilder sb=new StringBuilder();
        try {
            String line = "------------------------------";
            String br = System.getProperty("line.separator");

            JSONObject in = new JSONObject(response);
            JSONObject data = in.getJSONObject("data");
            JSONArray listTagihan = data.getJSONArray("detail");

            String time = data.getString("time");
            String subscriber_id = data.getString("subscriber_id");
            String name = data.getString("name");
            String periode = data.getString("periode");
            String bill = data.getString("bill");

            int tagihan = 0;
            for (int i = 0; i < listTagihan.length(); i++) {
                tagihan += listTagihan.getJSONObject(i).getInt("tagihan");
            }

            sb.append(TextSpace.rataTengah("PEMBAYARAN TELKOM"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("Nomor ID   : " + subscriber_id);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Bill       : " + bill);
            sb.append("\n");
            sb.append("Blth       : " + periode);
            sb.append("\n");
            sb.append("No Reff    : " + data.getString("swreff"));
            sb.append("\n");
            sb.append("Tagihan    : " + df.format(tagihan));
            sb.append("\n");
            sb.append("Biaya Adm  : " + df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar: " + df.format(data.getInt("amount")));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append(TextSpace.rataTengah("Telkom menyatakan"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("bukti pembayaran ini sah"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);
            sb.append(TextSpace.rataTengah("CA : " + Wong.getIdmerch() + " bitplus Mobile"));
            sb.append(br);
            out = sb.toString();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return out;
    }

    public ArrayList<ResultItem> lapTrans(String resp){

        String content=resp;
        ArrayList<ResultItem> al=new ArrayList<>();
        XmlIn in=new XmlIn();
        String rc=in.getItem(content,"rc");
        if(rc.equals("0000")||rc.equals("000")){
            DecimalFormat df=new DecimalFormat("#,##0");



            String trxid=in.getItem(content,"trxid");
            String type_trans=in.getItem(content,"type_trans");
            String desc=in.getItem(content,"desc");
            String merchant=in.getItem(content,"merchant");
            String subscriber_id=in.getItem(content,"noid");
            String name=in.getItem(content,"nama");
            //String npwp=in.getItem(content,"npwp");
            //String divre=in.getItem(content,"divre");
            //String datel=in.getItem(content,"datel");
            String swreff=in.getItem(content,"noref");
            String blth=in.getItem(content,"blth");
            String tagihan=in.getItem(content,"tagihan");
            String adminfee=in.getItem(content,"adminfee");
            String amount=in.getItem(content,"amount");
            String cashback=in.getItem(content,"cashback");
            String bill_merchant=in.getItem(content,"bill_merchant");



            al.add(new ResultItem("Merchant",merchant));
            al.add(new ResultItem("ID Pel",subscriber_id));
            al.add(new ResultItem("Nama",name));
            //al.add(new ResultItem("Npwp",npwp));
            //al.add(new ResultItem("Divre",divre));
            //al.add(new ResultItem("Datel",datel));
            al.add(new ResultItem("Sw Reff",swreff));
            al.add(new ResultItem("Blth",blth));
            al.add(new ResultItem("Tagihan",df.format(Integer.parseInt(tagihan))));
            al.add(new ResultItem("Admin",df.format(Integer.parseInt(adminfee))));
            al.add(new ResultItem("Total",df.format(Integer.parseInt(amount))));
            //al.add(new ResultItem("Cashback",df.format(Integer.parseInt(cashback))));
            //al.add(new ResultItem("Bill Merchant",df.format(Integer.parseInt(bill_merchant))));
            //al.add(new ResultItem("",""));
            //al.add(new ResultItem("Rincian Pembayaran",""));

            /*
            StringReader reader=null;
            reader=new StringReader(content);

            InputSource source = new InputSource(reader);
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();

            try {
                DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
                Document doc = documentBuilder.parse(source);
                doc.getDocumentElement().normalize();
                NodeList nList = doc.getElementsByTagName("item");

                for (int temp = 0; temp < nList.getLength(); temp++){
                    Node nNode = nList.item(temp);
                    if (nNode.getNodeType() == Node.ELEMENT_NODE){



                        Element eElement = (Element) nNode;
                        String billperiod = eElement.getElementsByTagName("billperiod").item(0).getTextContent();
                        String amountbill = eElement.getElementsByTagName("amountbill").item(0).getTextContent();
                        String admin = eElement.getElementsByTagName("admin").item(0).getTextContent();
                        String reffno = eElement.getElementsByTagName("reffno").item(0).getTextContent();


                        //al.add(new ResultItem("","--------------------"));
                        al.add(new ResultItem("Bill Periode",billperiod));
                        al.add(new ResultItem("Tagihan",df.format(Integer.parseInt(amountbill))));
                        al.add(new ResultItem("Admin",df.format(Integer.parseInt(admin))));
                        al.add(new ResultItem("Reff No",reffno));
                        al.add(new ResultItem("",""));

                    }
                }
            }catch (Exception e){
                Log.e("lapcash",e.toString());
            }finally {
                if(reader != null){
                    reader.close();
                }
            }
            */
        }else{
            al.add(new ResultItem("Data tidak ditemukan",""));
        }
        return al;
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d-m-yyyy HH:mm:ss").format(date);
        return formattedDate;
    }

    public ArrayList<NewResultItem> rePrint(String resp){
        DecimalFormat df=new DecimalFormat("#,##0");
        ArrayList<NewResultItem> al=new ArrayList<>();
        StringBuilder sb=new StringBuilder();
        try {
            String line = "------------------------------";
            String br = System.getProperty("line.separator");

            JSONObject in = new JSONObject(resp);
            JSONObject data = in.getJSONObject("data");
            JSONArray listTagihan = data.getJSONArray("detail");

            String produk = data.getString("type_trans");
            String time = data.getString("time");
            String subscriber_id = data.getString("subscriber_id");
            String name = data.getString("name");
            String periode = data.getString("periode");
            String bill = data.getString("bill");

            al.add(new NewResultItem("Produk",":", produk));
            al.add(new NewResultItem("ID Pelanggan",":",subscriber_id));
            al.add(new NewResultItem("Nama Pelanggan",":",name));
            al.add(new NewResultItem("Periode",":", periode));

            if(data.has("swreff")) {
                al.add(new NewResultItem("Biller Ref", ":", data.getString("swreff")));
            }

            int NoDetail = 1;
            int tagihan = 0;
            for (int i = 0; i < listTagihan.length(); i++) {
                al.add(new NewResultItem("","",""));
                al.add(new NewResultItem("-","Tagihan "+(NoDetail),"-"));;
                String periode_bill = listTagihan.getJSONObject(i).getString("periode");
                String rptag = listTagihan.getJSONObject(i).getString("tagihan");
                tagihan += listTagihan.getJSONObject(i).getInt("tagihan");
                al.add(new NewResultItem("Periode", ":", periode_bill));
                al.add(new NewResultItem("Rptag", ":", df.format(Integer.parseInt(rptag))));
                NoDetail++;
            }

            sb.append(TextSpace.rataTengah("PEMBAYARAN TELKOM"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append(br);
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("Nomor ID   : " + subscriber_id);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Bill       : " + bill);
            sb.append("\n");
            sb.append("Blth       : " + periode);
            sb.append("\n");
            sb.append("No Reff    : " + data.getString("swreff"));
            sb.append("\n");
            sb.append("Tagihan    : " + df.format(tagihan));
            sb.append("\n");
            sb.append("Biaya Adm  : " + df.format(data.getInt("admin")));
            sb.append("\n");
            sb.append("Total Bayar: " + df.format(data.getInt("amount")));
            sb.append("\n");
            //sb.append("    Telkom menyatakan");
            sb.append(line);
            sb.append(br);
            sb.append(TextSpace.rataTengah("Telkom menyatakan"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("bukti pembayaran ini sah"));
            sb.append("\n");
            //sb.append("  bukti pembayaran ini sah");
            //sb.append("\n");
            //sb.append("        Terima Kasih");
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append(br);
            //sb.append("CU : "+ Wong.getIdmerch()+" bitplus Mobile");
            sb.append(TextSpace.rataTengah("CU : " + Wong.getIdmerch() + " bitplus Mobile"));
            sb.append(br);
        }catch (Exception e) {
            e.printStackTrace();
        }
        //al.add(new ResultItem("struk",sb.toString()));
        this.setStruk(sb.toString());
        return al;
    }

    private String struk;

    public String getStruk() {
        return struk;
    }

    public void setStruk(String struk) {
        this.struk = struk;
    }
}
