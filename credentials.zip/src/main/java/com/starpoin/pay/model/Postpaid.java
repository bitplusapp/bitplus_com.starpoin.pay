package com.starpoin.pay.model;

import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Postpaid {

    public Map<String,Object> paramsInq(String noid){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","inquiry");
        map.put("productCategory", "pln");
        map.put("productCode", "postpaid");
        map.put("customer_no", noid);
        return map;
    }

    public Map<String,Object> paramsPay(String trxid, String noid, Double amount){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("action","payment");
        map.put("productCategory", "pln");
        map.put("productCode", "postpaid");
        map.put("customer_no", noid);
        map.put("ref_id", trxid);
        map.put("amount", amount);
        return map;
    }

    public ArrayList<NewResultItem> listResultJson(String response){
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            //Log.d("rcode",rcode);
            if(rcode.equals("000")||rcode.equals("0000")){
                DecimalFormat df=new DecimalFormat("#,##0");
                JSONObject data = jsonResp.getJSONObject("data");
                JSONArray listTagihan = data.getJSONArray("tagihan");
                String produk = data.getString("type_trans");
                String subscriber_id = data.getString("subscriber_id");
                String name = data.getString("name");
                String tarif = data.getString("segment");
                String daya = data.getString("power");
                String bill = data.getString("bill");

                al.add(new NewResultItem("Produk",":", produk));
                al.add(new NewResultItem("ID Pelanggan",":",subscriber_id));
                al.add(new NewResultItem("Nama Pelanggan",":",name));
                al.add(new NewResultItem("Tarif/Daya",":",tarif+"/"+daya));
                al.add(new NewResultItem("Tagihan",":",bill+ " Tagihan"));

                if(data.has("swreff")) {
                    al.add(new NewResultItem("PLN Ref", ":", data.getString("swreff")));
                }

                int NoDetail = 1;
                for (int i = 0; i < listTagihan.length(); i++) {
                        al.add(new NewResultItem("","",""));
                        al.add(new NewResultItem("-","Tagihan "+(NoDetail),"-"));
                        String tagihan = Long.toString(listTagihan.getJSONObject(i).getLong("electricity_bill")+listTagihan.getJSONObject(i).getLong("penalty"));
                        String arr_stan_meter[] = listTagihan.getJSONObject(i).getString("stand_meter").split("-");
                        String stmold = arr_stan_meter[0];
                        String stmnew = arr_stan_meter[1];
                        al.add(new NewResultItem("Periode",":",listTagihan.getJSONObject(i).getString("bill_period")));
                        al.add(new NewResultItem("Tagihan",":",df.format(Integer.parseInt(tagihan))));
                        al.add(new NewResultItem("Stand Meter",":",stmold +" - "+stmnew));
                        NoDetail++;
                }
            }
        }catch (Exception e){
            al.add(new NewResultItem("Waktu",":",e.getMessage()));
        }finally {
        }
        return al;
    }

    public String buildStruk(String response){
        String out=null;
        try {
            String line ="------------------------------";
            String br=System.getProperty("line.separator");

            DecimalFormat df=new DecimalFormat("#,##0");

            JSONObject in = new JSONObject(response);
            JSONObject data = in.getJSONObject("data");
            JSONArray listTagihan = data.getJSONArray("tagihan");

            String ref_id = data.getString("ref_id");
            String time = data.getString("time");
            String subscriber_id = data.getString("subscriber_id");
            String name = data.getString("name");
            String tarif = data.getString("segment");
            String daya = data.getString("power");

            StringBuilder sb=new StringBuilder();

            sb.append(TextSpace.rataTengah("PEMBAYARAN PLN POSTPAID"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Ref     : " + ref_id);
            sb.append("\n");
            sb.append("ID Pel     : " + subscriber_id);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Tarif/Daya : " + tarif + "/" + daya);
            sb.append("\n");
            sb.append("Biaya Adm  : " +"Rp. "+ df.format(Integer.parseInt(data.getString("admin"))));
            sb.append("\n");
            sb.append("Total Bayar: " + "Rp. "+df.format(Integer.parseInt(data.getString("amount"))));
            sb.append("\n\n");
            sb.append("Rincian Pembayaran");
            sb.append("\n\n");

            int NoDetail = 1;
            for (int i = 0; i < listTagihan.length(); i++) {
                String tagihan = Long.toString(listTagihan.getJSONObject(i).getLong("electricity_bill")+listTagihan.getJSONObject(i).getLong("penalty"));
                String arr_stan_meter[] = listTagihan.getJSONObject(i).getString("stand_meter").split("-");
                String stmold = arr_stan_meter[0];
                String stmnew = arr_stan_meter[1];
                NoDetail++;

                sb.append("Bln Tagih  : " + listTagihan.getJSONObject(i).getString("bill_period") + "\n");
                sb.append("Stand      : " + stmold +" - "+stmnew+ "\n");
                sb.append("PLN        : " +"Rp. "+ df.format(Integer.parseInt(tagihan)) + "\n");
                sb.append("\n");
            }

            sb.append(line);
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("CA : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);
            out = sb.toString();
        }catch (Exception e){
            //Log.e("lapcash",e.toString());
        }finally {
        }
        return out;
    }

    public ArrayList<NewResultItem> lapTrans(String response){
        ArrayList<NewResultItem> al=new ArrayList<>();
        JSONObject jsonResp = null;
        try {
            jsonResp = new JSONObject(response);
            String rcode = jsonResp.getString("rc");
            //Log.d("rcode",rcode);
            if(rcode.equals("000")||rcode.equals("0000")){
                DecimalFormat df=new DecimalFormat("#,##0");
                JSONObject data = jsonResp.getJSONObject("data");
                JSONArray listTagihan = data.getJSONArray("tagihan");
                String produk = data.getString("type_trans");
                String subscriber_id = data.getString("subscriber_id");
                String name = data.getString("name");
                String tarif = data.getString("segment");
                String daya = data.getString("power");
                String bill = data.getString("bill");

                al.add(new NewResultItem("Produk",":", produk));
                al.add(new NewResultItem("ID Pelanggan",":",subscriber_id));
                al.add(new NewResultItem("Nama Pelanggan",":",name));
                al.add(new NewResultItem("Tarif/Daya",":",tarif+"/"+daya));
                al.add(new NewResultItem("Tagihan",":",bill+ " Tagihan"));

                if(data.has("swreff")) {
                    al.add(new NewResultItem("PLN Ref", ":", data.getString("swreff")));
                }

                int NoDetail = 1;
                for (int i = 0; i < listTagihan.length(); i++) {
                    al.add(new NewResultItem("","",""));
                    al.add(new NewResultItem("-","Tagihan "+(NoDetail),"-"));
                    String tagihan = Long.toString(listTagihan.getJSONObject(i).getLong("electricity_bill")+listTagihan.getJSONObject(i).getLong("penalty"));
                    String arr_stan_meter[] = listTagihan.getJSONObject(i).getString("stand_meter").split("-");
                    String stmold = arr_stan_meter[0];
                    String stmnew = arr_stan_meter[1];
                    al.add(new NewResultItem("Periode",":",listTagihan.getJSONObject(i).getString("bill_period")));
                    al.add(new NewResultItem("Tagihan",":",df.format(Integer.parseInt(tagihan))));
                    al.add(new NewResultItem("Stand Meter",":",stmold +" - "+stmnew));
                    NoDetail++;
                }
            }
        }catch (Exception e){
            al.add(new NewResultItem("Message",":","Data tidak ditemukan"));
        }finally {
        }
        return al;
    }

    private String timestampFormattedWIB(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d-m-yyyy HH:mm:ss").format(date);
        return formattedDate;
    }

    private String timestampFormattedStruk(String timestamp) {
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyyMMdd").parse(timestamp.substring(0, 8));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String formattedDate = new SimpleDateFormat("d MMM yyyy").format(date);
        return formattedDate;
    }

    public ArrayList<NewResultItem> rePrint(String content) {
        ArrayList<NewResultItem> al=new ArrayList<>();
        try {
            String line ="------------------------------";
            String br=System.getProperty("line.separator");

            DecimalFormat df=new DecimalFormat("#,##0");

            JSONObject in = new JSONObject(content);
            JSONObject data = in.getJSONObject("data");
            JSONArray listTagihan = data.getJSONArray("tagihan");

            String ref_id = data.getString("ref_id");
            String time = data.getString("time");
            String produk = data.getString("type_trans");
            String subscriber_id = data.getString("subscriber_id");
            String name = data.getString("name");
            String tarif = data.getString("segment");
            String daya = data.getString("power");
            String bill = data.getString("bill");

            al.add(new NewResultItem("Produk",":", produk));
            al.add(new NewResultItem("ID Pelanggan",":",subscriber_id));
            al.add(new NewResultItem("Nama Pelanggan",":",name));
            al.add(new NewResultItem("Tarif/Daya",":",tarif+"/"+daya));
            al.add(new NewResultItem("Tagihan",":",bill+ " Tagihan"));

            if(data.has("swreff")) {
                al.add(new NewResultItem("PLN Ref", ":", data.getString("swreff")));
            }

            StringBuilder sb=new StringBuilder();

            sb.append(TextSpace.rataTengah("PEMBAYARAN PLN POSTPAID"));
            //sb.append("bitplus");
            sb.append("\n");
            sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
            sb.append("\n");
            sb.append(TextSpace.rataTengah("Simple & Mudah"));
            //sb.append("PEMBAYARAN PLN POSTPAID");
            sb.append("\n");
            sb.append(line);
            sb.append("\n");
            //sb.append("Tgl Trans  : " + tgltrans);
            sb.append("Tgl Trans  : " + timestampFormattedStruk(time));
            sb.append("\n");
            sb.append("No Ref     : " + ref_id);
            sb.append("\n");
            sb.append("ID Pel     : " + subscriber_id);
            sb.append("\n");
            sb.append("Nama       : " + name);
            sb.append("\n");
            sb.append("Tarif/Daya : " + tarif + "/" + daya);
            sb.append("\n");
            sb.append("Biaya Adm  : " +"Rp. "+ df.format(Integer.parseInt(data.getString("admin"))));
            sb.append("\n");
            sb.append("Total Bayar: " + "Rp. "+df.format(Integer.parseInt(data.getString("amount"))));
            sb.append("\n\n");
            sb.append("Rincian Pembayaran");
            sb.append("\n\n");

            int NoDetail = 1;
            for (int i = 0; i < listTagihan.length(); i++) {
                al.add(new NewResultItem("","",""));
                al.add(new NewResultItem("-","Tagihan "+(NoDetail),"-"));
                String tagihan = Long.toString(listTagihan.getJSONObject(i).getLong("electricity_bill")+listTagihan.getJSONObject(i).getLong("penalty"));
                String arr_stan_meter[] = listTagihan.getJSONObject(i).getString("stand_meter").split("-");
                String stmold = arr_stan_meter[0];
                String stmnew = arr_stan_meter[1];
                al.add(new NewResultItem("Periode",":",listTagihan.getJSONObject(i).getString("bill_period")));
                al.add(new NewResultItem("Tagihan",":",df.format(Integer.parseInt(tagihan))));
                al.add(new NewResultItem("Stand Meter",":",stmold +" - "+stmnew));
                NoDetail++;

                sb.append("Bln Tagih  : " + listTagihan.getJSONObject(i).getString("bill_period") + "\n");
                sb.append("Stand      : " + stmold +" - "+stmnew+ "\n");
                sb.append("PLN        : " +"Rp. "+ df.format(Integer.parseInt(tagihan)) + "\n");
                sb.append("\n");
            }

            sb.append(line);
            sb.append("\n");
            //sb.append("Terima Kasih");
            sb.append(TextSpace.rataTengah("Terima Kasih"));
            sb.append("\n");
            //sb.append("CU : "+ Wong.getIdmerch()+" bitplus Mobile");
            sb.append(TextSpace.rataTengah("CU : "+ Wong.getIdmerch()+" bitplus Mobile"));
            sb.append(br);

            //al.add(new NewResultItem("struk",sb.toString()));
            this.setStruk(sb.toString());
        }catch (Exception e){
            //Log.e("lapcash",e.toString());
        }finally {
        }

        return al;
    }

    private String struk;

    public String getStruk() {
        return struk;
    }

    public void setStruk(String struk) {
        this.struk = struk;
    }
}
