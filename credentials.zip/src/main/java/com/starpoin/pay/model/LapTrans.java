package com.starpoin.pay.model;

import com.starpoin.pay.R;
import com.starpoin.pay.util.Produk;

import java.util.ArrayList;

public class LapTrans {

    public final static String SEMUA="all";
    public final static String VOUCHER="voucher";
    public final static String POSTPAID="postpaid";
    public final static String PREPAID="prepaid";
    public final static String NONTAGLIS="nontaglis";
    public final static String JASTEL="telkom";
    public final static String PDAM="pdam";
    public final static String PBB="pbb";
    public final static String BPJS="bpjs";
    public final static String PASKABAYAR="telcopasca";
    public final static String TVCABLE="inetv";


    private int id;
    private int imageResource;
    private String key,label;

    public LapTrans(){

    }

    public LapTrans(int id, String key, String label) {
        this.id = id;
        this.key = key;
        this.label = label;
    }

    public LapTrans(int id, int imageResource, String label) {
        this.id = id;
        this.imageResource = imageResource;
        this.key = key;
        this.label = label;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public int getImageResource() {
        return imageResource;
    }

    public void setImageResource(int imageResource) {
        this.imageResource = imageResource;
    }

    public ArrayList<LapTrans> listProduk(){
        ArrayList<LapTrans> list=new ArrayList<>();
        list.add(new LapTrans(Produk.SEMUA,LapTrans.SEMUA,"Semua Produk"));
        list.add(new LapTrans(Produk.POSTPAID,LapTrans.POSTPAID,"PLN Postpaid"));
        list.add(new LapTrans(Produk.PREPAID,LapTrans.PREPAID,"PLN Token"));
        list.add(new LapTrans(Produk.NONTAGLIS,LapTrans.NONTAGLIS,"PLN Nontaglis"));
        list.add(new LapTrans(Produk.VOUCHER,LapTrans.VOUCHER,"Pulsa & Paket Data"));
        list.add(new LapTrans(Produk.PASCABAYAR,LapTrans.PASKABAYAR,"Paska bayar"));
        list.add(new LapTrans(Produk.PDAM,LapTrans.PDAM,"Air PDAM"));
        list.add(new LapTrans(Produk.BPJS,LapTrans.BPJS,"BPJS Kesehatan"));
        list.add(new LapTrans(Produk.JASTEL,LapTrans.JASTEL,"Telkom Indihome"));
        list.add(new LapTrans(Produk.PBB,LapTrans.PBB,"Pajak PBB"));
        list.add(new LapTrans(Produk.TVCABLE,LapTrans.TVCABLE,"Internet & TV Cable"));
        return list;
    }

    public ArrayList<LapTrans> listProductReprint(){
        ArrayList<LapTrans> list=new ArrayList<>();
        //list.add(new LapTrans(Produk.SEMUA,LapTrans.SEMUA,"Semua Produk"));
        list.add(new LapTrans(Produk.POSTPAID,LapTrans.POSTPAID,"PLN Postpaid"));
        list.add(new LapTrans(Produk.PREPAID,LapTrans.PREPAID,"PLN Token"));
        list.add(new LapTrans(Produk.NONTAGLIS,LapTrans.NONTAGLIS,"PLN Nontaglis"));
        list.add(new LapTrans(Produk.VOUCHER,LapTrans.VOUCHER,"Pulsa & Paket Data"));
        list.add(new LapTrans(Produk.PASCABAYAR,LapTrans.PASKABAYAR,"Paska bayar"));
        list.add(new LapTrans(Produk.PDAM,LapTrans.PDAM,"Air PDAM"));
        list.add(new LapTrans(Produk.BPJS,LapTrans.BPJS,"BPJS Kesehatan"));
        list.add(new LapTrans(Produk.JASTEL,LapTrans.JASTEL,"Telkom Indihome"));
        list.add(new LapTrans(Produk.PBB,LapTrans.PBB,"Pajak PBB"));
        list.add(new LapTrans(Produk.TVCABLE,LapTrans.TVCABLE,"Internet & TV Cable"));
        return list;
    }

    public ArrayList<LapTrans> listProdukWithImage(){
        ArrayList<LapTrans> list=new ArrayList<>();
        list.add(new LapTrans(Produk.POSTPAID,R.drawable.postpaid,"PLN Postpaid"));
        list.add(new LapTrans(Produk.PREPAID, R.drawable.prepaid,"Token Listrik"));
        list.add(new LapTrans(Produk.NONTAGLIS, R.drawable.nontaglis, "Nontaglis"));
        list.add(new LapTrans(Produk.PULSA, R.drawable.pulsa, "Pulsa"));
        list.add(new LapTrans(Produk.GAME, R.drawable.game, "Game"));
        list.add(new LapTrans(Produk.PAKETDATA, R.drawable.paket_data, "Paket Data"));
        list.add(new LapTrans(Produk.TOPUP,R.drawable.e_wallet,"E-Wallet"));
        list.add(new LapTrans(Produk.JASTEL, R.drawable.telkom, "Telkom"));
        list.add(new LapTrans(Produk.BPJS,R.drawable.bpjs, "BPJS"));
        list.add(new LapTrans(Produk.PDAM,R.drawable.pdam, "Air PDAM"));
        list.add(new LapTrans(Produk.PASCABAYAR,R.drawable.paska_bayar, "PaskaBayar"));
        list.add(new LapTrans(Produk.PBB,R.drawable.pbb, "Pajak PBB"));
        list.add(new LapTrans(Produk.TVCABLE,R.drawable.tv_cable, "Internet & TV Cable"));
        return list;
    }

    public ArrayList<LapTrans> listProdukWithImageForDashboard(){
        ArrayList<LapTrans> list=new ArrayList<>();
        list.add(new LapTrans(Produk.POSTPAID,R.drawable.postpaid,"PLN Postpaid"));
        list.add(new LapTrans(Produk.PREPAID, R.drawable.prepaid,"Token Listrik"));
        list.add(new LapTrans(Produk.NONTAGLIS, R.drawable.nontaglis, "Nontaglis"));
        list.add(new LapTrans(Produk.PULSA, R.drawable.pulsa, "Pulsa"));
        list.add(new LapTrans(Produk.GAME, R.drawable.game, "Game"));
        list.add(new LapTrans(Produk.PAKETDATA, R.drawable.paket_data, "Paket Data"));
        list.add(new LapTrans(Produk.TOPUP,R.drawable.e_wallet,"E-Wallet"));
        list.add(new LapTrans(Produk.JASTEL, R.drawable.telkom, "Telkom"));
        list.add(new LapTrans(Produk.BPJS,R.drawable.bpjs, "BPJS"));
        list.add(new LapTrans(Produk.PDAM,R.drawable.pdam, "Air PDAM"));
        list.add(new LapTrans(Produk.PASCABAYAR,R.drawable.paska_bayar, "PaskaBayar"));
        list.add(new LapTrans(Produk.SEMUA,R.drawable.other_product, "Lainnya"));
        return list;
    }

    public ArrayList<LapTrans> listProdukTagihanBulanan(){
        ArrayList<LapTrans> list=new ArrayList<>();
        list.add(new LapTrans(Produk.POSTPAID,R.drawable.postpaid,"PLN Postpaid"));
        list.add(new LapTrans(Produk.JASTEL, R.drawable.telkom, "Telkom"));
        list.add(new LapTrans(Produk.BPJS,R.drawable.bpjs, "BPJS"));
        list.add(new LapTrans(Produk.PDAM,R.drawable.pdam, "Air PDAM"));
        list.add(new LapTrans(Produk.PASCABAYAR,R.drawable.paska_bayar, "PaskaBayar"));
        list.add(new LapTrans(Produk.TVCABLE,R.drawable.tv_cable, "Internet & TV Cable"));
        return list;
    }

    public ArrayList<LapTrans> listProdukVoucher(){
        ArrayList<LapTrans> list=new ArrayList<>();
        list.add(new LapTrans(Produk.PREPAID, R.drawable.prepaid, "Token Listrik"));
        list.add(new LapTrans(Produk.PULSA, R.drawable.pulsa, "Pulsa"));
        list.add(new LapTrans(Produk.GAME, R.drawable.game, "Game"));
        list.add(new LapTrans(Produk.PAKETDATA, R.drawable.paket_data, "Paket Data"));
        list.add(new LapTrans(Produk.TOPUP,R.drawable.e_wallet,"E-Wallet"));
        return list;
    }

    public ArrayList<LapTrans> listProdukLainnya(){
        ArrayList<LapTrans> list=new ArrayList<>();
        list.add(new LapTrans(Produk.NONTAGLIS, R.drawable.nontaglis, "Nontaglis"));
        list.add(new LapTrans(Produk.PBB, R.drawable.pbb, "Pajak PBB"));
        //list.add(new LapTrans(Produk.EVENT, R.drawable.event, "Event"));
        return list;
    }
}
