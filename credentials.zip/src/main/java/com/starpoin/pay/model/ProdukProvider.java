package com.starpoin.pay.model;

import android.util.Log;

import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import malik.org.json.JSONArray;
import malik.org.json.JSONObject;

public class ProdukProvider {

    private String provider,kode,desc_produk,idsw,prefix,type_produk;

    public ProdukProvider(){

    }

    public ProdukProvider(String provider, String kode, String desc_produk, String idsw, String prefix,String type_produk) {
        this.provider = provider;
        this.kode = kode;
        this.desc_produk = desc_produk;
        this.idsw = idsw;
        this.prefix = prefix;
        this.type_produk = type_produk;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getDesc_produk() {
        return desc_produk;
    }

    public void setDesc_produk(String desc_produk) {
        this.desc_produk = desc_produk;
    }

    public String getIdsw() {
        return idsw;
    }

    public void setIdsw(String idsw) {
        this.idsw = idsw;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getType_produk() {
        return type_produk;
    }

    public void setType_produk(String type_produk) {
        this.type_produk = type_produk;
    }

    public String paramsProvider(String type){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","req_produk_provider");
        map.put("type_produk",type);
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        String params="Trans"+new Params().buildParams(map);
        return params;
    }

    public ArrayList<ProdukProvider> listProdukVoucher(String content){
        ArrayList<ProdukProvider> al=new ArrayList<>();
        try{
            JSONArray arr = new JSONArray(content);
            int size=arr.length();
            for(int i=0; i<size; i++){
                JSONObject item=arr.getJSONObject(i);

                String namaProvider=item.getString("name");
                String kode=item.getString("additional_code");
                String keterangan=item.getString("description");
                String sw="-";
                String prefix_number=item.getString("prefix");
                String type=item.getString("code");
                ProdukProvider produk=new ProdukProvider(namaProvider,kode,keterangan,sw,prefix_number,type);
                al.add(produk);
            }
        }catch (Exception ex){
            Log.e("err_json",ex.getMessage());
        }
        return al;
    }

    public List<String> prefixList(String prefix){
        List<String> list=new ArrayList<>();
        if(!prefix.equals("")){
            StringTokenizer st = new StringTokenizer(prefix);
            String str=st.nextToken(",");
            list.add(str);
        }
        return list;
    }

    public ArrayList<Pulsa> listDenomPulsa(ArrayList<ProdukProvider> list,String subno){
        ArrayList<Pulsa> denomList=new ArrayList<>();
        for(ProdukProvider prod:list){
            //private String provider,kode,desc_produk,port,prefix;
            provider=prod.getProvider();
            kode=prod.getKode();
            desc_produk=prod.getDesc_produk();
            idsw=prod.getIdsw();
            prefix=prod.getPrefix().trim();
            if(!prefix.equals("")){
                StringTokenizer st = new StringTokenizer(prefix);
                String str=st.nextToken(",");
                if(str.equals(subno)){
                    //String provider, String desc, String kode,String idsw
                    Pulsa pul=new Pulsa(provider,desc_produk,kode,idsw);
                    denomList.add(pul);
                }
            }

        }
        return denomList;
    }
}
