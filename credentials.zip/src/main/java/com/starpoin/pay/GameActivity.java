package com.starpoin.pay;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.adapter.GameNominalAdapter;
import com.starpoin.pay.adapter.GameProviderAdapter;
import com.starpoin.pay.model.Game;
import com.starpoin.pay.model.Pulsa;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Produk;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class GameActivity extends AbaseActivity implements View.OnClickListener {

    private final static int PICK_CONTACT = 0;
    private ConstraintLayout rootLayout;


    private Pulsa selectedDenom;
    private EditText etNomor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        setBarTitle("Game");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        reqProvider();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void reqProvider(){

        String params = "products/voucher_group/game";
        OtherTask task = new OtherTask(GameActivity.this, GameActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                viewProvider(content);
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewProvider(String content){
        ArrayList<Game> listProvider=new Game().buildProviderJson(content);

        GameProviderAdapter adapter=new GameProviderAdapter(GameActivity.this,listProvider);
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);
        RecyclerView rvDenom=findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);
        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                Game game=listProvider.get(position);
                String prov=game.getProvider();
                reqDenom(prov);
            }
        });
    }

    private void reqDenom(String prov){

        String params = "products/voucher_group/game/"+prov;

        OtherTask task = new OtherTask(GameActivity.this, GameActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                viewDenom(content);
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewDenom(String content){
        ArrayList<Pulsa> listDenom=new Pulsa().pulsaDenom(content);
        //PulsaAdapter adapter=new PulsaAdapter(GameActivity.this,listDenom);
        GameNominalAdapter adapter=new GameNominalAdapter(GameActivity.this,listDenom);
        GridLayoutManager layoutManager=new GridLayoutManager(this,3);

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.denom_layout_game);

        RecyclerView rvDenom=bottomSheetDialog.findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);

        etNomor = bottomSheetDialog.findViewById(R.id.etNomor);

        Button contactButton = bottomSheetDialog.findViewById(R.id.btnContact);

        contactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
                startActivityForResult(intent, PICK_CONTACT);
            }
        });

        adapter.setOnItemClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();
                selectedDenom=listDenom.get(position);
                String no=etNomor.getText().toString().trim();
                String kodeProd=selectedDenom.getKode();
                String prefix = selectedDenom.getIdsw();
                String checkForm = formValidation(prefix, no);
                if(checkForm == null) {
                    bottomSheetDialog.hide();
                    inquery(no,kodeProd);
                }else{
                    showMsg(checkForm);
                }
            }
        });

        bottomSheetDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            switch (requestCode) {
                case (PICK_CONTACT):
                    if (resultCode == RESULT_OK) {
                        Cursor cursor = getContentResolver().query(data.getData(), new String[] {ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);

                        // True if the cursor is not empty
                        cursor.moveToFirst();
                        String number = cursor.getString((int) 0);
                        etNomor.setText(number);
                    }

                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String formValidation(String prefix, String etNomor) {
        String resultMsg = null;
        if(prefix.contains(",") && etNomor.contains(",")) {
            return null;
        }

        if(prefix.contains("-NA-") && etNomor.length() == 0) {
            return null;
        }

        if(prefix.contains(",")) {
            resultMsg = "Format salah, gunakan format berikut ("+prefix+")";
        }

        if(prefix.contains("-NA-")) {
            resultMsg = "Format salah, Produk ini tidak memerlukan ID Game";
        }

        if(resultMsg == null)  {
            if(prefix.length() > 0 && etNomor.length() > 0) {
                return null;
            }

            if(prefix.length() == 0) {
                resultMsg = "Format salah, gunakan format berikut ("+prefix+")";
            }
        }

        return resultMsg;
    }

    private void inquery(String no,String idProduk){
        if(no.length()==0){
            no="0";
        }

        Map<String,Object> map = new Pulsa().paramsInq(no,idProduk,"game");
        String params= new JSONObject(map).toString();

        String finalNo = no;
        TransTask task = new TransTask(GameActivity.this,GameActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc=json.getString(content,"rc");
                if(rc.equals("0000")){
                    String trxid=json.getObjectWithString(content,"data", "ref_id");
                    double amount =Double.parseDouble(json.getObjectWithString(content,"data", "price"));
                    String admin = "0";
                    double nominal = amount;
                    String time = json.getObjectWithString(content,"data", "time");
                    String voucher_code = json.getObjectWithString(content,"data", "voucher_code");
                    Intent intent=new Intent(GameActivity.this, ResponseActivity.class);
                    intent.putExtra("produk", Produk.GAME);
                    intent.putExtra("result", content);
                    intent.putExtra("nominal", nominal);
                    intent.putExtra("amount", amount);
                    intent.putExtra("trxid", trxid);
                    intent.putExtra("admin", admin);
                    intent.putExtra("time", time);
                    intent.putExtra("noid", finalNo);
                    intent.putExtra("additional", voucher_code); //tambahan parameter
                    startActivity(intent);
                }else{
                    String desc=json.getString(content,"message");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);

    }

    @Override
    public void onClick(View v) {
    }
}