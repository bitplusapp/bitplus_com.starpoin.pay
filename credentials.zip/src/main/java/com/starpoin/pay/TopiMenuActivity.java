package com.starpoin.pay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TopiMenuActivity extends AbaseActivity implements View.OnClickListener {

    private Button btnJual,btnBeli,btnReturJual,btnReturBeli;
    private Button btnProduk,btnAddProduk;
    private Button btnLapJual,btnLapBeli,btnLapLaba;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topi_menu);

        setTitle("MENU KOPI");

        btnJual=findViewById(R.id.btnJual);
        btnJual.setOnClickListener(this);

        btnBeli=findViewById(R.id.btnBeli);
        btnBeli.setOnClickListener(this);

        btnReturJual=findViewById(R.id.btnReturJual);
        btnReturJual.setOnClickListener(this);

        btnReturBeli=findViewById(R.id.btnReturBeli);
        btnReturBeli.setOnClickListener(this);

        btnProduk=findViewById(R.id.btnProduk);
        btnProduk.setOnClickListener(this);

        btnAddProduk=findViewById(R.id.btnAddProduk);
        btnAddProduk.setOnClickListener(this);

        btnLapJual=findViewById(R.id.btnLapJual);
        btnLapJual.setOnClickListener(this);

        btnLapBeli=findViewById(R.id.btnLapBeli);
        btnLapBeli.setOnClickListener(this);

        btnLapLaba=findViewById(R.id.btnLapLaba);
        btnLapLaba.setOnClickListener(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        Intent intent=null;
        switch (v.getId()){
            case R.id.btnJual:
                intent=new Intent(TopiMenuActivity.this,TopijualActivity.class);
                break;
            case R.id.btnBeli:
                intent=new Intent(TopiMenuActivity.this,TopibeliActivity.class);
                break;
            case R.id.btnProduk:
                intent=new Intent(TopiMenuActivity.this,TopiProdukActivity.class);
                break;
            case R.id.btnAddProduk:
                intent=new Intent(TopiMenuActivity.this,TopiAddProdukActivity.class);
                break;
            case R.id.btnLapJual:
                intent=new Intent(TopiMenuActivity.this,TopiLapjualActivity.class);
                break;
            case R.id.btnLapBeli:
                intent=new Intent(TopiMenuActivity.this,TopiLapbeliActivity.class);
                break;
            case R.id.btnLapLaba:
                intent=new Intent(TopiMenuActivity.this,TopiLaplabaActivity.class);
                break;
        }
        if(intent != null){
            startActivity(intent);
        }
    }
}