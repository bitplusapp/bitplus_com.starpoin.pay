package com.starpoin.pay;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.model.LoginMethod;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.SecureOtherTask;
import com.starpoin.pay.util.JsonIn;
import com.starpoin.pay.util.Valid;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private ConstraintLayout rootLayout;
    private GoogleSignInClient mGoogleSignInClient;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private static String PIN;
    private SharedPreferences sp;
    private Button btnHubungkanEmail;
    private GoogleSignInAccount account;
    private String jsonResponse;

    public ProfileFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ProfileFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            System.out.println("Data from saved Instancestate");
            jsonResponse = savedInstanceState.getString("jsonResponse");
        }
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            System.out.println(mParam1);
            System.out.println(mParam2);
        }
        sp=getActivity().getSharedPreferences("Login",0);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(ProfileFragment.this.getContext(), gso);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(ProfileFragment.this.getContext());
        updateUI(account);
    }

    private void updateUI(GoogleSignInAccount account) {
        if(account != null) {
            mGoogleSignInClient.signOut();
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("jsonResponse", jsonResponse);
        // Tambahkan TextView lainnya sesuai kebutuhan
    }

    private void showDataFromResponse(String content) {
        JsonIn json=new JsonIn();
        Valid decrypt = new Valid();
        String data = json.getString(content, "data");
        TextView txtNameMerchant = rootLayout.findViewById(R.id.txtNameMerchant);
        txtNameMerchant.setText(json.getString(data, "id_merchant")+" - "+json.getString(data, "name_merchant"));
        TextView txtNotelp = rootLayout.findViewById(R.id.txtNoTelp);
        txtNotelp.setText(json.getString(data, "phone_number"));
        TextView txtEmail = rootLayout.findViewById(R.id.txtEmail);
        txtEmail.setText(json.getString(data, "username"));
        TextView txtAlamat = rootLayout.findViewById(R.id.txtAlamat);
        btnHubungkanEmail = rootLayout.findViewById(R.id.btnHubungkanEmail);
        String email_user = json.getString(data, "email_user");
        ImageView ivInfoPin, ivInfoEmail;

        ivInfoPin = rootLayout.findViewById(R.id.ivInfoPin);
        ivInfoPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMsg("fitur PIN Aplikasi opsional yang memungkinkan pengguna mengakses aplikasi tanpa login tradisional. PIN secara otomatis dibuat oleh sistem dan tidak dapat diubah di aplikasi mobile. Harap jaga kerahasiaan PIN Anda.");
            }
        });

        ivInfoEmail = rootLayout.findViewById(R.id.ivInfoEmail);
        ivInfoEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMsg("Dengan menghubungkan akun email, mitra bitplus memiliki tambahan opsi jika lupa password maka akan dikirimkan via email. pastikan email yang digunakan belum pernah terdaftar pada akun bitplus.");
            }
        });

        SignInButton signInButton = rootLayout.findViewById(R.id.sign_in_button);
        if(!decrypt.isValidEmail(txtEmail.getText().toString()) && !decrypt.isValidEmail(email_user)) {
            btnHubungkanEmail.setVisibility(View.GONE);
            signInButton.setStyle(SignInButton.SIZE_WIDE, SignInButton.COLOR_LIGHT);
            signInButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                    startActivityForResult(signInIntent, 1);
                }
            });
        }else{
            signInButton.setVisibility(View.GONE);
            btnHubungkanEmail.setVisibility(View.VISIBLE);
            btnHubungkanEmail.setText("Email Terhubung");
            btnHubungkanEmail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String email = "";
                    if(decrypt.isValidEmail(txtEmail.getText().toString())) {
                        email = txtEmail.getText().toString();
                    }else{
                        email = email_user;
                    }
                    showMsg("Email anda : "+email);
                }
            });
        }

        txtAlamat.setText(json.getString(data, "address"));
        PIN = decrypt.decrypt(json.getString(data, "pin_app"));

        Button btnAktifkan = rootLayout.findViewById(R.id.btnAktifkan);

        String pin = sp.getString("pin", null);
        if(pin != null) {
            btnAktifkan.setText("Non aktifkan");
            btnAktifkan.setBackgroundResource(R.color.warning);
            btnAktifkan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor Ed = sp.edit();
                    Ed.remove("pin");
                    Ed.commit();
                    Toast.makeText(ProfileFragment.this.getContext(), "PIN Di Non aktifkan", Toast.LENGTH_SHORT).show();
                    getFragmentManager().beginTransaction().detach(ProfileFragment.this).commit();
                    getFragmentManager().beginTransaction().attach(ProfileFragment.this).commit();
                }
            });
        }else{
            btnAktifkan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ProfileFragment.this.getContext(), PinScreenActivity.class);
                    intent.putExtra("pin", PIN);
                    startActivity(intent);
                }
            });
        }
    }

    private void getProfile() {
        if(jsonResponse != null) {
            showDataFromResponse(jsonResponse);
        }else{
            SecureOtherTask task = new SecureOtherTask(getActivity(),getActivity(), new OnEventListener<String>() {
                @Override
                public void onSuccess(String content) {
                    JsonIn json=new JsonIn();
                    String rc=json.getString(content,"rc");
                    if(rc.equals("000")||rc.equals("0000")) {
                        jsonResponse = content;
                        showDataFromResponse(content);
                    }else{
                        String desc=json.getString(content,"message");
                        showMsg(desc);
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    //showMsg(e.getMessage());
                    //Toast.makeText(getApplicationContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }

            });
            task.execute("profile/me", "");
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == 1) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            if (resultCode == Activity.RESULT_OK) {
                Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                handleSignInResult(task);
            }
        }else{
            //showMsg("Disconnected");
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> task) {
        if(task != null) {
            //send to server
            if(task.getResult() != null) {
                //loginUsingGoogleSign(task.getResult());
                processBindEmail(task.getResult());
            }
        }
    }

    private void processBindEmail(GoogleSignInAccount result) {
        JSONObject reqResp = null;
        try {
            reqResp = new JSONObject();
            reqResp.put("token", result.getIdToken());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        SecureOtherTask task = new SecureOtherTask(getActivity(),getActivity(), new OnEventListener<String>() {
            @Override
            public void onSuccess(String object) {
                JsonIn json = new JsonIn();
                showMsg(json.getString(object,"message"));
                updateUI(account);
                getFragmentManager().beginTransaction().detach(ProfileFragment.this).commit();
                getFragmentManager().beginTransaction().attach(ProfileFragment.this).commit();
            }
            @Override
            public void onFailure(Exception e) {
                e.printStackTrace();
                showMsg(e.getMessage());
            }
        });
        task.execute("profile/bind-email", reqResp.toString());
    }

    private void showMsg(String msg){
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(getContext(), R.style.BottomSheetDialogStyle);
        bottomSheetDialog.setContentView(R.layout.msg_dialog);
        //ImageButton btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        Button btnClose=bottomSheetDialog.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //bottomSheetDialog.cancel();
                bottomSheetDialog.dismiss();
            }
        });
        TextView tvError=bottomSheetDialog.findViewById(R.id.tvError);
        tvError.setText(msg);
        bottomSheetDialog.show();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_profile, container, false);
        rootLayout = rootView.findViewById(R.id.rootLayout);
        getProfile();
        return rootView;
    }
}