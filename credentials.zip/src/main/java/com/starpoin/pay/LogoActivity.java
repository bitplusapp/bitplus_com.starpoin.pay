package com.starpoin.pay;

import android.bluetooth.BluetoothAdapter;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.helper.PrinterProfil;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.PrinterTask;
import com.starpoin.pay.util.TextSpace;
import com.starpoin.pay.util.Wong;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class LogoActivity extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;

    private ImageView imgLogo;
    private ImageButton btnBack;
    private CheckBox cbLogo;
    private Button btnGallery,btnTest,btnReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logo);

        this.setTitle("Logo");

        if(getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);

        imgLogo=(ImageView) findViewById(R.id.imgLogo);
        cbLogo=(CheckBox) findViewById(R.id.cbLogo);
        cbLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = ((CheckBox) v).isChecked();
                String logo_view;
                if (checked){
                    logo_view="1";
                }else{
                    logo_view="0";
                }
                updateLogoView(logo_view);
            }
        });
        btnGallery=(Button) findViewById(R.id.btnGallery);
        btnGallery.setOnClickListener(this);

        btnTest=(Button) findViewById(R.id.btnTest);
        btnTest.setOnClickListener(this);

        btnReset=(Button) findViewById(R.id.btnReset);
        btnReset.setOnClickListener(this);

        btnBack = (ImageButton) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);

        showLogo();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnGallery:
                Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pickPhoto , 1);
                break;
            case R.id.btnTest:
                BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ECLAIR){
                    if (!btAdapter.isEnabled()) {
                        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivityForResult(enableBtIntent,2);


                    }else{
                        String text=createContentDataPrint();
                        //new PrinterTask().execute(text);
                        cetakStruk(text);
                    }
                }

                break;
            case R.id.btnReset:
                resetLogo();
                break;
            case R.id.btnBack:
                onBackPressed();
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_CANCELED) {
            switch (requestCode) {
                case 1:
                    if (resultCode == RESULT_OK && data != null) {
                        Uri selectedImage = data.getData();
                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
                        if (selectedImage != null) {
                            Cursor cursor = getContentResolver().query(selectedImage,
                                    filePathColumn, null, null, null);
                            if (cursor != null) {
                                cursor.moveToFirst();

                                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                                String picturePath = cursor.getString(columnIndex);

                                Bitmap bitmap=BitmapFactory.decodeFile(picturePath);
                                int bw=bitmap.getWidth();
                                int bh=bitmap.getHeight();
                                if(bw<701 && bh<301){
                                    imgLogo.setImageBitmap(bitmap);
                                    updateImgLogo(bitmap);
                                }else{
                                    Toast toast = Toast.makeText(LogoActivity.this,
                                            "Ukuran gambar terlalu besar", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.TOP, 25, 400);
                                    toast.show();
                                }

                                cursor.close();
                            }
                        }

                    }
                    break;
            }
        }
    }

    public void cetakStruk(String struk){
        PrinterTask task = new PrinterTask(LogoActivity.this,LogoActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                if(!content.equals("1")){
                    showMsg(content);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(struk);
    }

    private void showLogo(){
        PrinterProfil pp=new PrinterProfil().getPrinterProfil(this);
        byte[] logo=pp.getLogo();
        //byte[] logo=logoDb();
        ByteArrayInputStream imageStream=null;
        try {
            imageStream = new ByteArrayInputStream(logo);
            Bitmap img= BitmapFactory.decodeStream(imageStream);
            imgLogo.setImageBitmap(img);
        }catch (Exception e){

        }
        int logo_view=pp.getLogo_view();
        System.out.println("logo_view: "+logo_view);
        if(logo_view==1){
            cbLogo.setChecked(true);
        }else{
            cbLogo.setChecked(false);
        }
    }

    private void updateImgLogo(Bitmap newBitmap){
        //Bitmap bm=((BitmapDrawable)imgLogo.getDrawable()).getBitmap();
        DatabaseHelper dbHelper=new DatabaseHelper(LogoActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        ByteArrayOutputStream baos= null;
        try{
            baos = new ByteArrayOutputStream();
            newBitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] photo = baos.toByteArray();


            ContentValues cv = new ContentValues();
            cv.put("logo",photo);
            db.update("tprinter", cv, null, null);
        }catch (Exception e){
            Log.d("error",e.toString());
        }finally {
            if(baos != null){
                try {
                    baos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }

        }
    }

    private void updateLogoView(String str){

        DatabaseHelper dbHelper=new DatabaseHelper(LogoActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        try{
            String strSQL = "UPDATE tprinter set logo_view='"+str+"'";
            db.execSQL(strSQL);
            System.out.println("update sukses");
        }catch (Exception e){
            //Log.d("error",e.toString());
        }finally {
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }

        }
    }

    private void resetLogo(){
        DatabaseHelper dbHelper=new DatabaseHelper(LogoActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        ByteArrayOutputStream baos=null;
        try {
            baos = new ByteArrayOutputStream();
            Bitmap bitmap = BitmapFactory.decodeResource(this.getResources(), R.drawable.print_logo);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
            byte[] photo = baos.toByteArray();

            ContentValues cv = new ContentValues();
            cv.put("logo",photo);
            db.update("tprinter", cv, null, null);

            showLogo();
        }catch (Exception ex){

        }finally {
            if(baos != null){
                try {
                    baos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try{
                db.close();
                dbHelper.close();
            }catch (Exception ex){
                Log.i("gagal menutup database",ex.toString());
            }

        }
    }

    private String createContentDataPrint() {
        String line ="------------------------------";
        String br=System.getProperty("line.separator");

        StringBuilder sb = new StringBuilder();
        sb.append(TextSpace.rataTengah("PEMBELIAN TOKEN PLN"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("www.bitplus.co.id"));
        sb.append("\n");
        sb.append(TextSpace.rataTengah("Simple & Mudah"));
        sb.append("\n");
        sb.append(line);
        sb.append("\n");
        sb.append("Tgl Trans  : 123456789");
        sb.append("\n");
        sb.append("No Meter   : 12345678901");
        sb.append("\n");
        sb.append("ID Pel     : 123456789012");
        sb.append("\n");
        sb.append("Nama       : Test Cetak Printer");
        sb.append("\n");
        sb.append("Tarif/Daya : R1/1300");
        sb.append("\n");
        sb.append("Denom      : Rp. 20.000");
        sb.append("\n");
        sb.append("kWh        : 10");
        sb.append("\n");
        sb.append(line);
        sb.append(br);
        sb.append(TextSpace.rataTengah("TOKEN"));
        sb.append(br);
        sb.append(TextSpace.rataTengah("1111-2222-3333-4444-5555"));
        sb.append(br);
        sb.append(line);
        sb.append(br);
        sb.append(TextSpace.rataTengah("Terima Kasih"));
        sb.append(br);
        sb.append(TextSpace.rataTengah("CA : "+ Wong.getIdmerch()+" bitplus Mobile"));
        sb.append(br);

        return sb.toString();
    }
}