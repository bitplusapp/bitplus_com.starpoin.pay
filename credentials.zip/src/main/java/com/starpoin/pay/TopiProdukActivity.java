package com.starpoin.pay;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.starpoin.pay.helper.DatabaseHelper;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.TransTask;
import com.starpoin.pay.topi.DataProduk;
import com.starpoin.pay.topi.Produk;
import com.starpoin.pay.topi.adapter.ProdukAdapter;
import com.starpoin.pay.util.Params;
import com.starpoin.pay.util.Wong;

import org.json.JSONArray;
import org.json.JSONException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import malik.org.json.JSONObject;

public class TopiProdukActivity extends AbaseActivity {

    private ConstraintLayout rootLayout;
    //private ListView listview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topi_produk);

        setTitle("Produk");

        rootLayout=findViewById(R.id.rootLayout);

        //listview=findViewById(R.id.listview);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.topi_produk_menu, menu);

        //MenuInflater inflater = getMenuInflater();
        //inflater.inflate(R.menu.topi_produk_menu, menu);
        //MenuItem itemRefresh=menu.findItem(R.id.refresh);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.refresh:
                //saveNote();
                loadProduk();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        buildLocalData();
    }

    private void buildLocalData(){
        EditText etFilter = (EditText) findViewById(R.id.etFilter);

        ArrayList<Produk> list=new DataProduk().getListProduk(TopiProdukActivity.this);
        ProdukAdapter adapter=new ProdukAdapter(TopiProdukActivity.this,R.layout.topi_produk_list_adapter,list,etFilter);

        ListView listview=findViewById(R.id.listview);
        listview.setAdapter(adapter);
        listview.setTextFilterEnabled(true);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //String id,kode_produk,nama_produk,satuan,harga_beli,harga_jual1,qty1,harga_jual2,qty2,harga_jual3,qty3,stok;
                Produk e = (Produk) parent.getItemAtPosition(position);

                String kode_produk=e.getKode_produk();
                String nama_produk=e.getNama_produk();
                String satuan=e.getSatuan();
                String harga_beli=e.getHarga_beli();
                String harga_jual=e.getHarga_jual();

                String stok=e.getStok();

                Intent intent = new Intent(getBaseContext(), TopiViewProdukActivity.class);
                intent.putExtra("kode_produk", kode_produk);
                intent.putExtra("nama_produk", nama_produk);
                intent.putExtra("satuan", satuan);
                intent.putExtra("harga_beli", harga_beli);
                intent.putExtra("harga_jual", harga_jual);
                intent.putExtra("stok", stok);
                startActivity(intent);
            }
        });


        etFilter.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                // When user changed the Text

                adapter.getFilter().filter(cs.toString());
            }

            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                          int arg3) {
                // TODO Auto-generated method stub

            }

            public void afterTextChanged(Editable arg0) {
                // TODO Auto-generated method stub
            }
        });
    }

    private void loadProduk(){
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("q","list_produk");
        map.put("idmerc", Wong.getIdmerch());
        map.put("iduser", Wong.getEmail());
        String params="Topi"+new Params().buildParams(map);

        TransTask task = new TransTask(TopiProdukActivity.this,this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JSONObject job=new JSONObject(content);

                String rc=job.getString("rc");
                if(rc.equals("0000")){
                    //viewProduk(job);
                    updateDataProduk(content);
                }else{
                    String desc=job.getString("desc");
                    showMsg(desc);
                }
            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }



    private void updateDataProduk(String response){
        ArrayList<Produk> list=new ArrayList<>();
        try {


            org.json.JSONObject job=new org.json.JSONObject(response);
            JSONArray arr=job.getJSONArray("item");
            int size=arr.length();

            for(int i=0; i<size; i++){
                org.json.JSONObject js=arr.getJSONObject(i);
                String kode_produk=js.getString("kode_produk");
                String nama_produk=js.getString("nama_produk");
                String satuan=js.getString("satuan");
                String harga_beli=js.getString("harga_beli");
                String harga_jual=js.getString("harga_jual");
                String stok=js.getString("stok");

                Produk e=new Produk();
                e.setKode_produk(kode_produk);
                e.setNama_produk(nama_produk);
                e.setSatuan(satuan);
                e.setHarga_beli(harga_beli);
                e.setHarga_jual(harga_jual);
                e.setStok(stok);
                list.add(e);
            }

            resetProduk(list);
            buildLocalData();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void resetProduk(ArrayList<Produk> list){
        String idmerc=Wong.getIdmerch();
        String time=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        DatabaseHelper dbHelper=new DatabaseHelper(TopiProdukActivity.this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();

        String sql = "DELETE FROM topi_produk";
        db.execSQL(sql);

        for(Produk e:list){
            String kode_produk=e.getKode_produk();
            String nama_produk=e.getNama_produk();
            String satuan=e.getSatuan();
            String harga_beli=e.getHarga_beli();
            String harga_jual=e.getHarga_jual();
            String stok=e.getStok();

            String strSQL = "INSERT INTO topi_produk (id_merchant,kode_produk,nama_produk,satuan,harga_beli,harga_jual,stok,lastupdate) VALUES('"+idmerc+"','"+kode_produk+"','"+nama_produk+"','"+satuan+"','"+harga_beli+"','"+harga_jual+"','"+stok+"','"+time+"'  )  ";

            db.execSQL(strSQL);
        }

        db.close();
        dbHelper.close();
    }
}