package com.starpoin.pay;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.starpoin.pay.adapter.ListProductAdapter;
import com.starpoin.pay.adapter.NewResultAdapter;
import com.starpoin.pay.model.LapTrans;
import com.starpoin.pay.model.NewResultItem;
import com.starpoin.pay.model.Response;
import com.starpoin.pay.task.OnEventListener;
import com.starpoin.pay.task.OtherTask;
import com.starpoin.pay.util.DateParse;
import com.starpoin.pay.util.DatePick;
import com.starpoin.pay.util.JsonIn;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CektransaksiActivity extends AbaseActivity implements View.OnClickListener {

    private ConstraintLayout rootLayout;
    private RecyclerView rvDenom;
    private LinearLayout lyAmount;
    private EditText etNomor;
    private Button btntgl, btnShowProduct;

    private final Response response=new Response();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cektransaksi);

        this.setTitle("Cek Transaksi");

        rootLayout=(ConstraintLayout) findViewById(R.id.rootLayout);
        rvDenom=findViewById(R.id.rvDenom);
        lyAmount=(LinearLayout) findViewById(R.id.lyAmount);

        etNomor=findViewById(R.id.etNomor);

        btnShowProduct = findViewById(R.id.btnShowProduct);
        btnShowProduct.setOnClickListener(this);

        String tgl=new SimpleDateFormat("dd/MM/yyyy").format(new Date());
        btntgl=(Button) findViewById(R.id.btntgl);
        btntgl.setText(tgl);
        btntgl.setOnClickListener(this);

        //viewProduk();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btntgl:
                new DatePick(CektransaksiActivity.this,btntgl).onClick(v);

                break;

            case R.id.btnClear:
                etNomor.setText("");
                //viewProduk();
                break;
            case R.id.btnShowProduct:
                showBottomSheetDialogProductList();
                break;
        }
    }

    private void showBottomSheetDialogProductList() {
        lyAmount.setVisibility(View.GONE);
        ArrayList<LapTrans> list=new LapTrans().listProductReprint();
        final BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogStyle);
        dialog.setContentView(R.layout.bottom_sheet_dialog_product);

        final ListView lv = dialog.findViewById(R.id.lvProduct);
        lv.setAdapter(new ListProductAdapter(this, list));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                LapTrans lapTrans = (LapTrans) lv.getItemAtPosition(position);
                btnShowProduct.setText(lapTrans.getLabel());
                inquery(lapTrans);
                dialog.dismiss();
            }
        });
        // Get the height of the screen
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenHeight = displayMetrics.heightPixels;
        dialog.getBehavior().setPeekHeight(screenHeight);
        dialog.show();
    }

    private void inquery(LapTrans lap){
        String noid=etNomor.getText().toString().trim();
        if(noid.length()==0){
            noid="0";
        }
        String str=btntgl.getText().toString();
        String tgl=new DateParse().tglDefault(str);
        String params="report/status/"+lap.getKey()+"/"+noid+"/"+tgl;
        OtherTask task = new OtherTask(this, CektransaksiActivity.this, new OnEventListener<String>() {
            @Override
            public void onSuccess(String content) {
                JsonIn json = new JsonIn();
                String rc = json.getString(content, "rc");
                //String rc=xml.getItem(resp,"rc").trim();
                if(rc.equals("000")||rc.equals("0000")){
                    viewContent(content,lap.getId());
                }else{
                    showMsg("Tidak ada data ditemukan");
                }

            }

            @Override
            public void onFailure(Exception e) {
                showMsg(e.getMessage());
            }

        });
        task.execute(params);
    }

    private void viewContent(String content,int produk){
        rvDenom.removeAllViews();
        ArrayList<NewResultItem> list=response.NewlistResult(produk, content);
        NewResultAdapter adapter=new NewResultAdapter(getBaseContext(),list);
        GridLayoutManager layoutManager=new GridLayoutManager(this,1);
        rvDenom=findViewById(R.id.rvDenom);
        rvDenom.setLayoutManager(layoutManager);
        rvDenom.setAdapter(adapter);

        lyAmount.setVisibility(View.VISIBLE);

        TextView tvTotalAmount=(TextView) findViewById(R.id.tvTotalAmount);
        TextView tvTotalItem=(TextView) findViewById(R.id.tvTotalItem);
        Button btnClear=(Button) findViewById(R.id.btnClear);
        btnClear.setOnClickListener(this);

    }
}